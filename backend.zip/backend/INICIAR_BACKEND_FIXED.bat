@echo off
echo ========================================
echo   INICIANDO BACKEND (IGNORANDO TIPOS)
echo ========================================
echo.
cd /d %~dp0
set TS_NODE_TRANSPILE_ONLY=true
set TS_NODE_SKIP_PROJECT=true
echo Iniciando servidor...
node -r ts-node/register -r tsconfig-paths/register src/server.ts
pause


























