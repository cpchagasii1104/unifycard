-- backend/scripts/cleanup-invalid-professional-categories.sql
-- Script SQL de limpeza para categorias profissionais inválidas
-- FASE 3.8: Saneamento do legado
-- ⚠️ ATENÇÃO: Execute apenas após revisar diagnose-invalid-professional-categories.sql

BEGIN;

-- ============================================================
-- ETAPA 1: Arquivar categorias com blacklist hits
-- ============================================================
UPDATE categories
SET status = 'archived',
    updated_at = NOW()
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND (
    -- Sexual explícito
    LOWER(name) LIKE '%punheteiro%' OR
    LOWER(name) LIKE '%punheta%' OR
    LOWER(name) LIKE '%prostitut%' OR
    LOWER(name) LIKE '%escort%' OR
    LOWER(name) LIKE '%puta%' OR
    LOWER(name) LIKE '%vadia%' OR
    -- Crimes
    LOWER(name) LIKE '%ladr%' OR
    LOWER(name) LIKE '%roub%' OR
    LOWER(name) LIKE '%trafic%' OR
    LOWER(name) LIKE '%drog%' OR
    LOWER(name) LIKE '%assassin%' OR
    LOWER(name) LIKE '%homicid%' OR
    -- Violência/Ódio
    LOWER(name) LIKE '%nazi%' OR
    LOWER(name) LIKE '%racist%' OR
    LOWER(name) LIKE '%terrorist%'
  );

-- ============================================================
-- ETAPA 2: Arquivar termos genéricos sem qualificação
-- ============================================================
UPDATE categories
SET status = 'archived',
    updated_at = NOW()
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND array_length(string_to_array(name, ' '), 1) = 1
  AND NOT (
    name ILIKE '%ista' OR
    name ILIKE '%or' OR
    name ILIKE '%ora' OR
    name ILIKE '%eiro' OR
    name ILIKE '%eira' OR
    name ILIKE '%ólogo' OR
    name ILIKE '%ologo' OR
    name ILIKE '%óloga' OR
    name ILIKE '%ologa' OR
    name ILIKE '%nte' OR
    name ILIKE '%ário' OR
    name ILIKE '%ario' OR
    name ILIKE '%ária' OR
    name ILIKE '%aria' OR
    name ILIKE '%dor' OR
    name ILIKE '%dora'
  )
  AND LOWER(name) IN (
    'futebol', 'basquete', 'vôlei', 'volei', 'tênis', 'tenis',
    'música', 'musica', 'cinema', 'arte', 'comida', 'academia',
    'beleza', 'saúde', 'saude', 'educação', 'educacao',
    'tecnologia', 'esporte', 'hobby', 'interesse', 'passatempo'
  );

-- ============================================================
-- ETAPA 3: Arquivar hobbies infiltrados
-- ============================================================
UPDATE categories
SET status = 'archived',
    updated_at = NOW()
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND LOWER(name) IN (
    'futebol', 'basquete', 'vôlei', 'volei', 'tênis', 'tenis',
    'natação', 'natacao', 'corrida', 'ciclismo',
    'música', 'musica', 'cinema', 'arte', 'pintura', 'fotografia',
    'leitura', 'coleção', 'colecao', 'hobby', 'interesse'
  );

-- ============================================================
-- RELATÓRIO FINAL
-- ============================================================
SELECT 
  'Categorias arquivadas (blacklist)' AS action,
  COUNT(*) AS count
FROM categories
WHERE level = 2
  AND status = 'archived'
  AND updated_at > NOW() - INTERVAL '1 minute';

-- ⚠️ IMPORTANTE: Revisar antes de fazer COMMIT
-- Se estiver satisfeito, execute: COMMIT;
-- Se quiser reverter, execute: ROLLBACK;

-- Para executar, descomente a linha abaixo:
-- COMMIT;




























