// Script para aplicar remoção de categorias não-profissionais
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function applyRemove() {
  const client = await pool.connect();
  
  try {
    const sqlPath = path.join(__dirname, '../../docs/dev/sql/remove-non-professions.sql');
    
    if (!fs.existsSync(sqlPath)) {
      console.error('❌ Arquivo SQL não encontrado:', sqlPath);
      console.log('💡 Execute primeiro: node scripts/remove-non-professions.js');
      return;
    }
    
    const sql = fs.readFileSync(sqlPath, 'utf8');
    
    console.log('📋 Aplicando remoção de categorias não-profissionais...');
    console.log('⚠️  ATENÇÃO: Isso arquivará categorias como:');
    console.log('   - Gêneros de Filme');
    console.log('   - Gêneros Musicais');
    console.log('   - Gêneros Literários');
    console.log('   - Jogos de Mesa');
    console.log('   - Videogames');
    console.log('   - Séries');
    console.log('   - E outras categorias não-profissionais\n');
    
    await client.query('BEGIN');
    await client.query(sql);
    await client.query('COMMIT');
    
    console.log('✅ Remoção concluída!\n');
    
    // Verificar resultado
    const result = await client.query(`
      SELECT 
        level,
        status,
        COUNT(*) as total
      FROM categories
      GROUP BY level, status
      ORDER BY level, status
    `);
    
    console.log('=== RESULTADO ===');
    result.rows.forEach(row => {
      const levelLabel = row.level === 0 ? 'Grupos' : row.level === 1 ? 'Subgrupos' : row.level === 2 ? 'Profissões' : `Level ${row.level}`;
      console.log(`${levelLabel} (${row.status}): ${row.total}`);
    });
    
    // Contar profissões ativas
    const profissoes = await client.query(`
      SELECT COUNT(*) as total
      FROM categories
      WHERE level = 2 
        AND (SELECT COUNT(*) FROM categories WHERE parent_id = categories.category_id) = 0
        AND (status = 'active' OR status = 'auto_active')
    `);
    
    console.log(`\n✅ Profissões ativas restantes: ${profissoes.rows[0].total}`);
    
    // Verificar se "Gêneros de Filme" foi arquivado
    const generosFilme = await client.query(`
      SELECT category_id, name, status
      FROM categories
      WHERE slug LIKE '%genero%filme%' OR name LIKE '%Gênero%Filme%'
    `);
    
    if (generosFilme.rows.length > 0) {
      console.log('\n=== VERIFICAÇÃO: Gêneros de Filme ===');
      generosFilme.rows.forEach(cat => {
        console.log(`   ${cat.name}: ${cat.status}`);
      });
    }
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Erro:', error.message);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

applyRemove().catch(console.error);




























