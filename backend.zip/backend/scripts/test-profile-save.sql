-- Script para testar se os dados estão sendo salvos no banco
-- Execute este script diretamente no PostgreSQL para verificar

-- 1. Ver todos os global_users com seus dados
SELECT 
  global_user_id,
  full_name,
  birthdate,
  updated_at,
  created_at
FROM global_users
ORDER BY updated_at DESC
LIMIT 10;

-- 2. Ver links entre users e global_users
SELECT 
  u.user_id,
  u.email,
  u.global_user_id as users_global_user_id,
  uil.global_user_id as links_global_user_id,
  gu.full_name,
  gu.birthdate,
  gu.updated_at
FROM users u
LEFT JOIN user_identity_links uil ON u.user_id = uil.user_id
LEFT JOIN global_users gu ON COALESCE(u.global_user_id, uil.global_user_id) = gu.global_user_id
ORDER BY gu.updated_at DESC NULLS LAST
LIMIT 10;


























