// backend/scripts/audit-professional-categories-invalid.js
// Script de auditoria para identificar categorias profissionais inválidas
// FASE 3.8: Limpeza de categorias que não são profissões

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Termos bloqueados (mesmos da política)
const BLOCKED_TERMS = new Set([
  // Sexual explícito
  'punheteiro', 'punheta', 'masturbação', 'masturbacao', 'sexo', 'pornografia',
  'prostituta', 'prostituto', 'garota de programa', 'garoto de programa',
  'escort', 'acompanhante', 'puta', 'puto', 'vadia', 'viado', 'bicha',
  // Crimes
  'ladrão', 'ladrao', 'roubo', 'assalto', 'traficante', 'traficar', 'drogas',
  'homicídio', 'homicidio', 'assassinato', 'estelionato', 'fraude', 'corrupção',
  'corrupcao', 'contrabando', 'pirataria', 'pirata', 'hacker criminoso',
  // Violência e ódio
  'nazista', 'fascista', 'racista', 'xenófobo', 'xenofobo', 'homofóbico',
  'homofobico', 'misógino', 'misogino', 'terrorista', 'terrorismo',
  // Profissões ilegais
  'assassino de aluguel', 'matador', 'sicário', 'sicario',
]);

// Termos genéricos que NÃO são profissões
const GENERIC_TERMS = new Set([
  'futebol', 'basquete', 'vôlei', 'volei', 'tênis', 'tenis', 'natação', 'natacao',
  'música', 'musica', 'cinema', 'arte', 'comida', 'academia', 'beleza',
  'saúde', 'saude', 'educação', 'educacao', 'tecnologia', 'esporte',
  'hobby', 'interesse', 'passatempo',
]);

// Padrões de bloqueio
const BLOCK_PATTERNS = [
  /(sexo|sexual|porn|xxx|adulto|erótico|erotico)/i,
  /(ladr|roub|assalt|furt)/i,
  /(trafic|drog|maconh|coca|hero)/i,
  /(mat|assassin|homicíd|homicid)/i,
  /(nazi|fasc|racist|homofób|homofob|xenófob|xenofob)/i,
  /(put|vadi|prostitut|escort|acompanhant)/i,
];

function normalizeInput(input) {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .trim();
}

function isBlockedTerm(name) {
  const normalized = normalizeInput(name);
  
  // Verificar termos bloqueados explicitamente
  if (BLOCKED_TERMS.has(normalized)) {
    return { blocked: true, reason: 'Termo bloqueado explicitamente', type: 'EXPLICIT_BLOCK' };
  }
  
  // Verificar se contém termo bloqueado
  for (const blocked of BLOCKED_TERMS) {
    if (normalized.includes(blocked) || blocked.includes(normalized)) {
      return { blocked: true, reason: `Contém termo bloqueado: ${blocked}`, type: 'CONTAINS_BLOCKED' };
    }
  }
  
  // Verificar padrões regex
  for (const pattern of BLOCK_PATTERNS) {
    if (pattern.test(normalized)) {
      return { blocked: true, reason: 'Contém padrão bloqueado', type: 'PATTERN_BLOCK' };
    }
  }
  
  // Verificar termos genéricos (apenas para nível 2 - profissões finais)
  if (GENERIC_TERMS.has(normalized)) {
    return { blocked: true, reason: 'Termo genérico que não é profissão', type: 'GENERIC_TERM' };
  }
  
  return { blocked: false };
}

async function auditCategories() {
  console.log('🔍 Iniciando auditoria de categorias profissionais...\n');
  
  try {
    // Buscar todas as categorias (incluindo archived para auditoria completa)
    const result = await pool.query(`
      SELECT 
        category_id,
        name,
        slug,
        level,
        parent_id,
        status,
        created_by_ai,
        path
      FROM categories
      WHERE status IS NULL OR status != 'archived'
      ORDER BY level ASC, name ASC
    `);
    
    const categories = result.rows;
    console.log(`📊 Total de categorias encontradas: ${categories.length}\n`);
    
    // Classificar categorias
    const invalidCategories = [];
    const validCategories = [];
    const needsReview = [];
    
    for (const cat of categories) {
      // Apenas verificar categorias de nível 2 (profissões finais)
      // Níveis 0 e 1 são grupos/subgrupos, podem ser genéricos
      if (cat.level === 2) {
        const check = isBlockedTerm(cat.name);
        
        if (check.blocked) {
          invalidCategories.push({
            ...cat,
            reason: check.reason,
            type: check.type,
          });
        } else {
          // Verificar se é termo genérico sem qualificação profissional
          const normalized = normalizeInput(cat.name);
          const isGeneric = GENERIC_TERMS.has(normalized);
          
          if (isGeneric) {
            needsReview.push({
              ...cat,
              reason: 'Termo genérico - verificar se é profissão qualificada',
            });
          } else {
            validCategories.push(cat);
          }
        }
      } else {
        // Grupos e subgrupos são válidos por padrão
        validCategories.push(cat);
      }
    }
    
    // Relatório
    console.log('═══════════════════════════════════════════════════════════');
    console.log('📋 RELATÓRIO DE AUDITORIA');
    console.log('═══════════════════════════════════════════════════════════\n');
    
    console.log(`✅ Categorias válidas: ${validCategories.length}`);
    console.log(`❌ Categorias inválidas (bloqueadas): ${invalidCategories.length}`);
    console.log(`⚠️  Categorias para revisão: ${needsReview.length}\n`);
    
    if (invalidCategories.length > 0) {
      console.log('═══════════════════════════════════════════════════════════');
      console.log('❌ CATEGORIAS INVÁLIDAS (DEVEM SER REMOVIDAS)');
      console.log('═══════════════════════════════════════════════════════════\n');
      
      // Agrupar por tipo
      const byType = {};
      invalidCategories.forEach(cat => {
        if (!byType[cat.type]) {
          byType[cat.type] = [];
        }
        byType[cat.type].push(cat);
      });
      
      for (const [type, cats] of Object.entries(byType)) {
        console.log(`\n📌 ${type} (${cats.length} categorias):`);
        cats.forEach(cat => {
          const path = cat.path && cat.path.length > 0 
            ? cat.path.join(' → ') + ' → ' + cat.name
            : cat.name;
          console.log(`   - ${cat.name} (ID: ${cat.category_id})`);
          console.log(`     Caminho: ${path}`);
          console.log(`     Motivo: ${cat.reason}`);
          if (cat.created_by_ai) {
            console.log(`     ⚠️  Criado por IA`);
          }
          console.log('');
        });
      }
    }
    
    if (needsReview.length > 0) {
      console.log('═══════════════════════════════════════════════════════════');
      console.log('⚠️  CATEGORIAS PARA REVISÃO');
      console.log('═══════════════════════════════════════════════════════════\n');
      
      needsReview.forEach(cat => {
        const path = cat.path && cat.path.length > 0 
          ? cat.path.join(' → ') + ' → ' + cat.name
          : cat.name;
        console.log(`   - ${cat.name} (ID: ${cat.category_id})`);
        console.log(`     Caminho: ${path}`);
        console.log(`     Motivo: ${cat.reason}\n`);
      });
    }
    
    // Gerar SQL de remoção
    if (invalidCategories.length > 0) {
      const sqlPath = path.join(__dirname, '../docs/dev/sql/remove-invalid-professional-categories.sql');
      const fs = require('fs');
      
      let sql = `-- Script gerado automaticamente por audit-professional-categories-invalid.js\n`;
      sql += `-- Data: ${new Date().toISOString()}\n`;
      sql += `-- Total de categorias inválidas: ${invalidCategories.length}\n\n`;
      sql += `-- ATENÇÃO: Este script arquiva categorias inválidas\n`;
      sql += `-- Execute apenas após revisar a lista acima\n\n`;
      sql += `BEGIN;\n\n`;
      
      // Primeiro, arquivar categorias inválidas
      sql += `-- Arquivar categorias inválidas\n`;
      invalidCategories.forEach(cat => {
        sql += `UPDATE categories SET status = 'archived', updated_at = NOW() WHERE category_id = '${cat.category_id}'; -- ${cat.name} (${cat.reason})\n`;
      });
      
      sql += `\nCOMMIT;\n`;
      
      fs.writeFileSync(sqlPath, sql, 'utf8');
      console.log(`\n💾 SQL de remoção gerado em: ${sqlPath}`);
      console.log(`   Execute este script para arquivar as categorias inválidas.\n`);
    }
    
    // Estatísticas finais
    console.log('═══════════════════════════════════════════════════════════');
    console.log('📊 ESTATÍSTICAS FINAIS');
    console.log('═══════════════════════════════════════════════════════════\n');
    console.log(`Total de categorias auditadas: ${categories.length}`);
    console.log(`Categorias válidas: ${validCategories.length} (${((validCategories.length / categories.length) * 100).toFixed(1)}%)`);
    console.log(`Categorias inválidas: ${invalidCategories.length} (${((invalidCategories.length / categories.length) * 100).toFixed(1)}%)`);
    console.log(`Categorias para revisão: ${needsReview.length} (${((needsReview.length / categories.length) * 100).toFixed(1)}%)\n`);
    
  } catch (error) {
    console.error('❌ Erro durante auditoria:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Executar auditoria
auditCategories()
  .then(() => {
    console.log('✅ Auditoria concluída com sucesso!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Erro fatal:', error);
    process.exit(1);
  });




























