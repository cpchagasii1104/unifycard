// Script para aplicar migration 058 - Fix constraint UNIQUE
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function applyMigration() {
  const client = await pool.connect();
  
  try {
    const migrationPath = path.join(__dirname, '../migrations/058_fix_categories_slug_unique_constraint.sql');
    const sql = fs.readFileSync(migrationPath, 'utf8');
    
    console.log('📋 Aplicando migration 058...');
    await client.query('BEGIN');
    await client.query(sql);
    await client.query('COMMIT');
    
    console.log('✅ Migration 058 aplicada com sucesso!');
    
    // Verificar constraints
    const result = await client.query(`
      SELECT indexname, indexdef 
      FROM pg_indexes 
      WHERE tablename = 'categories' 
      AND indexname LIKE '%slug%parent%'
      ORDER BY indexname
    `);
    
    console.log('\n=== ÍNDICES CRIADOS ===');
    result.rows.forEach(row => {
      console.log(`${row.indexname}:`);
      console.log(`  ${row.indexdef}\n`);
    });
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Erro ao aplicar migration:', error.message);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

applyMigration().catch(console.error);




























