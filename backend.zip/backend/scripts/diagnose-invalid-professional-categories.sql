-- backend/scripts/diagnose-invalid-professional-categories.sql
-- Script SQL de diagnóstico para categorias profissionais inválidas
-- FASE 3.8: Saneamento do legado

-- ============================================================
-- DIAGNÓSTICO 1: Blacklist Hits (Termos bloqueados)
-- ============================================================
SELECT 
  category_id,
  name,
  slug,
  level,
  parent_id,
  status,
  created_by_ai,
  path,
  'BLACKLIST_HIT' AS issue_type,
  CASE 
    WHEN LOWER(name) LIKE '%punheteiro%' OR LOWER(name) LIKE '%punheta%' THEN 'SEXUAL'
    WHEN LOWER(name) LIKE '%prostitut%' OR LOWER(name) LIKE '%escort%' THEN 'SEXUAL'
    WHEN LOWER(name) LIKE '%ladr%' OR LOWER(name) LIKE '%roub%' THEN 'CRIME'
    WHEN LOWER(name) LIKE '%trafic%' OR LOWER(name) LIKE '%drog%' THEN 'CRIME'
    WHEN LOWER(name) LIKE '%nazi%' OR LOWER(name) LIKE '%racist%' THEN 'HATE'
    ELSE 'OTHER'
  END AS reason
FROM categories
WHERE level = 2  -- Apenas profissões finais
  AND (status IS NULL OR status != 'archived')
  AND (
    -- Sexual
    LOWER(name) LIKE '%punheteiro%' OR
    LOWER(name) LIKE '%punheta%' OR
    LOWER(name) LIKE '%prostitut%' OR
    LOWER(name) LIKE '%escort%' OR
    LOWER(name) LIKE '%puta%' OR
    LOWER(name) LIKE '%vadia%' OR
    -- Crimes
    LOWER(name) LIKE '%ladr%' OR
    LOWER(name) LIKE '%roub%' OR
    LOWER(name) LIKE '%trafic%' OR
    LOWER(name) LIKE '%drog%' OR
    LOWER(name) LIKE '%assassin%' OR
    LOWER(name) LIKE '%homicid%' OR
    -- Violência/Ódio
    LOWER(name) LIKE '%nazi%' OR
    LOWER(name) LIKE '%racist%' OR
    LOWER(name) LIKE '%terrorist%'
  )
ORDER BY reason, name;

-- ============================================================
-- DIAGNÓSTICO 2: Falha Occupation Form Check
-- ============================================================
-- Termos genéricos sem sufixo ocupacional ou estrutura válida
SELECT 
  category_id,
  name,
  slug,
  level,
  parent_id,
  status,
  created_by_ai,
  path,
  'FORM_CHECK_FAIL' AS issue_type,
  'GENERIC_TERM_NO_SUFFIX' AS reason
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  -- Palavra única sem sufixo ocupacional
  AND array_length(string_to_array(name, ' '), 1) = 1
  AND NOT (
    name ILIKE '%ista' OR
    name ILIKE '%or' OR
    name ILIKE '%ora' OR
    name ILIKE '%eiro' OR
    name ILIKE '%eira' OR
    name ILIKE '%ólogo' OR
    name ILIKE '%ologo' OR
    name ILIKE '%óloga' OR
    name ILIKE '%ologa' OR
    name ILIKE '%nte' OR
    name ILIKE '%ário' OR
    name ILIKE '%ario' OR
    name ILIKE '%ária' OR
    name ILIKE '%aria' OR
    name ILIKE '%dor' OR
    name ILIKE '%dora'
  )
  -- Termos genéricos conhecidos
  AND LOWER(name) IN (
    'futebol', 'basquete', 'vôlei', 'volei', 'tênis', 'tenis',
    'música', 'musica', 'cinema', 'arte', 'comida', 'academia',
    'beleza', 'saúde', 'saude', 'educação', 'educacao',
    'tecnologia', 'esporte', 'hobby', 'interesse', 'passatempo'
  )
ORDER BY name;

-- ============================================================
-- DIAGNÓSTICO 3: Hobbies Infiltrados em Professional
-- ============================================================
-- Categorias que são claramente hobbies, não profissões
SELECT 
  category_id,
  name,
  slug,
  level,
  parent_id,
  status,
  created_by_ai,
  path,
  'HOBBY_IN_PROFESSIONAL' AS issue_type,
  'NOT_A_PROFESSION' AS reason
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND LOWER(name) IN (
    'futebol', 'basquete', 'vôlei', 'volei', 'tênis', 'tenis',
    'natação', 'natacao', 'corrida', 'ciclismo',
    'música', 'musica', 'cinema', 'arte', 'pintura', 'fotografia',
    'leitura', 'coleção', 'colecao', 'hobby', 'interesse'
  )
ORDER BY name;

-- ============================================================
-- RESUMO GERAL
-- ============================================================
SELECT 
  'Total de categorias nível 2' AS metric,
  COUNT(*) AS count
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')

UNION ALL

SELECT 
  'Categorias com blacklist hits' AS metric,
  COUNT(*) AS count
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND (
    LOWER(name) LIKE '%punheteiro%' OR
    LOWER(name) LIKE '%prostitut%' OR
    LOWER(name) LIKE '%ladr%' OR
    LOWER(name) LIKE '%trafic%' OR
    LOWER(name) LIKE '%nazi%'
  )

UNION ALL

SELECT 
  'Categorias genéricas sem sufixo' AS metric,
  COUNT(*) AS count
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND array_length(string_to_array(name, ' '), 1) = 1
  AND LOWER(name) IN (
    'futebol', 'música', 'musica', 'cinema', 'arte', 'comida'
  )

UNION ALL

SELECT 
  'Categorias criadas por IA' AS metric,
  COUNT(*) AS count
FROM categories
WHERE level = 2
  AND (status IS NULL OR status != 'archived')
  AND created_by_ai = true;




























