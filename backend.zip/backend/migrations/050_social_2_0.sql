-- ============================================================
-- UNIFICARD — MIGRATION 050
-- Arquivo: 050_social_actors_system.sql
-- Tipo: SISTEMA ESTRUTURAL (Social 2.0)
-- Banco alvo: PostgreSQL 14+
--
-- CONTEXTO
-- Esta migration implementa a arquitetura Social 2.0 do UnifyCard,
-- baseada em actors unificados (User / Page / Group / Channel),
-- permitindo autoria flexível de posts e interações sociais.
--
-- OBJETIVO
-- • Unificar identidades sociais em uma única tabela (actors)
-- • Permitir posts por usuários, páginas, grupos e canais
-- • Estruturar mídia, reações e comentários de forma escalável
--
-- MODELO CONCEITUAL
-- • actors representa identidades sociais canônicas
-- • cada entidade concreta possui no máximo um actor
-- • posts passam a referenciar actor_id (mantendo compatibilidade)
--
-- ESCOPO
-- ✔ Cria tabela actors
-- ✔ Cria post_media, reactions, comments
-- ✔ Integra posts com actors
-- ✔ Adiciona suporte a cover images
--
-- ❌ Não remove campos legados
-- ❌ Não cria contadores agregados
-- ❌ Não implementa moderação ou visibilidade avançada
--
-- DEPENDÊNCIAS
-- • tenants
-- • users
-- • global_users
-- • companies
-- • groups
-- • posts
-- • profiles
-- • função update_updated_at_column()
--
-- OBSERVAÇÕES IMPORTANTES
-- • actors é identidade SOCIAL, não de autenticação.
-- • Cada user / company / group pode ter apenas um actor.
-- • slug é único por tenant quando definido.
-- • reactions e comments permanecem ligados a global_user.
-- • channel é reservado para uso futuro.
-- • RLS de leitura é aberta por tenant (decisão consciente).
--
-- IDEMPOTÊNCIA
-- • Todas as estruturas usam IF NOT EXISTS ou guards
-- • Triggers seguem padrão único do projeto
--
-- ============================================================


-- ============================================================
-- 1) ACTORS
-- ============================================================

CREATE TABLE IF NOT EXISTS actors (
  actor_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  tenant_id UUID NOT NULL
    REFERENCES tenants(tenant_id)
    ON DELETE CASCADE,

  actor_type VARCHAR(20) NOT NULL
    CHECK (actor_type IN ('user', 'page', 'group', 'channel')),

  user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
  company_id UUID REFERENCES companies(company_id) ON DELETE CASCADE,
  group_id UUID REFERENCES groups(group_id) ON DELETE CASCADE,

  display_name TEXT NOT NULL,
  slug VARCHAR(255),
  avatar_url TEXT,
  cover_url TEXT,
  bio TEXT,

  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT actors_type_reference CHECK (
    (actor_type = 'user' AND user_id IS NOT NULL AND company_id IS NULL AND group_id IS NULL) OR
    (actor_type = 'page' AND company_id IS NOT NULL AND user_id IS NULL AND group_id IS NULL) OR
    (actor_type = 'group' AND group_id IS NOT NULL AND user_id IS NULL AND company_id IS NULL) OR
    (actor_type = 'channel' AND user_id IS NULL AND company_id IS NULL AND group_id IS NULL)
  )
);

-- Unicidade lógica por tipo
CREATE UNIQUE INDEX IF NOT EXISTS idx_actors_unique_user
  ON actors (user_id)
  WHERE actor_type = 'user';

CREATE UNIQUE INDEX IF NOT EXISTS idx_actors_unique_company
  ON actors (company_id)
  WHERE actor_type = 'page';

CREATE UNIQUE INDEX IF NOT EXISTS idx_actors_unique_group
  ON actors (group_id)
  WHERE actor_type = 'group';

-- Slug único por tenant
CREATE UNIQUE INDEX IF NOT EXISTS idx_actors_slug_unique
  ON actors (tenant_id, slug)
  WHERE slug IS NOT NULL;

-- Índices auxiliares
CREATE INDEX IF NOT EXISTS idx_actors_tenant ON actors (tenant_id);
CREATE INDEX IF NOT EXISTS idx_actors_type ON actors (actor_type);

-- RLS
ALTER TABLE actors ENABLE ROW LEVEL SECURITY;

CREATE POLICY actors_rls
  ON actors
  USING (tenant_id::text = current_setting('app.current_tenant', true))
  WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true));


-- ============================================================
-- 2) POST_MEDIA
-- ============================================================

CREATE TABLE IF NOT EXISTS post_media (
  media_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  tenant_id UUID NOT NULL
    REFERENCES tenants(tenant_id)
    ON DELETE CASCADE,

  post_id UUID NOT NULL
    REFERENCES posts(post_id)
    ON DELETE CASCADE,

  media_type VARCHAR(20) NOT NULL
    CHECK (media_type IN ('image','video','audio','document')),

  url TEXT NOT NULL,
  thumbnail_url TEXT,
  file_size BIGINT,
  mime_type VARCHAR(100),

  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

  display_order INTEGER NOT NULL DEFAULT 0,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_post_media_post ON post_media (post_id);
CREATE INDEX IF NOT EXISTS idx_post_media_tenant ON post_media (tenant_id);

ALTER TABLE post_media ENABLE ROW LEVEL SECURITY;

CREATE POLICY post_media_rls
  ON post_media
  USING (tenant_id::text = current_setting('app.current_tenant', true))
  WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true));


-- ============================================================
-- 3) REACTIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS reactions (
  reaction_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  tenant_id UUID NOT NULL
    REFERENCES tenants(tenant_id)
    ON DELETE CASCADE,

  post_id UUID NOT NULL
    REFERENCES posts(post_id)
    ON DELETE CASCADE,

  global_user_id UUID NOT NULL
    REFERENCES global_users(global_user_id)
    ON DELETE CASCADE,

  reaction_type VARCHAR(20) NOT NULL DEFAULT 'like'
    CHECK (reaction_type IN ('like','love','haha','wow','sad','angry')),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT reactions_unique_user_post
    UNIQUE (post_id, global_user_id)
);

CREATE INDEX IF NOT EXISTS idx_reactions_post ON reactions (post_id);
CREATE INDEX IF NOT EXISTS idx_reactions_user ON reactions (global_user_id);

ALTER TABLE reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY reactions_rls
  ON reactions
  USING (tenant_id::text = current_setting('app.current_tenant', true))
  WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true));


-- ============================================================
-- 4) COMMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS comments (
  comment_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  tenant_id UUID NOT NULL
    REFERENCES tenants(tenant_id)
    ON DELETE CASCADE,

  post_id UUID NOT NULL
    REFERENCES posts(post_id)
    ON DELETE CASCADE,

  global_user_id UUID NOT NULL
    REFERENCES global_users(global_user_id)
    ON DELETE CASCADE,

  content TEXT NOT NULL,

  parent_comment_id UUID
    REFERENCES comments(comment_id)
    ON DELETE CASCADE,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ,
  is_deleted BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_comments_post ON comments (post_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments (parent_comment_id)
  WHERE parent_comment_id IS NOT NULL;

ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY comments_rls
  ON comments
  USING (tenant_id::text = current_setting('app.current_tenant', true))
  WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true));


-- ============================================================
-- 5) POSTS → ACTORS
-- ============================================================

ALTER TABLE posts
ADD COLUMN IF NOT EXISTS actor_id UUID
  REFERENCES actors(actor_id)
  ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_posts_actor
  ON posts (actor_id)
  WHERE actor_id IS NOT NULL;


-- ============================================================
-- 6) COVER IMAGES
-- ============================================================

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS cover_url TEXT;

ALTER TABLE companies
ADD COLUMN IF NOT EXISTS cover_url TEXT;


-- ============================================================
-- 7) TRIGGERS updated_at (PADRÃO)
-- ============================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_actors_updated_at') THEN
    CREATE TRIGGER trg_actors_updated_at
      BEFORE UPDATE ON actors
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_reactions_updated_at') THEN
    CREATE TRIGGER trg_reactions_updated_at
      BEFORE UPDATE ON reactions
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_comments_updated_at') THEN
    CREATE TRIGGER trg_comments_updated_at
      BEFORE UPDATE ON comments
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;


-- ============================================================
-- COMENTÁRIOS
-- ============================================================

COMMENT ON TABLE actors IS
  'Identidades sociais unificadas (User / Page / Group / Channel)';

COMMENT ON TABLE post_media IS
  'Mídia associada aos posts sociais';

COMMENT ON TABLE reactions IS
  'Reações dos usuários aos posts';

COMMENT ON TABLE comments IS
  'Comentários nos posts com suporte a threading e soft delete';


-- ============================================================
-- FIM 050_social_actors_system.sql
-- ============================================================
