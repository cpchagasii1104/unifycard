/*
Arquivo: 003_config_system.sql
Projeto: UnifyCard
Banco: PostgreSQL 14+
Escopo: Configuração dinâmica e feature flags

Objetivo:
- Permitir configurações por tenant e módulo
- Implementar feature flags com rollout controlado

Dependências:
- tenants (001_initial_schema)
Observações:
- Introduz função utilitária update_updated_at_column
*/


CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- TENANT CONFIGS
CREATE TABLE IF NOT EXISTS tenant_configs (
  config_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),

  module VARCHAR(100) NOT NULL,
  key VARCHAR(200) NOT NULL,

  value JSONB NOT NULL,
  value_type VARCHAR(20) NOT NULL CHECK (value_type IN ('string','number','boolean','json')),

  is_system BOOLEAN NOT NULL DEFAULT FALSE,

  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),

  UNIQUE (tenant_id, module, key)
);

ALTER TABLE IF EXISTS tenant_configs ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname=current_schema() AND tablename='tenant_configs' AND policyname='tenant_configs_rls'
  ) THEN
    CREATE POLICY tenant_configs_rls ON tenant_configs
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_tenant_configs_tenant_module
  ON tenant_configs(tenant_id, module);

CREATE INDEX IF NOT EXISTS idx_tenant_configs_tenant_module_key
  ON tenant_configs(tenant_id, module, key);

-- FEATURE FLAGS
CREATE TABLE IF NOT EXISTS feature_flags (
  flag_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),

  flag_name VARCHAR(200) NOT NULL,
  description TEXT,

  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  rollout_percentage INTEGER NOT NULL DEFAULT 100 CHECK (rollout_percentage >= 0 AND rollout_percentage <= 100),

  user_whitelist UUID[] DEFAULT '{}',

  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),

  UNIQUE (tenant_id, flag_name)
);

ALTER TABLE IF EXISTS feature_flags ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname=current_schema() AND tablename='feature_flags' AND policyname='feature_flags_rls'
  ) THEN
    CREATE POLICY feature_flags_rls ON feature_flags
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_feature_flags_tenant
  ON feature_flags(tenant_id);

CREATE INDEX IF NOT EXISTS idx_feature_flags_tenant_flag
  ON feature_flags(tenant_id, flag_name);

-- UPDATED_AT TRIGGER FUNCTION
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- TRIGGERS (idempotentes)
DROP TRIGGER IF EXISTS update_tenant_configs_updated_at ON tenant_configs;
CREATE TRIGGER update_tenant_configs_updated_at
  BEFORE UPDATE ON tenant_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_feature_flags_updated_at ON feature_flags;
CREATE TRIGGER update_feature_flags_updated_at
  BEFORE UPDATE ON feature_flags
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE tenant_configs IS 'Configurações dinâmicas por tenant e módulo';
COMMENT ON TABLE feature_flags IS 'Feature flags com rollout gradual e whitelist de usuários';
COMMENT ON FUNCTION update_updated_at_column IS 'Atualiza coluna updated_at automaticamente em UPDATEs';
