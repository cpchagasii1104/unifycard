/*
Arquivo: 001_initial_schema.sql
Projeto: UnifyCard
Banco: PostgreSQL 14+
Escopo: Core multi-tenant + financeiro

Objetivo:
- Criar tenants, users, accounts, transactions e ledger
- Estabelecer isolamento por tenant via RLS
- Base financeira e de eventos do sistema

Dependências:
- 000_schema_migrations.sql
Observações:
- Define o modelo base de tenant_id usado em todo o projeto
*/

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- TENANTS
CREATE TABLE IF NOT EXISTS tenants (
  tenant_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- USERS
CREATE TABLE IF NOT EXISTS users (
  user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  email VARCHAR(255) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  UNIQUE(tenant_id, email)
);

ALTER TABLE IF EXISTS users ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'users'
      AND policyname = 'users_rls'
  ) THEN
    CREATE POLICY users_rls ON users
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

-- PROFILES
CREATE TABLE IF NOT EXISTS profiles (
  profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  user_id UUID NOT NULL REFERENCES users(user_id),
  full_name VARCHAR(255),
  phone VARCHAR(50),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  UNIQUE(tenant_id, user_id)
);

ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'profiles'
      AND policyname = 'profile_rls'
  ) THEN
    CREATE POLICY profile_rls ON profiles
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

-- ACCOUNTS
CREATE TABLE IF NOT EXISTS accounts (
  account_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  owner_id UUID NOT NULL,
  owner_type VARCHAR(50) NOT NULL CHECK (
    owner_type IN ('user','merchant','community_fund','platform_ops','group')
  ),
  balance NUMERIC(20,2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'BRL',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

ALTER TABLE IF EXISTS accounts ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'accounts'
      AND policyname = 'accounts_rls'
  ) THEN
    CREATE POLICY accounts_rls ON accounts
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

-- TRANSACTIONS
CREATE TABLE IF NOT EXISTS transactions (
  transaction_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  from_account UUID NOT NULL REFERENCES accounts(account_id),
  to_account UUID NOT NULL REFERENCES accounts(account_id),
  amount NUMERIC(20,2) NOT NULL CHECK (amount > 0),
  currency VARCHAR(3) DEFAULT 'BRL',
  event_id UUID NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT now(),
  settled_at TIMESTAMP
);

ALTER TABLE IF EXISTS transactions ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'transactions'
      AND policyname = 'transactions_rls'
  ) THEN
    CREATE POLICY transactions_rls ON transactions
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

-- LEDGER
CREATE TABLE IF NOT EXISTS ledger (
  entry_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  account_id UUID NOT NULL REFERENCES accounts(account_id),
  transaction_id UUID NOT NULL REFERENCES transactions(transaction_id),
  entry_type VARCHAR(10) NOT NULL CHECK(entry_type IN ('credit','debit')),
  amount NUMERIC(20,2) NOT NULL,
  balance_before NUMERIC(20,2) NOT NULL,
  balance_after NUMERIC(20,2) NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

ALTER TABLE IF EXISTS ledger ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'ledger'
      AND policyname = 'ledger_rls'
  ) THEN
    CREATE POLICY ledger_rls ON ledger
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

-- EVENT LOG
CREATE TABLE IF NOT EXISTS event_log (
  event_id UUID PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES tenants(tenant_id),
  event_type VARCHAR(255) NOT NULL,
  event_version INTEGER DEFAULT 1,
  payload JSONB NOT NULL,
  metadata JSONB DEFAULT '{}',
  processed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT now()
);

ALTER TABLE IF EXISTS event_log ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema()
      AND tablename  = 'event_log'
      AND policyname = 'event_log_rls'
  ) THEN
    CREATE POLICY event_log_rls ON event_log
      USING (tenant_id::text = current_setting('app.current_tenant', true));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_eventlog_processing
  ON event_log(processed, created_at);