/*
Arquivo: 016_rides_patch_requirements.sql
Projeto: UnifyCard
Banco: PostgreSQL 14+
Escopo: Patch cirúrgico — métricas em tempo real, limites legais e incentivos dinâmicos

Objetivo:
1. Ganhos por hora e por km
2. Paradas detalhadas na corrida
3. Limite legal de 12h dirigindo
4. Pressão de demanda por zona (surge)
5. Incentivos automáticos por zona

Dependências:
- rides_driver_sessions
- rides_rides
- rides_zones
- rides_zone_demand_pressure
- rides_zone_incentives
- update_updated_at_column()
*/

-- =========================================================
-- 1) CAMPOS EM rides_driver_sessions
-- =========================================================

ALTER TABLE rides_driver_sessions
  ADD COLUMN IF NOT EXISTS current_earnings_per_hour NUMERIC(10,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS current_earnings_per_km   NUMERIC(10,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_earnings_session    NUMERIC(12,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_distance_km_session NUMERIC(10,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_rides_session       INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS alerts_sent               JSONB DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS vehicle_id                UUID,
  ADD COLUMN IF NOT EXISTS city_id                   UUID;

-- =========================================================
-- 2) FUNÇÃO: rides_check_driving_limit
-- ❗ VOLATILE (faz UPDATE)
-- =========================================================

CREATE OR REPLACE FUNCTION rides_check_driving_limit(
  p_tenant_id UUID,
  p_driver_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
  v_session RECORD;
  v_driving_minutes INTEGER;
  v_max_minutes INTEGER := 720; -- 12h
  v_warning TEXT := NULL;
  v_forced_break_until TIMESTAMPTZ;
BEGIN
  SELECT *
  INTO v_session
  FROM rides_driver_sessions
  WHERE tenant_id = p_tenant_id
    AND driver_id = p_driver_id
    AND ended_at IS NULL
  ORDER BY started_at DESC
  LIMIT 1;

  IF v_session IS NULL THEN
    RETURN jsonb_build_object(
      'can_drive', true,
      'driving_minutes', 0,
      'minutes_remaining', v_max_minutes
    );
  END IF;

  v_driving_minutes := COALESCE(v_session.driving_time_minutes, 0);

  IF v_driving_minutes >= v_max_minutes THEN
    v_forced_break_until := now() + interval '8 hours';

    UPDATE rides_driver_sessions
    SET is_forced_break = true,
        forced_break_until = v_forced_break_until
    WHERE session_id = v_session.session_id;

    RETURN jsonb_build_object(
      'can_drive', false,
      'warning', 'limit_reached',
      'forced_break_until', v_forced_break_until
    );
  END IF;

  RETURN jsonb_build_object(
    'can_drive', true,
    'driving_minutes', v_driving_minutes,
    'minutes_remaining', v_max_minutes - v_driving_minutes
  );
END;
$$;

-- =========================================================
-- 3) FUNÇÃO: rides_calculate_realtime_earnings
-- ❗ VOLATILE (faz UPDATE)
-- =========================================================

CREATE OR REPLACE FUNCTION rides_calculate_realtime_earnings(
  p_tenant_id UUID,
  p_driver_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
  v_session RECORD;
  v_total NUMERIC(12,2) := 0;
  v_dist  NUMERIC(10,2) := 0;
  v_rides INTEGER := 0;
  v_online_minutes NUMERIC := 0;
  v_eph NUMERIC := 0;
  v_epk NUMERIC := 0;
BEGIN
  SELECT *
  INTO v_session
  FROM rides_driver_sessions
  WHERE tenant_id = p_tenant_id
    AND driver_id = p_driver_id
    AND ended_at IS NULL
  ORDER BY started_at DESC
  LIMIT 1;

  IF v_session IS NULL THEN
    RETURN jsonb_build_object('has_session', false);
  END IF;

  SELECT
    COALESCE(SUM(r.final_price * 0.85), 0),
    COALESCE(SUM(r.total_distance_km), 0),
    COUNT(*)
  INTO v_total, v_dist, v_rides
  FROM rides_rides r
  WHERE r.tenant_id = p_tenant_id
    AND r.driver_id = p_driver_id
    AND r.status = 'completed'
    AND r.completed_at >= v_session.started_at;

  v_online_minutes :=
    EXTRACT(EPOCH FROM (now() - v_session.started_at)) / 60;

  IF v_online_minutes > 0 THEN
    v_eph := (v_total / v_online_minutes) * 60;
  END IF;

  IF v_dist > 0 THEN
    v_epk := v_total / v_dist;
  END IF;

  UPDATE rides_driver_sessions
  SET current_earnings_per_hour = v_eph,
      current_earnings_per_km   = v_epk,
      total_earnings_session    = v_total,
      total_distance_km_session = v_dist,
      total_rides_session       = v_rides
  WHERE session_id = v_session.session_id;

  RETURN jsonb_build_object(
    'has_session', true,
    'session_id', v_session.session_id,
    'earnings_per_hour', ROUND(v_eph, 2),
    'earnings_per_km', ROUND(v_epk, 2),
    'total_earnings', ROUND(v_total, 2),
    'total_distance_km', ROUND(v_dist, 2),
    'total_rides', v_rides,
    'online_minutes', ROUND(v_online_minutes, 0)
  );
END;
$$;

-- =========================================================
-- FIM DO PATCH 016
-- =========================================================
