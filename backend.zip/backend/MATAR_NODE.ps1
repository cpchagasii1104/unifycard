# Script para matar TODOS os processos Node
# Execute como Administrador

Write-Host "=== MATANDO TODOS OS PROCESSOS NODE ===" -ForegroundColor Red
Write-Host ""

$processes = Get-Process -Name node -ErrorAction SilentlyContinue

if ($processes) {
    Write-Host "Encontrados $($processes.Count) processos Node:" -ForegroundColor Yellow
    $processes | ForEach-Object {
        Write-Host "  PID: $($_.Id) - Iniciado: $($_.StartTime)" -ForegroundColor White
    }
    Write-Host ""
    Write-Host "Matando processos..." -ForegroundColor Red
    Stop-Process -Name node -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    
    # Verificar se ainda há processos
    $remaining = Get-Process -Name node -ErrorAction SilentlyContinue
    if ($remaining) {
        Write-Host "AVISO: Ainda ha processos Node rodando!" -ForegroundColor Red
        Write-Host "Tente executar como Administrador ou mate manualmente" -ForegroundColor Yellow
    } else {
        Write-Host "SUCESSO: Todos os processos Node foram mortos" -ForegroundColor Green
    }
} else {
    Write-Host "Nenhum processo Node encontrado" -ForegroundColor Green
}

Write-Host ""
Write-Host "Agora execute: npm run dev" -ForegroundColor Cyan


























