// run-migration-073.js
// Script temporário para executar apenas a migration 073

const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function run() {
  try {
    console.log('📦 Executando migration 073...');
    
    // Adicionar coluna company_status
    await pool.query(`
      ALTER TABLE companies 
      ADD COLUMN IF NOT EXISTS company_status VARCHAR(20) DEFAULT 'draft' 
      CHECK (company_status IN ('draft', 'manual', 'pending_doc', 'validated'))
    `);
    console.log('✅ Coluna company_status criada!');
    
    // Criar índice
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_companies_status ON companies(company_status)
    `);
    console.log('✅ Índice criado!');
    
    // Criar tabela company_documents (sem a constraint problemática por enquanto)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS company_documents (
        document_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        company_id UUID NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
        global_user_id UUID NOT NULL REFERENCES global_users(global_user_id) ON DELETE CASCADE,
        document_type VARCHAR(50) NOT NULL,
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER,
        mime_type VARCHAR(100) DEFAULT 'application/pdf',
        status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
        metadata JSONB DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
      )
    `);
    console.log('✅ Tabela company_documents criada!');
    
    // Criar índices
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_company_documents_company ON company_documents(company_id)
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_company_documents_user ON company_documents(global_user_id)
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_company_documents_type ON company_documents(document_type)
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_company_documents_status ON company_documents(status)
    `);
    console.log('✅ Índices criados!');
    
    // Criar trigger
    await pool.query(`
      CREATE OR REPLACE FUNCTION update_company_documents_updated_at()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = now();
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql
    `);
    
    await pool.query(`
      DROP TRIGGER IF EXISTS trigger_update_company_documents_updated_at ON company_documents;
      CREATE TRIGGER trigger_update_company_documents_updated_at
        BEFORE UPDATE ON company_documents
        FOR EACH ROW
        EXECUTE FUNCTION update_company_documents_updated_at()
    `);
    console.log('✅ Trigger criado!');
    
    console.log('✨ Migration 073 executada com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro:', error.message);
    console.error(error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

run();


























