// BOOT.ts - ÚNICO ENTRYPOINT DO BACKEND
import 'dotenv/config';

// ─────────────────────────────────────────────────────────────
// VALIDAÇÃO DE VARIÁVEIS DE AMBIENTE (ANTES DE QUALQUER COISA)
// ─────────────────────────────────────────────────────────────
import { validateEnv } from './src/core/config/env-validation';
try {
  validateEnv();
  console.log('✅ [BOOT] Validação de variáveis de ambiente: OK');
} catch (error) {
  console.error('❌ [BOOT] ERRO FATAL: Validação de variáveis de ambiente falhou');
  console.error(error);
  process.exit(1);
}

// ─────────────────────────────────────────────────────────────
// MARCA D'ÁGUA DE DIAGNÓSTICO
// ─────────────────────────────────────────────────────────────
console.log(
  'RUN TAG:',
  process.env.UNIFICARD_RUN || 'SEM_TAG',
  'PID:',
  process.pid
);
console.log('🔵 [BOOT] BOOT.ts carregado (ÚNICO ENTRYPOINT)');

// ─────────────────────────────────────────────────────────────
// IMPORTS LEVES (NENHUM DOMÍNIO / DB / EVENTOS AQUI)
// ─────────────────────────────────────────────────────────────
import Fastify, { FastifyInstance } from 'fastify';
import sensible from '@fastify/sensible';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import staticFiles from '@fastify/static';
import * as path from 'path';
import * as net from 'net';

// Plugins
import { tenantPlugin } from './src/plugins/tenant.plugin';
import authPlugin from './src/core/auth/auth.plugin';
import { errorHandlerPlugin } from './src/plugins/error-handler.plugin';
import { rbacPlugin } from './src/plugins/rbac.plugin';
import { actionContextPlugin } from './src/plugins/action-context.plugin';
import { requestIdPlugin } from './src/plugins/request-id.plugin';

// Módulos públicos
import { authModule } from './src/core/auth/auth.module';
import { healthModule } from './src/core/health/health.module';

// ─────────────────────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────────────────────
// PORT é obrigatório (validado em validateEnv)
const PORT = Number(process.env.PORT);
if (!process.env.PORT || isNaN(PORT) || PORT < 1 || PORT > 65535) {
  console.error('❌ [BOOT] ERRO FATAL: PORT deve ser definido e ser um número válido entre 1 e 65535');
  console.error(`   PORT recebido: ${process.env.PORT}`);
  process.exit(1);
}
const HOST = process.env.HOST || '0.0.0.0';

// ─────────────────────────────────────────────────────────────
// BUILD APP (APENAS HTTP + ROTAS)
// ─────────────────────────────────────────────────────────────
export async function buildApp(): Promise<FastifyInstance> {
  console.log('[BOOT] Iniciando buildApp()...');
  
  // ─────────────────────────────────────────────────────────────
  // VALIDAÇÃO DE PERMISSÕES CANÔNICAS (FASE 1: ANTES DE TUDO)
  // ─────────────────────────────────────────────────────────────
  try {
    const { validateCanonicalPermissions } = await import('./src/core/authorization/validate-permissions');
    validateCanonicalPermissions();
  } catch (err) {
    console.error('[BOOT] ❌ ERRO FATAL: Validação de permissões canônicas falhou');
    console.error(err);
    process.exit(1); // Fail fast
  }

  // ─────────────────────────────────────────────────────────────
  // INJEÇÃO DE DEPENDÊNCIAS (FASE 2.1: @modules/social)
  // ─────────────────────────────────────────────────────────────
  try {
    const { socialPortsRegistry } = await import('./src/core/social/ports-registry');
    const {
      actorRepositoryAdapter,
      actorUtilsAdapter,
      socialRepositoryAdapter,
      socialServiceAdapter,
      eventFeedHandlersAdapter,
    } = await import('./src/modules/social/adapters');

    // Injetar adapters no registry do core
    socialPortsRegistry.setActorRepository(actorRepositoryAdapter);
    socialPortsRegistry.setActorUtils(actorUtilsAdapter);
    socialPortsRegistry.setSocialRepository(socialRepositoryAdapter);
    socialPortsRegistry.setSocialService(socialServiceAdapter);
    socialPortsRegistry.setEventFeedHandlers(eventFeedHandlersAdapter);

    console.log('[BOOT] ✅ Dependências de @modules/social injetadas no core');
  } catch (err) {
    console.error('[BOOT] ❌ ERRO ao injetar dependências de @modules/social:', err);
    throw err;
  }

  // ─────────────────────────────────────────────────────────────
  // INJEÇÃO DE DEPENDÊNCIAS (FASE 3: @modules/bank)
  // ─────────────────────────────────────────────────────────────
  try {
    const { bankPortsRegistry } = await import('./src/core/bank/ports-registry');
    const {
      bankAccountAdapter,
      bankTransactionAdapter,
      bankIntegrationAdapter,
      bankLimitAdapter,
    } = await import('./src/modules/bank/adapters');

    // Injetar adapters no registry do core
    bankPortsRegistry.setBankAccount(bankAccountAdapter);
    bankPortsRegistry.setBankTransaction(bankTransactionAdapter);
    bankPortsRegistry.setBankIntegration(bankIntegrationAdapter);
    bankPortsRegistry.setBankLimit(bankLimitAdapter);

    console.log('[BOOT] ✅ Dependências de @modules/bank injetadas no core');
  } catch (err) {
    console.error('[BOOT] ❌ ERRO ao injetar dependências de @modules/bank:', err);
    throw err;
  }

  // ─────────────────────────────────────────────────────────────
  // INJEÇÃO DE DEPENDÊNCIAS (FASE 4: @modules/groups)
  // ─────────────────────────────────────────────────────────────
  try {
    const { groupsPortsRegistry } = await import('./src/core/groups/ports-registry');
    const { groupsRepositoryAdapter } = await import('./src/modules/groups/adapters');

    // Injetar adapters no registry do core
    groupsPortsRegistry.setGroupsRepository(groupsRepositoryAdapter);

    console.log('[BOOT] ✅ Dependências de @modules/groups injetadas no core');
  } catch (err) {
    console.error('[BOOT] ❌ ERRO ao injetar dependências de @modules/groups:', err);
    throw err;
  }

  const app = Fastify({
    logger: {
      level: process.env.LOG_LEVEL || 'info',
      transport:
        process.env.NODE_ENV !== 'production'
          ? { target: 'pino-pretty', options: { colorize: true } }
          : undefined,
    },
  });

  // Plugins globais
  await app.register(sensible);
  await app.register(errorHandlerPlugin);
  
  // CORS: Permitir frontend local em desenvolvimento
  const corsOrigin = process.env.CORS_ORIGIN || (process.env.NODE_ENV === 'production' ? false : true);
  await app.register(cors, {
    origin: corsOrigin,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  });
  console.log(`[BOOT] CORS configurado: origin=${corsOrigin === true ? 'true (todos)' : corsOrigin}`);
  
  await app.register(helmet);
  
  // Rate limit: mais permissivo em desenvolvimento
  const isDevelopment = process.env.NODE_ENV === 'development' || process.env.NODE_ENV !== 'production';
  await app.register(rateLimit as any, {
    max: isDevelopment ? 5000 : 100, // 5000 requests/min em DEV, 100 em produção
    timeWindow: '1 minute',
    // Em desenvolvimento, permitir mais requisições para facilitar debug
    skipOnError: isDevelopment, // Não bloquear se houver erro no rate limit em DEV
    // Desabilitar rate limit para rotas de bootstrap em DEV
    skip: (req: any) => {
      if (isDevelopment) {
        const path = req.url;
        // Rotas de bootstrap que podem ser chamadas múltiplas vezes
        const bootstrapRoutes = [
          '/dashboard',
          '/identity/wallet',
          '/plan',
          '/referral/code',
          '/social/actors/available',
          '/core/profile',
        ];
        return bootstrapRoutes.some(route => path.startsWith(route));
      }
      return false;
    },
  });

  // Rotas públicas
  await app.register(authModule, { prefix: '/auth' });
  console.log('[BOOT] Rotas de autenticação registradas: /auth/login, /auth/register');
  
  await app.register(healthModule, { prefix: '/health' });
  console.log('[BOOT] Health check registrado: /health');

  // SPRINT 85: Webhook PIX (rota pública)
  try {
    const { pixWebhookRoutes } = await import('./src/modules/payments/pix.routes');
    await app.register(pixWebhookRoutes, { prefix: '/webhooks' });
    console.log('[BOOT] Webhook PIX registrado: /webhooks/pix/:provider');
  } catch (err) {
    console.warn('[BOOT] Aviso: Erro ao registrar webhook PIX (não bloqueante):', err);
  }

  // SPRINT 86: Payment Links (rotas públicas)
  try {
    const publicPaymentLinkRoutes = await import('./src/modules/payments/payment-link.routes');
    await app.register(publicPaymentLinkRoutes.default);
    // SPRINT 92: Venue Public Routes
    const { venuePublicRoutes } = await import('./src/modules/venue/venue.routes');
    await app.register(venuePublicRoutes);
    console.log('[BOOT] Payment Links públicos registrados: /pay/:slug');
  } catch (err) {
    console.warn('[BOOT] Aviso: Erro ao registrar payment links públicos (não bloqueante):', err);
  }

  // Servir arquivos estáticos de uploads
  const uploadsDir = path.join(process.cwd(), 'uploads');
  await app.register(staticFiles, {
    root: uploadsDir,
    prefix: '/uploads/',
  });
  console.log('[BOOT] Arquivos estáticos de uploads registrados: /uploads/');

  // Marketplace Public Routes (read-only, estático, sem tenant)
  // ORDEM: Após RBAC Guards, antes de rotas protegidas
  try {
    const marketplacePublicRoutes = await import('./src/modules/marketplace/marketplace-public.routes');
    await app.register(marketplacePublicRoutes.default, { prefix: '/marketplace' });
    console.log('[BOOT] ✅ Marketplace rotas públicas registradas: /marketplace (health, home, templates, categories, stores, regions)');
  } catch (err) {
    console.error('[BOOT] ❌ ERRO FATAL: Falha ao registrar Marketplace rotas públicas');
    console.error(err);
    throw err; // Fail fast - Marketplace é crítico
  }

  // Location Core (read-only, público)
  try {
    const locationRoutes = await import('./src/core/location/location.routes');
    await app.register(locationRoutes.default, { prefix: '/locations' });
    console.log('[BOOT] Location Core registrado: /locations');
  } catch (err) {
    console.warn('[BOOT] Aviso: Erro ao registrar Location Core (não bloqueante):', err);
  }

  // Reporting Core (denúncias)
  try {
    const reportingRoutes = await import('./src/core/reporting/reporting.routes');
    await app.register(reportingRoutes.default, { prefix: '/reports' });

    // 🔴 Company Canonical Birth - Nascimento Canônico
    const { default: companyCanonicalRoutes } = await import('./src/core/companies/company-canonical.routes');
    await app.register(companyCanonicalRoutes, { prefix: '/api' });
    console.log('[BOOT] Reporting Core registrado: /reports');
  } catch (err) {
    console.warn('[BOOT] Aviso: Erro ao registrar Reporting Core (não bloqueante):', err);
  }

  // Módulo obsoleto src/core/category foi removido - usar src/core/categories (canônico)
  // try {
  //   const categoryRoutes = await import('./src/core/category/category.routes');
  //   await app.register(categoryRoutes.default, { prefix: '/categories' });
  //   console.log('[BOOT] Category Core registrado: /categories');
  // } catch (err) {
  //   console.warn('[BOOT] Aviso: Erro ao registrar Category Core (não bloqueante):', err);
  // }

  // Location (import dinâmico - legado, se existir)
  try {
    const locationModule = await import('./src/services/location/location.module');
    await app.register(locationModule.default, { prefix: '/api' });
    console.log('[BOOT] Módulo de localização legado registrado');
  } catch (err) {
    // Ignorar se não existir
  }

  // Escopo protegido
  console.log('[BOOT] Registrando escopo protegido e módulos...');
  await app.register(async (protectedScope) => {
    await protectedScope.register(tenantPlugin);
    await protectedScope.register(authPlugin);
    await protectedScope.register(actionContextPlugin);
    await protectedScope.register(rbacPlugin);
    console.log('[BOOT] Plugins de tenant, auth, action-context e rbac registrados');

    // ── IMPORTS DINÂMICOS (DOMÍNIO) ──
    // Imports individuais para evitar problemas de ordem no Promise.all
    const availabilityImport = await import('./src/core/availability/availability.module');
    const calendarImport = await import('./src/core/calendar/unified-calendar.module');
    
    const [
      { economyModule },
      { rbacModule },
      { configModule },
      { notifyModule },
      { reviewModule },
      { reputationModule },
      { coreModule },
      { dashboardModule },
      { fundModule },
      { categoriesModule },
      { profileModule },
      { companiesModule },
      { publicationEngineModule },
      { referralModule },
      { planModule },
      { assistantModule },
      { socialActionsModule },
      { workModule },
      { ridesModule },
      { socialModule },
      { mediaModule },
      { culturalModule },
      { votesModule },
      // Feed e Eventos (reintroduzidos)
      { feedContextualModule },
      { feedLegacyModule },
      eventLifecycleRoutes,
      // Módulos faltantes (reintroduzidos)
      { identityModule },
      { matchingModule },
      { opportunityModule },
      { unifybankModule },
      { categoryReviewModule },
      { checkoutModule },
      { eventsModule },
      { eventModule },
      { aiModule },
      // Trust Dashboard (FASE 10)
      trustModule,
      // Grupos
      { groupsModule },
      // Serviços
      { servicesModule },
      // Dashboard Econômico (READ-ONLY)
      { economyOverviewModule },
      // Dispatch de Oportunidades
      { dispatchModule },
      // Inbox Social
      { inboxModule },
    ] = await Promise.all([
      import('./src/core/economy/economy.module'),
      import('./src/core/rbac/rbac.module'),
      import('./src/core/config/config.module'),
      import('./src/core/notify/notify.module'),
      import('./src/core/reviews/review.module'),
      import('./src/core/reputation/reputation.module'),
      import('./src/core/core.module'),
      import('./src/core/dashboard/dashboard.module'),
      import('./src/core/economy/fund/fund.module'),
      import('./src/core/categories/categories.module'),
      import('./src/core/profile/profile.module'),
      import('./src/core/companies/companies.module'),
      import('./src/core/publication/publication-engine.module'),
      import('./src/core/referral/referral.module'),
      import('./src/core/plan/plan.module'),
      import('./src/modules/assistant/assistant.module'),
      import('./src/modules/social-actions/social-actions.module'),
      import('./src/modules/work/work.module'),
      import('./src/modules/rides/rides.module'),
      import('./src/modules/social/social.module'),
      import('./src/modules/media/media.module'),
      import('./src/modules/cultural/cultural.module'),
      import('./src/modules/votes/votes.module'),
      // Feed contextual (core)
      import('./src/core/feed/feed.module'),
      // Feed legado (services)
      import('./src/services/feed/feed.module'),
      // Event lifecycle (services)
      import('./src/services/events/event-lifecycle.routes'),
      // Módulos faltantes (reintroduzidos)
      import('./src/core/identity/identity.module'),
      import('./src/core/matching/matching.module'),
      import('./src/core/opportunity/opportunity.module'),
      import('./src/core/unifybank/unifybank.module'),
      import('./src/core/catalog/category-review.module'),
      import('./src/core/checkout/checkout.module'),
      import('./src/modules/events/events.module'),
      import('./src/core/events/event.module'),
      import('./src/core/ai/ai.module'),
      // Trust Dashboard (FASE 10)
      import('./src/core/reputation/trust.routes'),
      // Grupos
      import('./src/modules/groups/groups.module'),
      // Serviços
      import('./src/modules/services/services.module'),
      // Dashboard Econômico (READ-ONLY)
      import('./src/modules/economy/economy.module'),
      // Dispatch de Oportunidades
      import('./src/modules/dispatch/dispatch.module'),
      // Inbox Social
      import('./src/modules/inbox/inbox.module'),
    ]);
    
    // Extrair módulos dos imports individuais
    const availabilityModule = availabilityImport.availabilityModule;
    const unifiedCalendarModule = calendarImport.unifiedCalendarModule;

    await protectedScope.register(economyModule, { prefix: '/economy' });
    await protectedScope.register(rbacModule, { prefix: '/rbac' });
    await protectedScope.register(configModule, { prefix: '/config' });
    await protectedScope.register(notifyModule, { prefix: '/notify' });
    await protectedScope.register(reviewModule, { prefix: '/reviews' });
    await protectedScope.register(reputationModule, { prefix: '/reputation' });
    await protectedScope.register(coreModule, { prefix: '/core' });
    await protectedScope.register(dashboardModule, { prefix: '/dashboard' });
    await protectedScope.register(fundModule, { prefix: '/fund' });
    await protectedScope.register(categoriesModule, { prefix: '/categories' });
    await protectedScope.register(profileModule, { prefix: '/profile' });
    await protectedScope.register(companiesModule, { prefix: '/companies' });
    await protectedScope.register(publicationEngineModule);
    await protectedScope.register(referralModule, { prefix: '/referral' });
    await protectedScope.register(planModule, { prefix: '/plan' });
    await protectedScope.register(assistantModule, { prefix: '/assistant' });
    await protectedScope.register(socialActionsModule, { prefix: '/social-actions' });
    await protectedScope.register(workModule, { prefix: '/work' });
    await protectedScope.register(ridesModule, { prefix: '/rides' });
    await protectedScope.register(socialModule, { prefix: '/social' });
    
    // Rotas de relacionamentos sociais e grupos leves
    const { socialRelationshipsRoutes } = await import('./src/modules/social/social-relationships.routes');
    const { socialGroupsLightRoutes } = await import('./src/modules/social/social-groups-light.routes');
    await protectedScope.register(socialRelationshipsRoutes, { prefix: '/social' });
    await protectedScope.register(socialGroupsLightRoutes, { prefix: '/social/groups-light' });
    await protectedScope.register(mediaModule, { prefix: '/media' });
    await protectedScope.register(culturalModule, { prefix: '/cultural' });
    await protectedScope.register(votesModule, { prefix: '/api' });
    await protectedScope.register(aiModule, { prefix: '/ai' });
    
    // Feed e Eventos (reintroduzidos)
    await protectedScope.register(feedContextualModule, { prefix: '/feed' });
    await protectedScope.register(feedLegacyModule, { prefix: '/api/feed' });
    // 🔴 NOTA: eventLifecycleRoutes e eventsModule ambos usam /api/events
    // eventLifecycleRoutes: rotas de lifecycle (publish, schedule, tickets)
    // eventsModule: rotas principais de CRUD de eventos
    // Ambos podem coexistir se rotas não conflitarem
    await protectedScope.register(eventLifecycleRoutes.default, { prefix: '/api/events' });
    
    // Módulos faltantes (reintroduzidos)
    await protectedScope.register(identityModule, { prefix: '/identity' });
    await protectedScope.register(matchingModule, { prefix: '/matching' });
    await protectedScope.register(opportunityModule, { prefix: '/opportunities' });
    await protectedScope.register(unifybankModule, { prefix: '/bank' });
    await protectedScope.register(unifybankModule, { prefix: '/admin' });
    await protectedScope.register(categoryReviewModule, { prefix: '/admin' });
    
    // Rotas admin SSOT (observabilidade)
    const { default: ssotAdminRoutes } = await import('./src/core/categories/ssot-admin.routes');
    await protectedScope.register(ssotAdminRoutes, { prefix: '/admin/ssot' });
    await protectedScope.register(checkoutModule, { prefix: '/api/checkout' });
    // 🔴 NOTA: eventsModule registrado em /api/events (pode conflitar com eventLifecycleRoutes)
    // Verificar se há rotas duplicadas e consolidar se necessário
    await protectedScope.register(eventsModule, { prefix: '/api/events' });
    await protectedScope.register(eventModule, { prefix: '/api/events' });
    // Trust Dashboard (FASE 10)
    await protectedScope.register(trustModule.default, { prefix: '/api/trust' });
    // Grupos
    await protectedScope.register(groupsModule, { prefix: '/groups' });
    // Serviços
    await protectedScope.register(servicesModule, { prefix: '/services' });
    // Human MVP
    const { default: humanMvpRoutes } = await import('./src/modules/human-mvp/human-mvp.routes');
    await protectedScope.register(humanMvpRoutes, { prefix: '/human-mvp' });
    protectedScope.log.info('[BOOT] Human MVP Routes registrado: /human-mvp');
    
    // Mensageria Contextual
    const contextualMessagingModule = await import('./src/modules/contextual-messaging/contextual-messaging.module');
    await protectedScope.register(contextualMessagingModule.default);

    // Negociação Assistida e Registro de Acordos
    const agreementsModule = await import('./src/modules/agreements/agreements.module');
    await protectedScope.register(agreementsModule.default);

    // Evidências & Resolução de Disputas
    const evidenceModule = await import('./src/modules/evidence/evidence.module');
    await protectedScope.register(evidenceModule.default);

    // Pagamentos com Escrow e Marcos de Execução
    const escrowModule = await import('./src/modules/escrow/escrow.module');
    await protectedScope.register(escrowModule.default);

    // Trust & Integrity Engine
    // trustModule já foi importado e registrado anteriormente na linha 455 com prefixo '/api/trust'

    // Ledger Contábil Canônico
    const ledgerModule = await import('./src/modules/ledger/ledger.module');
    await protectedScope.register(ledgerModule.default);

    // Payout Engine
    const payoutModule = await import('./src/modules/payout/payout.module');
    await protectedScope.register(payoutModule.default);

    // Invoice Engine
    const invoiceModule = await import('./src/modules/invoicing/invoice.module');
    await protectedScope.register(invoiceModule.default);

    // Reporting Institucional
    const reportingModule = await import('./src/modules/reporting/reporting.module');
    await protectedScope.register(reportingModule.default);

    // Risk & Trust Command Center
    const riskCommandCenterModule = await import('./src/modules/risk-command-center/risk-command-center.module');
    await protectedScope.register(riskCommandCenterModule.default);

    // Policy & Enforcement Engine
    const policyEngineModule = await import('./src/modules/policy-engine/policy-engine.module');
    await protectedScope.register(policyEngineModule.default);

    // My Orders & Purchases Hub
    const myOrdersModule = await import('./src/modules/my-orders/my-orders.module');
    await protectedScope.register(myOrdersModule.default);
    console.log('[BOOT] Contextual Messaging module registered');
    
    // Notificações In-App
    const systemNotificationsModule = await import('./src/modules/system-notifications/system-notifications.module');
    await protectedScope.register(systemNotificationsModule.default);
    console.log('[BOOT] System Notifications module registered');
    
    // Auditoria de Negócio
    const businessAuditModule = await import('./src/modules/business-audit/business-audit.module');
    await protectedScope.register(businessAuditModule.default);
    console.log('[BOOT] Business Audit module registered');
    
    // Autorização de Negócio
    const businessAuthorizationModule = await import('./src/core/authorization/business-authorization.module');
    await protectedScope.register(businessAuthorizationModule.default);
    console.log('[BOOT] Business Authorization module registered');
    // Dashboard Econômico (READ-ONLY)
    await protectedScope.register(economyOverviewModule, { prefix: '/economy' });
    // Dispatch de Oportunidades
    await protectedScope.register(dispatchModule, { prefix: '/dispatch' });
    // Inbox Social
    await protectedScope.register(inboxModule, { prefix: '/inbox' });
    // Unified Availability Core
    await protectedScope.register(availabilityModule, { prefix: '/availability' });
    // Unified Calendar
    await protectedScope.register(unifiedCalendarModule);
    // Compatibility Engine
    const compatibilityModule = await import('./src/core/compatibility/compatibility.module');
    await protectedScope.register(compatibilityModule.default);
    console.log('[BOOT] Compatibility module registered');
    // SPRINT 13: Piloto Controlado & Observação Silenciosa
    const pilotEventsModule = await import('./src/core/pilot/pilot-events.routes');
    await protectedScope.register(pilotEventsModule.default, { prefix: '/admin/pilot' });
    // SPRINT 14: Piloto Humano Controlado - Convites
    const pilotInvitesModule = await import('./src/core/pilot/pilot-invites.routes');
    await protectedScope.register(pilotInvitesModule.default, { prefix: '/admin/pilot' });
    // SPRINT 15: Piloto Vivo - Observação Humana
    const pilotHumanObservationModule = await import('./src/core/pilot/pilot-human-observation.routes');
    await protectedScope.register(pilotHumanObservationModule.default, { prefix: '/admin/pilot' });
    // SPRINT 26: Memória Institucional Declarativa
    const institutionalMemoryModule = await import('./src/core/pilot/institutional-memory.routes');
    await protectedScope.register(institutionalMemoryModule.default, { prefix: '/admin/pilot' });
    // SPRINT 41.1: Marketplace Operável
    // ORDEM: Após RBAC Guards (linha 277), após rotas públicas (linha 224)
    try {
      const marketplaceModule = await import('./src/modules/marketplace/marketplace.routes');
      await protectedScope.register(marketplaceModule.default, { prefix: '/marketplace' });
      
      // Marketplace Categories (canônico, consome CORE)
      const marketplaceCategoriesRoutes = await import('./src/modules/marketplace/marketplace-categories.routes');
      await protectedScope.register(marketplaceCategoriesRoutes.default);
      
      // Marketplace Search (ranking determinístico)
      const marketplaceSearchRoutes = await import('./src/modules/marketplace/marketplace-search.routes');
      await protectedScope.register(marketplaceSearchRoutes.default);
      
      // Marketplace Store Onboarding
      const storeOnboardingRoutes = await import('./src/modules/marketplace/store-onboarding.routes');
      await protectedScope.register(storeOnboardingRoutes.default);
      console.log('[BOOT] ✅ Marketplace rotas protegidas registradas: /marketplace (orders, payments, delivery, pdv)');
    } catch (err) {
      console.error('[BOOT] ❌ ERRO FATAL: Falha ao registrar Marketplace rotas protegidas');
      console.error(err);
      throw err; // Fail fast - Marketplace é crítico
    }
    // SPRINT 42.1: PDV Core
    const pdvModule = await import('./src/modules/pdv/pdv.routes');
    await protectedScope.register(pdvModule.default, { prefix: '/pdv' });
    console.log('[BOOT] PDV module registered: /pdv');
    // SPRINT 46: Relatórios Operacionais
    const reportsModule = await import('./src/modules/reports/reports.routes');
    await protectedScope.register(reportsModule.default, { prefix: '/reports' });
    console.log('[BOOT] Reports module registered: /reports');
    // SPRINT 50: Automações Operacionais
    const automationModule = await import('./src/modules/automation/automation.routes');
    await protectedScope.register(automationModule.default, { prefix: '/automation' });
    console.log('[BOOT] Automation module registered: /automation');
    // SPRINT 51: Multi-empresa, Filiais e Consolidação
    const organizationModule = await import('./src/modules/organization/organization.routes');
    await protectedScope.register(organizationModule.default, { prefix: '/organization' });
    console.log('[BOOT] Organization module registered: /organization');
    // SPRINT 79: Páginas Públicas
    const publicProfileModule = await import('./src/modules/public-profiles/public-profile.routes');
    await protectedScope.register(publicProfileModule.default);
    console.log('[BOOT] Public Profiles module registered: /public-profiles');
    
    console.log('[BOOT] Todos os módulos protegidos registrados');
  });
  
  console.log('[BOOT] buildApp() concluído com sucesso');
  return app;
}

// ─────────────────────────────────────────────────────────────
// FUNÇÃO AUXILIAR: Verificar se porta está em uso
// ─────────────────────────────────────────────────────────────
async function checkPortInUse(port: number, host: string): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    
    server.once('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') {
        resolve(true); // Porta está em uso
      } else {
        resolve(false); // Outro erro, assumir que porta está livre
      }
    });
    
    server.once('listening', () => {
      server.close();
      resolve(false); // Porta está livre
    });
    
    server.listen(port, host);
  });
}

// ─────────────────────────────────────────────────────────────
// START SERVER (BOOTSTRAP LINEAR E SEGURO)
// ─────────────────────────────────────────────────────────────
export async function startServer(): Promise<void> {
  console.log('🚀 [BOOT] starting server');
  console.log(`[BOOT] Porta configurada: ${PORT}`);
  console.log(`[BOOT] Host configurado: ${HOST}`);

  // Schema Guard: Valida schema mínimo ANTES de iniciar servidor
  const { validateSchemaOrDie } = await import('./src/core/db/schema-guard');
  await validateSchemaOrDie();

  // Import dinâmico do DB (NUNCA no topo)
  const { getDatabaseInfo, logDatabaseConnectionInfo } =
    await import('./src/core/database/pool');

  logDatabaseConnectionInfo();

  try {
    await Promise.race([
      getDatabaseInfo(),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('DB timeout (5s)')), 5000)
      ),
    ]);
  } catch (err) {
    console.warn('⚠️ [BOOT] DB indisponível (não bloqueante):', err);
  }

  console.log('[BOOT] Construindo aplicação Fastify...');
  const app = await buildApp();
  console.log('[BOOT] Aplicação Fastify construída com sucesso');

  // Registrar handlers de eventos SOMENTE AGORA
  try {
    const { registerCoreHandlers } =
      await import('./src/core/events/register-handlers');
    await registerCoreHandlers();
    console.log('[BOOT] Handlers de eventos registrados');
  } catch (err) {
    console.warn('[BOOT] Aviso: Erro ao registrar handlers de eventos (não bloqueante):', err);
  }

  // Verificar se a porta está ocupada ANTES de tentar iniciar o servidor
  console.log(`[BOOT] Verificando disponibilidade da porta ${PORT}...`);
  const isPortInUse = await checkPortInUse(PORT, HOST);
  if (isPortInUse) {
    const errorMsg = [
      '='.repeat(60),
      '❌ ERRO FATAL: Porta já está em uso',
      '='.repeat(60),
      `Porta configurada: ${PORT}`,
      `Host: ${HOST}`,
      '',
      'AÇÃO REQUERIDA:',
      '  1. Encerre o processo que está usando a porta, OU',
      '  2. Defina outra porta via variável de ambiente PORT',
      '',
      'Para identificar o processo que usa a porta:',
      `  Windows: netstat -ano | findstr :${PORT}`,
      `  Linux/Mac: lsof -i :${PORT} ou netstat -tulpn | grep :${PORT}`,
      '='.repeat(60),
    ].join('\n');
    console.error(errorMsg);
    throw new Error(`Porta ${PORT} já está em uso. Encerre o processo que usa a porta ou defina outra PORT.`);
  }
  console.log(`[BOOT] Porta ${PORT} disponível`);

  console.log(`[BOOT] Iniciando servidor HTTP na porta ${PORT}, host ${HOST}...`);
  try {
    const address = await app.listen({ port: PORT, host: HOST });
    console.log(`[BOOT] Servidor HTTP iniciado com sucesso: ${address}`);
  } catch (err: any) {
    // Se ainda assim ocorrer EADDRINUSE (race condition), tratar explicitamente
    if (err.code === 'EADDRINUSE') {
      const errorMsg = [
        '='.repeat(60),
        '❌ ERRO FATAL: Porta já está em uso (EADDRINUSE)',
        '='.repeat(60),
        `Porta configurada: ${PORT}`,
        `Host: ${HOST}`,
        '',
        'AÇÃO REQUERIDA:',
        '  1. Encerre o processo que está usando a porta, OU',
        '  2. Defina outra porta via variável de ambiente PORT',
        '',
        'Para identificar o processo que usa a porta:',
        `  Windows: netstat -ano | findstr :${PORT}`,
        `  Linux/Mac: lsof -i :${PORT} ou netstat -tulpn | grep :${PORT}`,
        '='.repeat(60),
      ].join('\n');
      console.error(errorMsg);
      throw new Error(`Porta ${PORT} já está em uso (EADDRINUSE). Encerre o processo que usa a porta ou defina outra PORT.`);
    }
    console.error('❌ [BOOT] ERRO FATAL ao iniciar servidor HTTP:', err);
    throw err;
  }

  console.log('='.repeat(60));
  console.log('✅ SERVIDOR INICIADO COM SUCESSO');
  console.log('='.repeat(60));
  console.log(`[BOOT] PID: ${process.pid}`);
  console.log(`[BOOT] URL: http://localhost:${PORT}`);
  console.log(`[BOOT] HEALTH: http://localhost:${PORT}/health`);
  console.log(`[BOOT] AUTH: http://localhost:${PORT}/auth/login`);
  console.log(`[BOOT] Servidor escutando na porta ${PORT}`);
  console.log('='.repeat(60));
}

// ─────────────────────────────────────────────────────────────
// ENTRYPOINT (ÚNICO PONTO DE EXECUÇÃO)
// ─────────────────────────────────────────────────────────────
console.log('='.repeat(60));
console.log('🚀 INICIANDO BACKEND UNIFICARD');
console.log('='.repeat(60));
console.log(`[BOOT] Node version: ${process.version}`);
console.log(`[BOOT] NODE_ENV: ${process.env.NODE_ENV || 'development'}`);
console.log(`[BOOT] PID: ${process.pid}`);
console.log('='.repeat(60));

startServer().catch((err) => {
  console.error('='.repeat(60));
  console.error('❌ [BOOT] ERRO FATAL ao iniciar servidor:');
  console.error('='.repeat(60));
  console.error(err);
  console.error('='.repeat(60));
  process.exit(1);
});
