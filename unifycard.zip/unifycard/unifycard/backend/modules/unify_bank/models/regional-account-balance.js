// /backend/modules/unifybank/models/regional-account-balance.js

module.exports = (sequelize, DataTypes) => {
  const RegionalAccountBalance = sequelize.define('RegionalAccountBalance', {
    regional_account_id: {
      type: DataTypes.UUID,
      primaryKey: true,
    },
    balance: {
      type: DataTypes.DECIMAL(18, 2),
      defaultValue: 0,
    },
    last_updated: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  }, {
    tableName: 'regional_account_balance',
    timestamps: false,
  });

  RegionalAccountBalance.associate = (models) => {
    RegionalAccountBalance.belongsTo(models.RegionalAccount, { foreignKey: 'regional_account_id' });
  };

  return RegionalAccountBalance;
};
