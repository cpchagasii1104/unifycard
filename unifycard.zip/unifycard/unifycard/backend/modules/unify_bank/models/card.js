// /backend/modules/unifybank/models/card.js

module.exports = (sequelize, DataTypes) => {
  const Card = sequelize.define('Card', {
    card_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'active',
    },
    created_at: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  }, {
    tableName: 'card',
    timestamps: false,
  });

  Card.associate = (models) => {
    Card.belongsTo(models.User, { foreignKey: 'user_id' });
  };

  return Card;
};
