// /backend/modules/unify_bank/repositories/unify-bank-repository.js

const db = require('../../../config/db');

/**
 * Repositório para manipulação da conta UnifyBank do usuário.
 */
const unifyBankRepository = {
  /**
   * Cria a conta UnifyBank para o usuário dentro de uma transação existente.
   * @param {Object} client - Instância do client do pool do PostgreSQL
   * @param {UUID} user_id
   * @param {UUID} regional_account_id
   * @returns {Promise<void>}
   */
  async createUnifyBankAccountWithClient(client, user_id, regional_account_id) {
    const query = `
      INSERT INTO unify_bank_account (user_id, regional_account_id, balance)
      VALUES ($1, $2, 0)
    `;
    await client.query(query, [user_id, regional_account_id]);
  },
};

module.exports = unifyBankRepository;

