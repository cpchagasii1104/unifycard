// /backend/modules/unify_bank/repositories/card-repository.js

const db = require('../../../config/db');

/**
 * Repositório para manipulação do cartão UnifyCard do usuário.
 */
const cardRepository = {
  /**
   * Cria o cartão UnifyCard para o usuário dentro de uma transação.
   * @param {Object} client - Instância do client do PostgreSQL
   * @param {UUID} user_id
   * @returns {Promise<void>}
   */
  async createCard(client, user_id) {
    const query = `
      INSERT INTO card (user_id, status)
      VALUES ($1, 'active')
    `;
    await client.query(query, [user_id]);
  },
};

module.exports = cardRepository;

