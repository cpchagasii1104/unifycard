// /backend/modules/unify_bank/routes/unifybank-routes.js

const express = require('express');
const router = express.Router();

// Placeholder para futuras rotas de UnifyBank
router.get('/unifybank/test', (req, res) => {
  res.json({ message: 'Rota de UnifyBank funcionando!' });
});

module.exports = router;
