'use strict';

const db = require('../../../database');
const {
  Product,
  ProductCategory,
  ProductImage,
  ProductStock,
  ProductPriceHistory,
  Company,
} = db;

const createProduct = async (userId, data) => {
  return await db.sequelize.transaction(async (t) => {
    const product = await Product.create({
      companyId: data.companyId,
      categoryId: data.categoryId,
      name: data.name,
      description: data.description,
      price: data.price,
      currency: data.currency || 'BRL',
      tags: data.tags || [],
      isVisible: data.isVisible ?? true,
    }, { transaction: t });

    await ProductStock.create({
      productId: product.productId,
      quantity: data.quantity || 0,
      reserved: 0,
      minimum: data.minimum || 0,
    }, { transaction: t });

    await ProductPriceHistory.create({
      productId: product.productId,
      oldPrice: 0,
      newPrice: product.price,
      currency: product.currency,
      changeType: 'manual',
      updatedBy: userId,
    }, { transaction: t });

    return product;
  });
};

const listProducts = async (companyId, filters = {}) => {
  const where = { companyId };

  if (filters.categoryId) {
    where.categoryId = filters.categoryId;
  }

  if (filters.search) {
    where.name = { [db.Sequelize.Op.iLike]: `%${filters.search}%` };
  }

  return await Product.findAll({
    where,
    include: [
      { model: ProductCategory, as: 'category' },
      { model: ProductImage, as: 'images' },
      { model: ProductStock, as: 'stock' },
    ],
    order: [['createdAt', 'DESC']],
  });
};

const getProductById = async (productId) => {
  return await Product.findByPk(productId, {
    include: [
      { model: ProductCategory, as: 'category' },
      { model: ProductImage, as: 'images' },
      { model: ProductStock, as: 'stock' },
      { model: ProductPriceHistory, as: 'priceHistory' },
    ],
  });
};

const updateProduct = async (productId, updates) => {
  const product = await Product.findByPk(productId);
  if (!product) throw new Error('Product not found');
  return await product.update(updates);
};

const deleteProduct = async (productId) => {
  const product = await Product.findByPk(productId);
  if (!product) throw new Error('Product not found');
  return await product.destroy();
};

const addProductImage = async (productId, imageData) => {
  return await ProductImage.create({
    productId,
    imageUrl: imageData.imageUrl,
    description: imageData.description,
    isPrimary: imageData.isPrimary ?? false,
    sortOrder: imageData.sortOrder ?? 0,
  });
};

const registerPriceChange = async (productId, newPrice, changeType, userId) => {
  const product = await Product.findByPk(productId);
  if (!product) throw new Error('Product not found');

  await ProductPriceHistory.create({
    productId,
    oldPrice: product.price,
    newPrice,
    currency: product.currency,
    changeType,
    updatedBy: userId,
  });

  product.price = newPrice;
  return await product.save();
};

module.exports = {
  createProduct,
  listProducts,
  getProductById,
  updateProduct,
  deleteProduct,
  addProductImage,
  registerPriceChange,
};
