const db = require('../../../config/db');

const getSectors = async (req, res) => {
  try {
    const query = 'SELECT code, label_pt, label_en FROM profession_sector ORDER BY label_pt';
    const result = await db.query(query);
    return res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar setores:', err);
    return res.status(500).json({ message: 'Erro ao buscar setores.' });
  }
};

const getAreasBySector = async (req, res) => {
  try {
    const { sector } = req.query;
    if (!sector) return res.status(400).json({ message: 'Setor ausente na query.' });

    const query = `
      SELECT area_code, label_pt, label_en 
      FROM profession_area 
      WHERE sector_code = $1 
      ORDER BY label_pt
    `;
    const result = await db.query(query, [sector]);
    return res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar áreas:', err);
    return res.status(500).json({ message: 'Erro ao buscar áreas.' });
  }
};

const getFunctionsByArea = async (req, res) => {
  try {
    const { area } = req.query;
    if (!area) return res.status(400).json({ message: 'Área ausente na query.' });

    const query = `
      SELECT function_code, label_pt, label_en 
      FROM profession_function 
      WHERE area_code = $1 
      ORDER BY label_pt
    `;
    const result = await db.query(query, [area]);
    return res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar funções:', err);
    return res.status(500).json({ message: 'Erro ao buscar funções.' });
  }
};

module.exports = {
  getSectors,
  getAreasBySector,
  getFunctionsByArea,
};
