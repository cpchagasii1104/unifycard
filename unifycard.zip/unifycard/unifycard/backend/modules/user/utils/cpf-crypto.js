const crypto = require('crypto');

// ATENÇÃO: Defina CPF_SECRET_KEY no .env como uma chave forte de 32 bytes em HEXADECIMAL!
// Exemplo de geração: require('crypto').randomBytes(32).toString('hex')
// Exemplo no .env: CPF_SECRET_KEY=ef4d2f630d62e59e2e3c1a2b997c3765d47251e360cc5c58e58d7ec3be2a458b

const ENCRYPTION_KEY = Buffer.from(process.env.CPF_SECRET_KEY, 'hex'); // 32 bytes em hexadecimal
const IV_LENGTH = 16;

function encryptCPF(cpf) {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(cpf, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return iv.toString('base64') + ':' + encrypted;
}

function decryptCPF(cipherText) {
  const encrypted = Buffer.isBuffer(cipherText) ? cipherText.toString() : cipherText;
  const parts = encrypted.split(':');
  const iv = Buffer.from(parts[0], 'base64');
  const encryptedCPF = parts[1];
  const decipher = crypto.createDecipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let decrypted = decipher.update(encryptedCPF, 'base64', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

function maskCPF(cpf) {
  if (!cpf || cpf.length !== 11) return cpf;
  return `${cpf.slice(0, 3)}.${cpf.slice(3, 6)}.***-${cpf.slice(9, 11)}`;
}

module.exports = { encryptCPF, decryptCPF, maskCPF };
