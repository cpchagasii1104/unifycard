// /backend/modules/user/schemas/login-schema.js

const Joi = require('joi');

/**
 * Esquema de validação para login de usuário
 */
const loginSchema = Joi.object({
  email: Joi.string().email().required().max(255),
  password: Joi.string().min(8).max(128).required(),
});

/**
 * Função utilitária para validar input de login
 * @param {Object} data
 * @returns {Object} { error, value }
 */
function validateLogin(data) {
  return loginSchema.validate(data, { abortEarly: false });
}

module.exports = {
  loginSchema,
  validateLogin
};
