const Joi = require('joi');

// Expressão regular para formato de data YYYY-MM-DD (evita conversão automática do Joi)
const isoDateRegex = /^\d{4}-\d{2}-\d{2}$/;

const signupSchema = Joi.object({
  first_name: Joi.string().min(2).max(150).required(),
  last_name: Joi.string().min(2).max(150).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(255).required(),
  cpf: Joi.string().length(11).required(),

  phone_country: Joi.string().min(1).max(10).required(),
  phone: Joi.string().min(8).max(20).required(),

  biological_sex: Joi.string().valid('male', 'female').required(),

  gender_identity: Joi.string()
    .valid(
      'male',
      'female',
      'non_binary',
      'trans_woman',
      'trans_man',
      'travesti',
      'agender',
      'genderfluid',
      'other',
      'prefer_not_to_say'
    )
    .optional()
    .allow(null, ''),

  profession: Joi.string().max(255).optional().allow(null, ''),

  birth_date: Joi.string().pattern(isoDateRegex).required()
    .messages({
      'string.pattern.base': 'birth_date deve estar no formato YYYY-MM-DD',
    }),

  cep: Joi.string().length(8).required(),
  street: Joi.string().min(2).max(255).required(),
  number: Joi.string().min(1).max(20).required(),
  complement: Joi.string().max(255).optional().allow(null, ''),

  country: Joi.string().min(2).max(100).required(),

  referral_code: Joi.string().alphanum().max(10).optional().allow('', null),

  consent_at: Joi.date().iso().optional().allow(null),

  function_codes: Joi.array().items(Joi.string()).optional().allow(null)
});

module.exports = {
  validateSignup: (data) => signupSchema.validate(data, { abortEarly: false }),
};
