'use strict';

const db = require('../../../config/db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { encryptCPF, decryptCPF } = require('../utils/cpf-crypto');
const unifyBankRepository = require('../../unify_bank/repositories/unify-bank-repository');
const cardRepository = require('../../unify_bank/repositories/card-repository');

function generateReferralCode(length = 7) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function maskCpf(cpf) {
  if (!cpf || cpf.length !== 11) return cpf;
  return `${cpf.slice(0, 3)}.${cpf.slice(3, 6)}.***-${cpf.slice(9, 11)}`;
}

class UserService {
  async createUser(userData) {
    const client = await db.connect();
    try {
      await client.query('BEGIN');

      const {
        email, password, cpf, first_name, last_name, birth_date,
        phone, phone_country, biological_sex, gender_identity,
        street, number, complement, cep, country, referral_code,
        function_codes, consent_at, password_hash: preHashedPassword
      } = userData;

      const encryptedCPF = encryptCPF(cpf);
      const password_hash = preHashedPassword || await bcrypt.hash(password, 10);
      const finalReferralCode = generateReferralCode();

      const insertUser = `
        INSERT INTO "user" (email, password_hash, phone, created_at, consent_at, generated_referral_code)
        VALUES ($1, $2, $3, now(), $4, $5)
        RETURNING user_id
      `;
      const { rows } = await client.query(insertUser, [
        email, password_hash, phone, consent_at, finalReferralCode
      ]);
      const user_id = rows[0].user_id;

      const cepQuery = `
        SELECT acr.neighborhood_id, n.city_id, c.state_id, ra.regional_account_id
        FROM address_cep_range acr
        JOIN neighborhood n ON acr.neighborhood_id = n.neighborhood_id
        JOIN city c ON n.city_id = c.city_id
        JOIN regional_account ra ON ra.neighborhood_id = n.neighborhood_id
        WHERE $1 BETWEEN cep_start AND cep_end
        LIMIT 1
      `;
      const result = await client.query(cepQuery, [cep]);
      if (result.rows.length === 0) throw new Error('CEP não encontrado ou região não atendida.');
      const { neighborhood_id, city_id, state_id, regional_account_id } = result.rows[0];

      let referrer_profile_id = null;
      if (referral_code && referral_code.trim()) {
        const checkReferrer = `
          SELECT user_profile_id FROM user_profile WHERE referral_code = $1 LIMIT 1
        `;
        const refResult = await client.query(checkReferrer, [referral_code.trim()]);
        if (refResult.rows.length > 0) {
          referrer_profile_id = refResult.rows[0].user_profile_id;
        }
      }

      const insertProfile = `
        INSERT INTO user_profile (
          user_id, regional_account_id, first_name, last_name, cpf, birth_date,
          phone, biological_sex, gender_identity, neighborhood_id, city_id, state_id, cep,
          referral_code, referrer_profile_id, street, number, complement
        ) VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10, $11, $12, $13,
          $14, $15, $16, $17, $18
        )
        RETURNING user_profile_id
      `;
      const profileValues = [
        user_id, regional_account_id, first_name, last_name, encryptedCPF, birth_date,
        phone, biological_sex, gender_identity, neighborhood_id, city_id, state_id, cep,
        finalReferralCode, referrer_profile_id, street, number, complement
      ];
      const profileResult = await client.query(insertProfile, profileValues);
      const user_profile_id = profileResult.rows[0].user_profile_id;

      if (Array.isArray(function_codes) && function_codes.length > 0) {
        const insertFunctions = `
          INSERT INTO user_profession_function (user_profile_id, function_code)
          VALUES ${function_codes.map((_, i) => `($1, $${i + 2})`).join(', ')}
          ON CONFLICT DO NOTHING
        `;
        const values = [user_profile_id, ...function_codes];
        await client.query(insertFunctions, values);
      }

      await unifyBankRepository.createUnifyBankAccountWithClient(client, user_id, regional_account_id);
      await cardRepository.createCard(client, user_id);

      await client.query('COMMIT');
      return { user_id, user_profile_id, referral_code: finalReferralCode };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  async loginUser(loginData) {
    const query = `
      SELECT user_id, email, password_hash, created_at
      FROM "user"
      WHERE LOWER(email) = LOWER($1) AND deleted_at IS NULL
      LIMIT 1
    `;
    const result = await db.query(query, [loginData.email]);
    const user = result.rows?.[0];
    if (!user) throw Object.assign(new Error('Invalid credentials'), { code: 'INVALID_CREDENTIALS' });

    const isMatch = await bcrypt.compare(loginData.password, user.password_hash);
    if (!isMatch) throw Object.assign(new Error('Invalid credentials'), { code: 'INVALID_CREDENTIALS' });

    const payload = { id: user.user_id, email: user.email };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '12h' });

    return {
      user: { user_id: user.user_id, email: user.email, created_at: user.created_at },
      token,
    };
  }

  async getUserProfileWithAddress(userId) {
    const query = `
      SELECT 
        u.email,
        up.*,
        n.name AS neighborhood,
        c.name AS city_name,
        s.name AS state_name,
        ra.regional_account_id,
        uba.unify_bank_account_id,
        ca.card_id
      FROM "user" u
      JOIN user_profile up ON u.user_id = up.user_id
      LEFT JOIN neighborhood n ON up.neighborhood_id = n.neighborhood_id
      LEFT JOIN city c ON up.city_id = c.city_id
      LEFT JOIN state s ON up.state_id = s.state_id
      LEFT JOIN regional_account ra ON up.regional_account_id = ra.regional_account_id
      LEFT JOIN unify_bank_account uba ON uba.user_id = u.user_id
      LEFT JOIN card ca ON ca.user_id = u.user_id
      WHERE u.user_id = $1
      LIMIT 1
    `;
    const result = await db.query(query, [userId]);
    if (result.rows.length === 0) throw new Error('Perfil não encontrado para o usuário.');

    const profile = result.rows[0];
    const decryptedCPF = decryptCPF(profile.cpf || '');
    profile.cpf = decryptedCPF;
    profile.masked_cpf = decryptedCPF
      ? decryptedCPF.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.***-$4')
      : null;

    const [functionsResult, hobbiesResult] = await Promise.all([
      db.query('SELECT function_code FROM user_profession_function WHERE user_profile_id = $1', [profile.user_profile_id]),
      // A tabela correta de vínculo usuário ↔ hobby é user_hobby
      db.query('SELECT hobby_code FROM user_hobby WHERE user_profile_id = $1', [profile.user_profile_id])
    ]);

    profile.function_codes = functionsResult.rows.map(row => row.function_code);
    profile.hobby_codes = hobbiesResult.rows.map(row => row.hobby_code);

    return profile;
  }

  async updateUserProfile(userProfileId, payload) {
    // Campos do user_profile que podem ser atualizados. Inclui dados pessoais, profissionais
    // e informações adicionais (residência, família, acessibilidade, etc.).
    // Sanitizar valores: converter strings vazias em NULL para campos booleanos e numéricos;
    // e serializar arrays/objetos JSON para string JSON onde necessário.
    const sanitizedPayload = { ...payload };
    const booleanFields = [
      'receives_social_benefit', 'has_disability', 'need_accessibility',
      'is_caregiver', 'has_animals', 'has_children'
    ];
    booleanFields.forEach((field) => {
      if (sanitizedPayload[field] === '') {
        sanitizedPayload[field] = null;
      }
    });
    const numberFields = [
      'residents', 'dependents_count', 'height_cm', 'weight_kg', 'children_count'
    ];
    numberFields.forEach((field) => {
      if (sanitizedPayload[field] === '') {
        sanitizedPayload[field] = null;
      }
    });
    const jsonFields = [
      'academic_degrees', 'completed_courses', 'certifications',
      'languages_spoken', 'available_periods', 'children_ages'
    ];
    jsonFields.forEach((field) => {
      if (sanitizedPayload[field] !== undefined && sanitizedPayload[field] !== null) {
        try {
          sanitizedPayload[field] = JSON.stringify(sanitizedPayload[field]);
        } catch (_) {
          // Se não for serializável, ignora a conversão
        }
      }
    });

    const fields = [
      'birth_date', 'phone', 'biological_sex', 'gender_identity',
      'street', 'number', 'complement', 'cep', 'preferences',
      // Campos de educação e carreira
      'education_level', 'academic_degrees', 'completed_courses', 'certifications', 'occupation', 'employment_type', 'monthly_income_range',
      // Situação residencial e familiar
      'housing_situation', 'residents', 'dependents_count',
      // Benefícios e acessibilidade
      'receives_social_benefit', 'social_benefit_details', 'has_disability', 'disability_details', 'need_accessibility',
      // Outras características
      'languages_spoken', 'has_transport', 'is_caregiver', 'has_animals', 'available_periods',
      // Dados de saúde e crianças
      'height_cm', 'weight_kg', 'has_children', 'children_count', 'children_ages'
    ];
    const updates = [];
    const values = [];

    fields.forEach((field) => {
      if (sanitizedPayload[field] !== undefined) {
        updates.push(`${field} = $${values.length + 1}`);
        values.push(sanitizedPayload[field]);
      }
    });

    if (updates.length > 0) {
      const updateQuery = `UPDATE user_profile SET ${updates.join(', ')} WHERE user_profile_id = $${values.length + 1}`;
      values.push(userProfileId);
      await db.query(updateQuery, values);
    }

    await db.query('DELETE FROM user_profession_function WHERE user_profile_id = $1', [userProfileId]);
    if (Array.isArray(payload.function_codes)) {
      for (const code of payload.function_codes) {
        await db.query('INSERT INTO user_profession_function (user_profile_id, function_code) VALUES ($1, $2)', [userProfileId, code]);
      }
    }

    // Atualiza hobbies usando a tabela correta (user_hobby)
    await db.query('DELETE FROM user_hobby WHERE user_profile_id = $1', [userProfileId]);
    if (Array.isArray(payload.hobby_codes)) {
      for (const code of payload.hobby_codes) {
        await db.query('INSERT INTO user_hobby (user_profile_id, hobby_code) VALUES ($1, $2)', [userProfileId, code]);
      }
    }

    // Retorna o perfil atualizado via ID de perfil
    return this.getUserProfileById(userProfileId);
  }

  /**
   * Recupera o perfil completo a partir do user_profile_id, com dados de endereço
   * e listas de funções e hobbies. Usado após atualizar perfil.
   * @param {string} userProfileId
   */
  async getUserProfileById(userProfileId) {
    const query = `
      SELECT 
        u.email,
        up.*,
        n.name AS neighborhood,
        c.name AS city_name,
        s.name AS state_name,
        ra.regional_account_id,
        uba.unify_bank_account_id,
        ca.card_id
      FROM user_profile up
      JOIN "user" u ON u.user_id = up.user_id
      LEFT JOIN neighborhood n ON up.neighborhood_id = n.neighborhood_id
      LEFT JOIN city c ON up.city_id = c.city_id
      LEFT JOIN state s ON up.state_id = s.state_id
      LEFT JOIN regional_account ra ON up.regional_account_id = ra.regional_account_id
      LEFT JOIN unify_bank_account uba ON uba.user_id = u.user_id
      LEFT JOIN card ca ON ca.user_id = u.user_id
      WHERE up.user_profile_id = $1
      LIMIT 1
    `;
    const result = await db.query(query, [userProfileId]);
    if (result.rows.length === 0) {
      throw new Error('Perfil não encontrado.');
    }
    const profile = result.rows[0];
    // Descriptografar CPF e criar máscara
    const decryptedCPF = decryptCPF(profile.cpf || '');
    profile.cpf = decryptedCPF;
    profile.masked_cpf = decryptedCPF
      ? decryptedCPF.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.***-$4')
      : null;
    // Recuperar funções e hobbies
    const [functionsResult, hobbiesResult] = await Promise.all([
      db.query('SELECT function_code FROM user_profession_function WHERE user_profile_id = $1', [profile.user_profile_id]),
      db.query('SELECT hobby_code FROM user_hobby WHERE user_profile_id = $1', [profile.user_profile_id])
    ]);
    profile.function_codes = functionsResult.rows.map(row => row.function_code);
    profile.hobby_codes = hobbiesResult.rows.map(row => row.hobby_code);
    return profile;
  }
}

module.exports = new UserService();
