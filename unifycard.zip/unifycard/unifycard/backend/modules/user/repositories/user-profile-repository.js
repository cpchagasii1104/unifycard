const db = require('../../../config/db');
const { QueryTypes } = require('sequelize');

const userProfileRepository = {
  async findByCPF(encryptedCpf) {
    const result = await db.query(
      'SELECT * FROM user_profile WHERE cpf = $1 AND deleted_at IS NULL LIMIT 1',
      {
        bind: [encryptedCpf],
        type: QueryTypes.SELECT,
      }
    );
    return result[0] || null;
  },

  async create(userProfileData, options = {}) {
    const result = await db.query(
      `INSERT INTO user_profile 
        (user_id, first_name, last_name, cpf, birth_date, phone, biological_sex,
         neighborhood_id, city_id, state_id, cep, regional_account_id, profile_status,
         referral_code, street, number, complement)
       VALUES 
        ($1, $2, $3, $4, $5, $6, $7,
         $8, $9, $10, $11, $12, $13,
         $14, $15, $16, $17)
       RETURNING *`,
      {
        bind: [
          userProfileData.user_id,
          userProfileData.first_name,
          userProfileData.last_name,
          userProfileData.cpf,
          userProfileData.birth_date,
          userProfileData.phone,
          userProfileData.biological_sex,
          userProfileData.neighborhood_id,
          userProfileData.city_id,
          userProfileData.state_id,
          userProfileData.cep,
          userProfileData.regional_account_id,
          userProfileData.profile_status,
          userProfileData.referral_code,
          userProfileData.street,
          userProfileData.number,
          userProfileData.complement
        ],
        type: QueryTypes.INSERT,
        transaction: options.transaction,
      }
    );
    return result[0][0];
  },

  async update(profileId, data) {
    const fields = Object.keys(data);
    if (fields.length === 0) {
      throw new Error('Nenhum campo fornecido para atualização.');
    }

    const setClause = fields.map((field, index) => `${field} = $${index + 1}`).join(', ');
    const values = fields.map((field) => data[field]);

    const query = `
      UPDATE user_profile
      SET ${setClause}, updated_at = now()
      WHERE user_profile_id = $${fields.length + 1}
      RETURNING *
    `;

    const result = await db.query(query, {
      bind: [...values, profileId],
      type: QueryTypes.UPDATE,
    });

    return result[0][0];
  },
};

module.exports = userProfileRepository;
