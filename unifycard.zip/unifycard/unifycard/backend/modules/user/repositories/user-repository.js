// /backend/modules/user/repositories/user-repository.js

const db = require('../../../config/db');
const { QueryTypes } = require('sequelize');

/**
 * Repository para manipulação direta da tabela 'user'
 */
const userRepository = {
  /**
   * Busca usuário por e-mail (case insensitive)
   * @param {string} email
   * @returns {Promise<Object|null>}
   */
  async findByEmail(email) {
    console.log('[userRepository] - findByEmail - Email recebido:', email);

    const result = await db.query(
      `SELECT user_id, email, password_hash, created_at
       FROM "user"
       WHERE lower(email) = lower($1) AND deleted_at IS NULL
       LIMIT 1`,
      {
        bind: [email],
        type: QueryTypes.SELECT,
      }
    );

    console.log('[userRepository] - findByEmail - Resultado:', result);
    return result[0] || null;
  },

  /**
   * Cria um novo usuário na tabela
   * @param {Object} userData
   * @param {Object} [options] - { transaction }
   * @returns {Promise<Object>}
   */
  async create(userData, options = {}) {
    console.log('[userRepository] - create - Dados recebidos:', userData);

    const result = await db.query(
      `INSERT INTO "user" (email, password_hash, phone, is_email_verified, is_phone_verified)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING user_id, email, created_at`,
      {
        bind: [
          userData.email,
          userData.password_hash,
          userData.phone,
          userData.is_email_verified,
          userData.is_phone_verified,
        ],
        type: QueryTypes.INSERT,
        transaction: options.transaction,
      }
    );

    console.log('[userRepository] - create - Resultado:', result);
    return (result && result[0] && result[0][0]) ? result[0][0] : null;
  },
};

module.exports = userRepository;
