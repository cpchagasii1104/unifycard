const express = require('express');
const router = express.Router();

const userController = require('../controllers/user-controller');
const userProfileController = require('../controllers/user-profile-controller');
const userDashboardRoutes = require('../controllers/user-dashboard-controller');

const authMiddleware = require('../../../middlewares/auth-middleware'); // ✅ Middleware correto

// 🔐 Rotas protegidas
router.use('/user', authMiddleware, userDashboardRoutes);
router.get('/user-profile/:id', authMiddleware, userProfileController.getUserProfileById);
router.put('/user-profile/:id', authMiddleware, userProfileController.updateUserProfile);
router.get('/profile', authMiddleware, userProfileController.getUserProfileAuthenticated);

// 🔓 Rotas públicas
router.post('/signup', userController.signupUser);

module.exports = router;
