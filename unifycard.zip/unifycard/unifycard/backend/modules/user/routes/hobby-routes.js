const express = require('express');
const router = express.Router();
const controller = require('../controllers/hobby-controller');

router.get('/topics', controller.listTopics); // ?category=
router.get('/details', controller.listDetails); // ?topic_code=

module.exports = router;
