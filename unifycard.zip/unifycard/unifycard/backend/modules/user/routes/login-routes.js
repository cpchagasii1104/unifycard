// /unifycard/backend/modules/user/routes/login-routes.js

const express = require('express');
const router = express.Router();

const loginController = require('../controllers/login-controller');

/**
 * Rota de login de usuário
 * POST /api/login
 */
router.post('/', loginController);

module.exports = router;
