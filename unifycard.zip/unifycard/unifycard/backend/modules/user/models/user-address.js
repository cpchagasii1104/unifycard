// /backend/modules/user/models/user-address.js

const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/db');

const UserAddress = sequelize.define('UserAddress', {
  address_id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false
  },
  cep: {
    type: DataTypes.STRING,
    allowNull: false
  },
  street: {
    type: DataTypes.STRING,
    allowNull: false
  },
  number: {
    type: DataTypes.STRING,
    allowNull: false
  },
  complement: {
    type: DataTypes.STRING
  },
  neighborhood_id: {
    type: DataTypes.UUID,
    allowNull: false
  },
  city_id: {
    type: DataTypes.UUID,
    allowNull: false
  },
  state_id: {
    type: DataTypes.UUID,
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  timestamps: false,
  tableName: 'user_address'
});

module.exports = UserAddress;
