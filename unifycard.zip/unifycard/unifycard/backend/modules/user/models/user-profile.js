// /backend/modules/user/models/user-profile.js

const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/db');

const UserProfile = sequelize.define('UserProfile', {
  user_profile_id: {                 // Corrige o nome do campo, igual ao banco
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false,
    unique: true,
    references: {
      model: 'user',
      key: 'user_id',
    },
  },
  first_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  last_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  name: {
    type: DataTypes.VIRTUAL,
    get() {
      return `${this.first_name} ${this.last_name}`;
    },
    set(value) {
      throw new Error('Do not try to set the "name" value!');
    },
  },
  cpf: {
    type: DataTypes.BLOB, // BYTEA no banco, BLOB no Sequelize
    allowNull: false,
    unique: true,
    comment: 'CPF criptografado',
  },
  cnpj: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  birth_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  company_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  biological_sex: {
    type: DataTypes.STRING, // Enum mapeado manualmente, se precisar
    allowNull: true,
  },
  profile_status: {
    type: DataTypes.STRING, // Enum mapeado manualmente, se precisar
    allowNull: true,
    defaultValue: 'active',
  },
  gender_identity: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  profile_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  location_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'location',
      key: 'location_id',
    },
  },
  deleted_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  person_type: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'PF',
  },
  company_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  regional_account_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'regional_account',
      key: 'regional_account_id',
    },
  }
}, {
  timestamps: false,
  tableName: 'user_profile',
});

module.exports = UserProfile;
