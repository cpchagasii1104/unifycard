const userService = require('../services/user-service');

const updateUserProfile = async (req, res) => {
  try {
    const profileId = req.params.id;
    if (!profileId) return res.status(400).json({ message: 'ID do perfil ausente.' });

    const allowedFields = [
      'birth_date', 'phone', 'biological_sex', 'gender_identity',
      'street', 'number', 'complement', 'cep', 'preferences',
      'education_level', 'academic_degrees', 'completed_courses', 'certifications',
      'occupation', 'employment_type', 'monthly_income_range', 'housing_situation',
      'residents', 'dependents_count',
      'receives_social_benefit', 'social_benefit_details',
      'has_disability', 'disability_details', 'need_accessibility',
      'languages_spoken', 'has_transport', 'is_caregiver', 'has_animals',
      'available_periods', 'marital_status', 'height_cm', 'weight_kg',
      'has_children', 'children_count', 'children_ages',
      'function_codes', 'hobby_codes'
    ];

    const updateData = {};
    for (const field of allowedFields) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        updateData[field] = req.body[field];
      }
    }

    if (process.env.NODE_ENV !== 'production') {
      console.log('════════════════════════════════════════════');
      console.log('[UPDATE USER PROFILE] ID do perfil:', profileId);
      console.log('[UPDATE USER PROFILE] Campos recebidos:', Object.keys(updateData));
      console.log('[UPDATE USER PROFILE] Valores:', updateData);
      console.log('════════════════════════════════════════════');
    }

    const updatedProfile = await userService.updateUserProfile(profileId, updateData);

    return res.status(200).json({
      success: true,
      message: 'Perfil atualizado com sucesso.',
      profile: updatedProfile
    });

  } catch (err) {
    console.error('[ERRO updateUserProfile]', err);
    return res.status(500).json({ message: 'Erro ao atualizar perfil.' });
  }
};

const getUserProfileById = async (req, res) => {
  try {
    const userProfileId = req.params.id;
    if (!userProfileId) return res.status(400).json({ message: 'ID do perfil não informado.' });

    const profile = await userService.getUserProfileById(userProfileId);
    if (!profile) return res.status(404).json({ message: 'Perfil não encontrado.' });

    return res.status(200).json({ profile });
  } catch (err) {
    console.error('[ERRO getUserProfileById]', err);
    return res.status(500).json({ message: 'Erro ao buscar perfil.' });
  }
};

const getUserProfileAuthenticated = async (req, res) => {
  try {
    const userId = req.user.id;
    const profile = await userService.getUserProfileWithAddress(userId);
    return res.status(200).json({ profile });
  } catch (error) {
    console.error('[GET USER PROFILE AUTH]', error);
    return res.status(500).json({ error: 'Erro ao obter perfil do usuário.' });
  }
};

module.exports = {
  updateUserProfile,
  getUserProfileById,
  getUserProfileAuthenticated
};
