// C:\mercado_e_shop\backend\modules\user\controllers\profession-area-controller.js

const db = require('../../../config/db');

const getProfessionAreasBySector = async (req, res) => {
  const sectorCode = req.query.sector_code;

  if (!sectorCode) {
    return res.status(400).json({ error: 'Parâmetro "sector_code" é obrigatório.' });
  }

  try {
    const query = `
      SELECT area_code, label_pt, label_en, description
      FROM profession_area
      WHERE sector_code = $1 AND is_active = true
      ORDER BY label_pt;
    `;
    const { rows } = await db.query(query, [sectorCode]);

    return res.json({ areas: rows });
  } catch (err) {
    console.error('Erro ao buscar áreas profissionais:', err);
    return res.status(500).json({ error: 'Erro interno ao buscar áreas profissionais.' });
  }
};

module.exports = { getProfessionAreasBySector };
