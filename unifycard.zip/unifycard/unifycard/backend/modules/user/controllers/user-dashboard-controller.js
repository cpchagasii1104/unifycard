const express = require('express');
const router = express.Router();
const authMiddleware = require('../../../middlewares/auth-middleware');
const db = require('../../../config/db');
const { decryptCPF, maskCPF } = require('../utils/cpf-crypto');

// GET /api/user/dashboard
router.get('/dashboard', authMiddleware, async (req, res) => {
  const userId = req.user?.id || req.user?.user_id || req.query.user_id;

  if (!userId) {
    return res.status(400).json({ message: 'ID do usuário é obrigatório.' });
  }

  try {
    const { rows } = await db.query(
      `SELECT 
         u.user_id,
         u.email,
         up.first_name,
         up.last_name,
         up.birth_date,
         up.phone,
         up.cep,
         up.street,
         up.number,
         up.complement,
         up.referral_code,
         up.gender_identity,
         up.biological_sex,
         up.profile_status,
         up.preferences,
         up.user_profile_id,
         up.cpf,
         ra.regional_account_id,
         uba.unify_bank_account_id,
         card.card_id,
         n.name AS neighborhood,
         c.name AS city_name,
         s.name AS state_name,
         s.uf AS state_uf,
         (
           SELECT json_agg(upf.function_code)
           FROM user_profession_function upf
           WHERE upf.user_profile_id = up.user_profile_id
         ) AS function_codes,
         (
           SELECT json_agg(uh.hobby_code)
           FROM user_hobby uh
           WHERE uh.user_profile_id = up.user_profile_id
         ) AS hobby_codes
       FROM "user" u
       JOIN user_profile up ON u.user_id = up.user_id
       LEFT JOIN neighborhood n ON up.neighborhood_id = n.neighborhood_id
       LEFT JOIN city c ON up.city_id = c.city_id
       LEFT JOIN state s ON up.state_id = s.state_id
       LEFT JOIN regional_account ra ON up.regional_account_id = ra.regional_account_id
       LEFT JOIN unify_bank_account uba ON uba.user_id = u.user_id
       LEFT JOIN card ON card.user_id = u.user_id
       WHERE u.user_id = $1
       LIMIT 1`,
      [userId]
    );

    if (!rows[0]) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const user = rows[0];
    let decryptedCpf = '';
    let maskedCpf = '';

    try {
      const rawCpf = user.cpf?.toString();
      decryptedCpf = rawCpf ? decryptCPF(rawCpf) : '';
      maskedCpf = decryptedCpf ? maskCPF(decryptedCpf) : '';
    } catch (err) {
      console.error('[CPF Descriptografia]', err.message);
    }

    const profile = {
      user_id: user.user_id,
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      birth_date: user.birth_date || '',
      phone: user.phone || '',
      cep: user.cep || '',
      street: user.street || '',
      number: user.number || '',
      complement: user.complement || '',
      referral_code: user.referral_code || '',
      gender_identity: user.gender_identity || '',
      biological_sex: user.biological_sex || '',
      profile_status: user.profile_status || '',
      preferences: user.preferences || '',
      user_profile_id: user.user_profile_id,
      cpf: maskedCpf,
      regional_account_id: user.regional_account_id || '',
      unify_bank_account_id: user.unify_bank_account_id || '',
      card_id: user.card_id || '',
      neighborhood: user.neighborhood || '',
      city_name: user.city_name || '',
      state_name: user.state_name || '',
      state_uf: user.state_uf || '',
      function_codes: Array.isArray(user.function_codes) ? user.function_codes : [],
      hobby_codes: Array.isArray(user.hobby_codes) ? user.hobby_codes : [],
    };

    return res.status(200).json({ profile });
  } catch (err) {
    console.error('[DASHBOARD CONTROLLER] Erro ao carregar perfil:', err);
    return res.status(500).json({ message: 'Erro interno ao carregar o dashboard.' });
  }
});

module.exports = router;
