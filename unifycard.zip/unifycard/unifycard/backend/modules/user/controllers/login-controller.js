const { validateLogin } = require('../schemas/login-schema');
const userService = require('../services/user-service');

/**
 * Controller para login do usuário
 * @route POST /api/login
 */
async function loginController(req, res) {
  console.log('🚀 [LOGIN] Requisição recebida:', req.body);

  try {
    // 1. Validação de entrada
    const { error, value } = validateLogin(req.body);
    if (error) {
      console.warn('⚠️ [LOGIN] Falha de validação:', error.details[0].message);
      return res.status(400).json({ success: false, message: error.details[0].message });
    }

    console.log('✅ [LOGIN] Dados validados:', value);

    // 2. Autenticação pelo serviço real
    const { user, token } = await userService.loginUser(value);

    console.log('✅ [LOGIN] Usuário autenticado:', user.email);

    // 3. Resposta ao cliente
    return res.status(200).json({
      success: true,
      message: 'Login successful',
      user: {
        user_id: user.user_id,
        email: user.email,
        created_at: user.created_at
      },
      token
    });

  } catch (err) {
    if (err.code === 'INVALID_CREDENTIALS') {
      console.warn('⛔ [LOGIN] Credenciais inválidas:', req.body.email);
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    console.error('❌ [LOGIN] Erro interno:', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
}

module.exports = loginController;
