const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validateSignup } = require('../schemas/signup-schema');
const userService = require('../services/user-service');

const signupController = async (req, res) => {
  try {
    console.log('[SIGNUP] REQ.BODY:', req.body);

    // 🧪 Validação dos dados com Joi
    const { error, value } = validateSignup(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message,
      });
    }

    // 🧱 Verificação de campos obrigatórios adicionais (não cobertos por Joi)
    const requiredFields = [
      'email',
      'password',
      'cpf',
      'first_name',
      'last_name',
      'birth_date',
      'phone',
      'biological_sex',
      'cep',
      'street',
      'number',
    ];

    for (const field of requiredFields) {
      if (!value[field] || (Array.isArray(value[field]) && value[field].length === 0)) {
        return res.status(400).json({
          success: false,
          message: `Missing required field: ${field}`,
        });
      }
    }

    // 🧬 Criação do usuário e perfil
    const {
      user_id,
      user_profile_id,
      referral_code: generated_referral_code,
    } = await userService.createUser({
      ...value,
      referral_code: req.body.referral_code?.trim() || null,
    });

    // 🔐 Geração do JWT
    const token = jwt.sign(
  { id: user_id, email: value.email },
  process.env.JWT_SECRET,
  { expiresIn: '12h' }
  );

    // 📦 Retorno de sucesso com dados essenciais
    return res.status(201).json({
      success: true,
      message: 'User created successfully.',
      user: {
        user_id,
        user_profile_id,
        referral_code: generated_referral_code,
        email: value.email,
      },
      token,
    });

  } catch (err) {
    console.error('[ERROR IN SIGNUP CONTROLLER]', err);

    // 🔁 Tratamento de erros conhecidos
    if (err.code === 'USER_EMAIL_EXISTS') {
      return res.status(409).json({
        success: false,
        message: 'Email already registered.',
      });
    }

    if (err.code === 'USER_CPF_EXISTS') {
      return res.status(409).json({
        success: false,
        message: 'CPF already registered.',
      });
    }

    if (err.message === 'Invalid CEP.') {
      return res.status(400).json({
        success: false,
        message: 'Invalid CEP.',
      });
    }

    // 🛑 Erro interno genérico
    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
};

module.exports = signupController;
