const db = require('../../../config/db');

// Lista os tópicos de hobby (categoria opcional: physical, artistic, etc)
const listTopics = async (req, res) => {
  try {
    const { category } = req.query;
    const values = [];
    let where = '';

    if (category) {
      where = 'WHERE category = $1';
      values.push(category);
    }

    const query = `
      SELECT topic_code, label_pt, label_en, category
      FROM hobby_topic
      ${where}
      ORDER BY label_pt
    `;
    const { rows } = await db.query(query, values);
    res.json(rows);
  } catch (err) {
    console.error('[listTopics]', err);
    res.status(500).json({ message: 'Erro ao buscar tópicos.' });
  }
};

// Lista os hobbies (renomeado de hobby_detail → hobby)
const listHobbies = async (req, res) => {
  try {
    const { topic_code } = req.query;
    const values = [];
    let where = '';

    if (topic_code) {
      where = 'WHERE topic_code = $1';
      values.push(topic_code);
    }

    const query = `
      SELECT hobby_code, label_pt, label_en, topic_code
      FROM hobby
      ${where}
      ORDER BY label_pt
    `;
    const { rows } = await db.query(query, values);
    res.json(rows);
  } catch (err) {
    console.error('[listHobbies]', err);
    res.status(500).json({ message: 'Erro ao buscar hobbies.' });
  }
};

module.exports = {
  listTopics,
  listHobbies,
};
