const db = require('../../../config/db');

exports.getAllProfessionFunctions = async (req, res) => {
  try {
    const query = `
      SELECT function_code AS code, label_pt AS label
      FROM profession_function
      WHERE is_active = true
      ORDER BY label_pt ASC
    `;
    const { rows } = await db.query(query);
    res.json(rows);
  } catch (err) {
    console.error('Erro ao buscar funções profissionais:', err);
    res.status(500).json({ message: 'Erro ao carregar funções profissionais' });
  }
};
