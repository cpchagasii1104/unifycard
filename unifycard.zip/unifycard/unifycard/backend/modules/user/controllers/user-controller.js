const userService = require('../services/user-service');
const { generateReferralCode } = require('../../../shared/utils/referral-code-util');

/**
 * POST /api/signup
 * Cria novo usuário com dados básicos e código de indicação (se fornecido)
 */
const signupUser = async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      password,
      cpf,
      phone_country,
      phone,
      biological_sex,
      birth_date,
      cep,
      street,
      number,
      complement,
      country,
      referral_code,
      consent_at,
      function_codes
    } = req.body;

    const userData = {
      first_name,
      last_name,
      email,
      password,
      cpf,
      phone_country,
      phone,
      biological_sex,
      birth_date,
      cep,
      street,
      number,
      complement,
      country,
      referral_code: referral_code || null,
      consent_at,
      profession_sector_code: null,
      profession_area_code: null,
      profession_function_code: null,
      function_codes: Array.isArray(function_codes) ? function_codes : [],
      generated_referral_code: generateReferralCode(),
    };

    const result = await userService.createUser(userData);
    return res.status(201).json(result);

  } catch (err) {
    console.error('[signupUser] ERRO:', err);

    if (err.code === '23505') {
      if (err.detail?.includes('email')) {
        return res.status(409).json({ message: 'E-mail já cadastrado.' });
      }
      if (err.detail?.includes('cpf')) {
        return res.status(409).json({ message: 'CPF já cadastrado.' });
      }
      if (err.detail?.includes('cep')) {
        return res.status(400).json({ message: 'CEP inválido ou duplicado.' });
      }
    }

    return res.status(500).json({
      success: false,
      message: err.message || 'Erro interno no servidor.',
    });
  }
};

/**
 * GET /api/user/dashboard
 * Retorna os dados do usuário logado com endereço e dados de perfil.
 */
const getDashboardProfile = async (req, res) => {
  try {
    const user_id = req.user.user_id;
    const profile = await userService.getUserProfileWithAddress(user_id);

    return res.status(200).json({ success: true, profile }); // ✅ CPF virá como profile.cpf
  } catch (err) {
    console.error('[getDashboardProfile] ERRO:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * GET /api/user/indicated
 * Retorna lista de usuários que foram indicados por este usuário.
 */
const getIndicatedUsers = async (req, res) => {
  try {
    const user_id = req.user.user_id;
    const indicated = await userService.getUsersIndicatedByUser(user_id);
    return res.status(200).json({ success: true, indicated });
  } catch (err) {
    console.error('[getIndicatedUsers] ERRO:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * PUT /api/user-profile/:id
 * Atualiza o perfil do usuário com os dados recebidos no corpo da requisição
 */
const updateUserProfile = async (req, res) => {
  try {
    const profileId = req.params.id;
    if (!profileId) {
      return res.status(400).json({ message: 'ID do perfil ausente.' });
    }

    const updateData = req.body;

    // 🟡 Log para depuração total:
    console.log('─────────────────────────────────────────────');
    console.log('[CONTROLLER] updateUserProfile → INICIADO');
    console.log('[CONTROLLER] profileId recebido →', profileId);
    console.log('[CONTROLLER] updateData recebido →', updateData);
    console.log('─────────────────────────────────────────────');

    const updatedProfile = await userService.updateUserProfile(profileId, updateData);

    return res.status(200).json({
      success: true,
      message: 'Perfil atualizado com sucesso.',
      profile: updatedProfile
    });
  } catch (err) {
    console.error('[ERRO updateUserProfile]', err);
    return res.status(500).json({ message: 'Erro ao atualizar perfil.' });
  }
};

module.exports = {
  signupUser,
  getDashboardProfile,
  getIndicatedUsers,
  updateUserProfile, // ✅ agora corretamente exportado
};
