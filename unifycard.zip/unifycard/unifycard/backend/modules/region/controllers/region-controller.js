// /backend/modules/region/controllers/region-controller.js
const db = require('../../../config/db');

exports.lookupCep = async (req, res) => {
  const { cep } = req.params;
  try {
    const result = await db.query(
      `SELECT n.name AS neighborhood, c.name AS city, s.name AS state, ac.street_name
       FROM address_cep ac
       JOIN neighborhood n ON ac.neighborhood_id = n.neighborhood_id
       JOIN city c ON n.city_id = c.city_id
       JOIN state s ON c.state_id = s.state_id
       WHERE ac.cep = $1 LIMIT 1`,
      { bind: [cep], type: db.QueryTypes.SELECT }
    );

    if (!result[0]) return res.status(404).json({ message: 'CEP não encontrado' });
    res.json(result[0]);
  } catch (err) {
    console.error('Erro ao buscar CEP:', err);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
};
