// /backend/modules/region/models/address-cep-range.js

module.exports = (sequelize, DataTypes) => {
  const AddressCep = sequelize.define('AddressCep', {
    cep: {
      type: DataTypes.STRING(8),
      primaryKey: true,
    },
    street_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    neighborhood_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
  }, {
    tableName: 'address_cep',
    timestamps: false,
  });

  AddressCep.associate = (models) => {
    AddressCep.belongsTo(models.Neighborhood, { foreignKey: 'neighborhood_id' });
  };

  return AddressCep;
};
