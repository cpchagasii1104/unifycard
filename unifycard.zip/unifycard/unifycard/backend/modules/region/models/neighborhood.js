// /backend/modules/region/models/neighborhood.js

module.exports = (sequelize, DataTypes) => {
  const Neighborhood = sequelize.define('Neighborhood', {
    neighborhood_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    city_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    tableName: 'neighborhood',
    timestamps: false,
  });

  Neighborhood.associate = (models) => {
    Neighborhood.belongsTo(models.City, { foreignKey: 'city_id' });
  };

  return Neighborhood;
};
