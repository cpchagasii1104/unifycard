// /backend/modules/region/models/regional-account.js

module.exports = (sequelize, DataTypes) => {
  const RegionalAccount = sequelize.define('RegionalAccount', {
    regional_account_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    neighborhood_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    created_at: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  }, {
    tableName: 'regional_account',
    timestamps: false,
  });

  RegionalAccount.associate = (models) => {
    RegionalAccount.belongsTo(models.Neighborhood, { foreignKey: 'neighborhood_id' });
  };

  return RegionalAccount;
};
