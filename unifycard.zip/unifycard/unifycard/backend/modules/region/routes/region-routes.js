const express = require('express');
const regionController = require('../controllers/region-controller.js');
const regionRoutes = express.Router();

// Rota de consulta de CEP (ViaCEP ou banco interno)
regionRoutes.get('/cep/:cep', async (req, res) => {
  const { cep } = req.params;
  try {
    const data = await regionController.lookupCep(cep);
    res.json(data);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = regionRoutes;
