'use strict';

const express = require('express');
const router = express.Router();

const scheduleController = require('../controllers/schedule-controller');
const authMiddleware = require('../../../middlewares/auth-middleware');

// 🗓️ Horários (schedules)
router.post('/', authMiddleware, scheduleController.createSchedule);
router.get('/company/:companyId', authMiddleware, scheduleController.listSchedules);
router.put('/:scheduleId', authMiddleware, scheduleController.updateSchedule);
router.delete('/:scheduleId', authMiddleware, scheduleController.deleteSchedule);

// 📅 Agendamentos (bookings)
router.post('/booking', authMiddleware, scheduleController.bookSchedule);
router.get('/booking/company/:companyId', authMiddleware, scheduleController.listBookings);
router.put('/booking/:bookingId/status', authMiddleware, scheduleController.updateBookingStatus);

module.exports = router;
