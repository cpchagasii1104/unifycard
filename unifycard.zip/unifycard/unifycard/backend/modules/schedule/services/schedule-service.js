'use strict';

const db = require('../../../database');
const {
  Schedule,
  ScheduleBooking,
  Company,
  CompanyEmployee,
  User,
} = db;

const createSchedule = async (userId, data) => {
  const company = await Company.findByPk(data.companyId);
  if (!company) throw new Error('Company not found');

  return await Schedule.create({
    ...data,
    employeeId: data.employeeId || null,
  });
};

const listSchedules = async (companyId) => {
  return await Schedule.findAll({
    where: { companyId, isActive: true },
    order: [['dayOfWeek', 'ASC'], ['startTime', 'ASC']],
  });
};

const updateSchedule = async (scheduleId, updates) => {
  const schedule = await Schedule.findByPk(scheduleId);
  if (!schedule) throw new Error('Schedule not found');

  return await schedule.update(updates);
};

const deleteSchedule = async (scheduleId) => {
  const schedule = await Schedule.findByPk(scheduleId);
  if (!schedule) throw new Error('Schedule not found');

  return await schedule.destroy();
};

const bookSchedule = async (userId, data) => {
  const schedule = await Schedule.findByPk(data.scheduleId);
  if (!schedule) throw new Error('Schedule not found');

  const booking = await ScheduleBooking.create({
    scheduleId: data.scheduleId,
    companyId: schedule.companyId,
    employeeId: schedule.employeeId,
    userId,
    date: data.date,
    startTime: schedule.startTime,
    endTime: schedule.endTime,
    notes: data.notes || null,
    status: 'pending',
  });

  return booking;
};

const listBookings = async (companyId, filters = {}) => {
  const where = { companyId };

  if (filters.date) {
    where.date = filters.date;
  }

  if (filters.status) {
    where.status = filters.status;
  }

  return await ScheduleBooking.findAll({
    where,
    order: [['date', 'ASC'], ['startTime', 'ASC']],
    include: [
      { model: Schedule, as: 'schedule' },
      { model: User, as: 'user' },
    ],
  });
};

const updateBookingStatus = async (bookingId, status) => {
  const booking = await ScheduleBooking.findByPk(bookingId);
  if (!booking) throw new Error('Booking not found');

  booking.status = status;
  return await booking.save();
};

module.exports = {
  createSchedule,
  listSchedules,
  updateSchedule,
  deleteSchedule,
  bookSchedule,
  listBookings,
  updateBookingStatus,
};
