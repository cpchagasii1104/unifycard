'use strict';

const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ScheduleBooking extends Model {
    static associate(models) {
      // 🔗 Horário original
      ScheduleBooking.belongsTo(models.Schedule, {
        foreignKey: 'schedule_id',
        as: 'schedule',
        onDelete: 'CASCADE',
      });

      // 🔗 Usuário que agendou
      ScheduleBooking.belongsTo(models.User, {
        foreignKey: 'user_id',
        as: 'user',
        onDelete: 'SET NULL',
      });

      // 🔗 Empresa
      ScheduleBooking.belongsTo(models.Company, {
        foreignKey: 'company_id',
        as: 'company',
        onDelete: 'CASCADE',
      });

      // 🔗 Funcionário (prestador)
      ScheduleBooking.belongsTo(models.CompanyEmployee, {
        foreignKey: 'employee_id',
        as: 'employee',
        onDelete: 'SET NULL',
      });
    }
  }

  ScheduleBooking.init(
    {
      scheduleBookingId: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        field: 'schedule_booking_id',
      },
      scheduleId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'schedule_id',
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: true,
        field: 'user_id',
      },
      employeeId: {
        type: DataTypes.UUID,
        allowNull: true,
        field: 'employee_id',
      },
      companyId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'company_id',
      },
      date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      startTime: {
        type: DataTypes.TIME,
        allowNull: false,
        field: 'start_time',
      },
      endTime: {
        type: DataTypes.TIME,
        allowNull: false,
        field: 'end_time',
      },
      status: {
        type: DataTypes.ENUM('pending', 'confirmed', 'cancelled', 'completed', 'no_show'),
        defaultValue: 'pending',
      },
      notes: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Observações do cliente ou atendente',
      },
      createdAt: {
        type: DataTypes.DATE,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        field: 'created_at',
      },
      updatedAt: {
        type: DataTypes.DATE,
        field: 'updated_at',
      },
    },
    {
      sequelize,
      modelName: 'ScheduleBooking',
      tableName: 'schedule_booking',
      underscored: true,
      timestamps: true,
      paranoid: false,
    }
  );

  return ScheduleBooking;
};
