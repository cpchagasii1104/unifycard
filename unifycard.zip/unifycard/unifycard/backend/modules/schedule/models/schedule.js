'use strict';

const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Schedule extends Model {
    static associate(models) {
      // 🔗 Empresa responsável
      Schedule.belongsTo(models.Company, {
        foreignKey: 'company_id',
        as: 'company',
        onDelete: 'CASCADE',
      });

      // 🔗 Filial onde ocorre (se aplicável)
      Schedule.belongsTo(models.CompanyBranch, {
        foreignKey: 'branch_id',
        as: 'branch',
        onDelete: 'SET NULL',
      });

      // 🔗 Funcionário responsável
      Schedule.belongsTo(models.CompanyEmployee, {
        foreignKey: 'employee_id',
        as: 'employee',
        onDelete: 'SET NULL',
      });

      // 📅 Reservas vinculadas
      Schedule.hasMany(models.ScheduleBooking, {
        foreignKey: 'schedule_id',
        as: 'bookings',
        onDelete: 'CASCADE',
      });
    }
  }

  Schedule.init(
    {
      scheduleId: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        field: 'schedule_id',
      },
      companyId: {
        type: DataTypes.UUID,
        allowNull: false,
        field: 'company_id',
      },
      branchId: {
        type: DataTypes.UUID,
        allowNull: true,
        field: 'branch_id',
      },
      employeeId: {
        type: DataTypes.UUID,
        allowNull: true,
        field: 'employee_id',
      },
      title: {
        type: DataTypes.STRING(255),
        allowNull: false,
        comment: 'Título do horário (ex: Atendimento jurídico, Aula de pilates)',
      },
      description: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      dayOfWeek: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'day_of_week',
        comment: '0 = Domingo, 1 = Segunda, ..., 6 = Sábado',
      },
      startTime: {
        type: DataTypes.TIME,
        allowNull: false,
        field: 'start_time',
      },
      endTime: {
        type: DataTypes.TIME,
        allowNull: false,
        field: 'end_time',
      },
      isRecurring: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        field: 'is_recurring',
        comment: 'Indica se o horário se repete semanalmente',
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        field: 'is_active',
      },
      createdAt: {
        type: DataTypes.DATE,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        field: 'created_at',
      },
      updatedAt: {
        type: DataTypes.DATE,
        field: 'updated_at',
      },
    },
    {
      sequelize,
      modelName: 'Schedule',
      tableName: 'schedule',
      underscored: true,
      timestamps: true,
      paranoid: false,
    }
  );

  return Schedule;
};
