'use strict';

const scheduleService = require('../services/schedule-service');

// 🗓️ Criar novo horário recorrente
const createSchedule = async (req, res, next) => {
  try {
    const { userId } = req.auth;
    const data = req.body;

    const schedule = await scheduleService.createSchedule(userId, data);
    return res.status(201).json(schedule);
  } catch (error) {
    next(error);
  }
};

// 🔍 Buscar horários da empresa
const listSchedules = async (req, res, next) => {
  try {
    const { companyId } = req.params;
    const result = await scheduleService.listSchedules(companyId);
    return res.json(result);
  } catch (error) {
    next(error);
  }
};

// 🔄 Atualizar um horário
const updateSchedule = async (req, res, next) => {
  try {
    const { scheduleId } = req.params;
    const updates = req.body;

    const updated = await scheduleService.updateSchedule(scheduleId, updates);
    return res.json(updated);
  } catch (error) {
    next(error);
  }
};

// ❌ Deletar horário
const deleteSchedule = async (req, res, next) => {
  try {
    const { scheduleId } = req.params;
    await scheduleService.deleteSchedule(scheduleId);
    return res.status(204).send();
  } catch (error) {
    next(error);
  }
};

// 📅 Criar agendamento (booking)
const bookSchedule = async (req, res, next) => {
  try {
    const { userId } = req.auth;
    const data = req.body;

    const booking = await scheduleService.bookSchedule(userId, data);
    return res.status(201).json(booking);
  } catch (error) {
    next(error);
  }
};

// 📋 Buscar agendamentos
const listBookings = async (req, res, next) => {
  try {
    const { companyId } = req.params;
    const filters = req.query;

    const result = await scheduleService.listBookings(companyId, filters);
    return res.json(result);
  } catch (error) {
    next(error);
  }
};

// ✅ Atualizar status da reserva
const updateBookingStatus = async (req, res, next) => {
  try {
    const { bookingId } = req.params;
    const { status } = req.body;

    const result = await scheduleService.updateBookingStatus(bookingId, status);
    return res.json(result);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createSchedule,
  listSchedules,
  updateSchedule,
  deleteSchedule,
  bookSchedule,
  listBookings,
  updateBookingStatus,
};
