'use strict';

const { Op } = require('sequelize');
const db = require('@/database');

const {
  Schedule,
  ScheduleBooking,
  Company,
  CompanyEmployee,
  User,
} = db;

// 🔍 Buscar horário por ID
const findScheduleById = async (scheduleId) => {
  return await Schedule.findByPk(scheduleId);
};

// 🔍 Buscar todos os horários ativos da empresa
const findSchedulesByCompany = async (companyId) => {
  return await Schedule.findAll({
    where: {
      companyId,
      isActive: true,
    },
    order: [['dayOfWeek', 'ASC'], ['startTime', 'ASC']],
  });
};

// 📅 Criar novo horário
const createSchedule = async (data, transaction = null) => {
  return await Schedule.create(data, { transaction });
};

// ✏️ Atualizar horário
const updateSchedule = async (schedule, updates, transaction = null) => {
  return await schedule.update(updates, { transaction });
};

// ❌ Deletar horário
const deleteSchedule = async (schedule, transaction = null) => {
  return await schedule.destroy({ transaction });
};

// 📚 Buscar agendamento por ID
const findBookingById = async (bookingId) => {
  return await ScheduleBooking.findByPk(bookingId);
};

// 📚 Buscar agendamentos com filtros
const findBookings = async (companyId, filters = {}) => {
  const where = { companyId };

  if (filters.date) {
    where.date = filters.date;
  }

  if (filters.status) {
    where.status = filters.status;
  }

  if (filters.employeeId) {
    where.employeeId = filters.employeeId;
  }

  return await ScheduleBooking.findAll({
    where,
    order: [['date', 'ASC'], ['startTime', 'ASC']],
    include: [
      { model: Schedule, as: 'schedule' },
      { model: User, as: 'user' },
      { model: CompanyEmployee, as: 'employee' },
    ],
  });
};

// 📅 Criar novo agendamento (reserva)
const createBooking = async (data, transaction = null) => {
  return await ScheduleBooking.create(data, { transaction });
};

// ✏️ Atualizar status de agendamento
const updateBookingStatus = async (booking, status, transaction = null) => {
  booking.status = status;
  return await booking.save({ transaction });
};

module.exports = {
  findScheduleById,
  findSchedulesByCompany,
  createSchedule,
  updateSchedule,
  deleteSchedule,
  findBookingById,
  findBookings,
  createBooking,
  updateBookingStatus,
};
