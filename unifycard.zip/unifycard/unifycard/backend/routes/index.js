'use strict';

const express = require('express');
const router = express.Router();

// ✅ Login via módulo de rota (estrutura validada)
router.use('/login', require('../modules/user/routes/login-routes'));

// 🔁 Outras rotas reais da aplicação
router.use('/hobbies', require('./hobby-routes'));
router.use('/enums', require('./enum-routes'));
router.use('/user', require('../modules/user/routes/user-routes'));
router.use('/company', require('../modules/company/routes/company-routes'));
router.use('/product', require('../modules/product/routes/product-routes'));
router.use('/schedule', require('../modules/schedule/routes/schedule-routes'));
router.use('/region', require('../modules/region/routes/region-routes'));

// 🧹 Nunca declare diretamente: router.post('/login', controller) aqui.

module.exports = router;
