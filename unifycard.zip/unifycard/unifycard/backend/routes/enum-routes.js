const express = require('express');
const router = express.Router();
const pool = require('../config/db');

// 🧠 Função genérica para buscar ENUMs do tipo ENUM
const fetchEnumValues = async (enumTypeName) => {
  const query = `SELECT unnest(enum_range(NULL::${enumTypeName})) AS value`;
  const result = await pool.query(query);
  return result.rows.map(row => row.value);
};

// 🔸 [GET] /api/enums/gender-identity → ainda é ENUM no banco
router.get('/gender-identity', async (req, res) => {
  try {
    const values = await fetchEnumValues('gender_identity');
    res.status(200).json(values);
  } catch (err) {
    console.error('Erro ao buscar ENUM gender_identity:', err);
    res.status(500).json({ error: 'Erro ao buscar enum gender_identity' });
  }
});

// 🔹 [GET] /api/enums/profession-sector → agora busca da tabela
router.get('/profession-sector', async (req, res) => {
  try {
    const lang = req.query.lang === 'en' ? 'label_en' : 'label_pt';
    const result = await pool.query(
      `SELECT code, ${lang} AS label FROM profession_sector WHERE is_active = true ORDER BY ${lang}`
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar setores profissionais:', err);
    res.status(500).json({ error: 'Erro ao buscar setores profissionais' });
  }
});

// 🔹 [GET] /api/enums/profession-areas?sector_code=food
router.get('/profession-areas', async (req, res) => {
  const sectorCode = req.query.sector_code;
  if (!sectorCode) {
    return res.status(400).json({ error: 'Parâmetro "sector_code" é obrigatório.' });
  }

  try {
    const lang = req.query.lang === 'en' ? 'label_en' : 'label_pt';
    const result = await pool.query(
      `SELECT area_code AS code, ${lang} AS label FROM profession_area WHERE sector_code = $1 AND is_active = true ORDER BY ${lang}`,
      [sectorCode]
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar áreas profissionais:', err);
    res.status(500).json({ error: 'Erro ao buscar áreas profissionais' });
  }
});

// 🔹 [GET] /api/enums/profession-functions?area_code=cozinha
router.get('/profession-functions', async (req, res) => {
  const areaCode = req.query.area_code;
  if (!areaCode) {
    return res.status(400).json({ error: 'Parâmetro "area_code" é obrigatório.' });
  }

  try {
    const lang = req.query.lang === 'en' ? 'label_en' : 'label_pt';
    const result = await pool.query(
      `SELECT function_code AS code, ${lang} AS label FROM profession_function WHERE area_code = $1 AND is_active = true ORDER BY ${lang}`,
      [areaCode]
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar funções profissionais:', err);
    res.status(500).json({ error: 'Erro ao buscar funções profissionais' });
  }
});

// 🔹 [GET] /api/enums/hobbies → lista categorizada de hobbies
const hobbyEnumController = require('../modules/hobby/controllers/hobby-enum-controller');
router.get('/hobbies', hobbyEnumController.getHobbyList);

module.exports = router;
