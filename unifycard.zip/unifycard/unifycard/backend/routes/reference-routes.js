const express = require('express');
const router = express.Router();

const professionController = require('../modules/user/controllers/profession-controller');
const hobbyController = require('../modules/user/controllers/hobby-controller');

// 🔍 Retorna todas as profissões disponíveis
router.get('/professions', professionController.getAllProfessions);

// 🔍 Retorna todos os hobbies disponíveis
router.get('/hobbies', hobbyController.getAllHobbies);

module.exports = router;
