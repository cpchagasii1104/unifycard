// Caminho: /unifycard/backend/routes/hobby-routes.js

const express = require('express');
const router = express.Router();
const db = require('../config/db');

// 🔹 GET /api/hobbies/categories
router.get('/categories', async (req, res) => {
  try {
    const result = await db.query(`SELECT unnest(enum_range(NULL::hobby_category)) AS category`);
    return res.json(result.rows.map(row => row.category));
  } catch (err) {
    console.error('[GET /hobbies/categories]', err);
    return res.status(500).json({ message: 'Erro ao buscar categorias.' });
  }
});

// 🔹 GET /api/hobbies/topics?category=musica
router.get('/topics', async (req, res) => {
  try {
    const { category } = req.query;
    const query = `
      SELECT topic_code, label_pt, label_en, category, description
      FROM hobby_topic
      WHERE is_active = TRUE
      ${category ? 'AND category = $1' : ''}
      ORDER BY label_pt
    `;
    const params = category ? [category] : [];
    const result = await db.query(query, params);
    return res.json(result.rows);
  } catch (err) {
    console.error('[GET /hobbies/topics]', err);
    return res.status(500).json({ message: 'Erro ao buscar tópicos.' });
  }
});

// 🔹 GET /api/hobbies/details?topic_code=xyz
router.get('/details', async (req, res) => {
  try {
    const { topic_code } = req.query;
    if (!topic_code) return res.status(400).json({ message: 'topic_code é obrigatório.' });

    const query = `
      SELECT hobby_code, label_pt, label_en, topic_code, description
      FROM hobby
      WHERE topic_code = $1 AND is_active = TRUE
      ORDER BY label_pt
    `;
    const result = await db.query(query, [topic_code]);
    return res.json(result.rows);
  } catch (err) {
    console.error('[GET /hobbies/details]', err);
    return res.status(500).json({ message: 'Erro ao buscar hobbies.' });
  }
});

// 🔹 NOVA ROTA /api/hobbies/all
router.get('/all', async (req, res) => {
  try {
    const query = `
      SELECT hobby_code, label_pt, label_en, topic_code, description
      FROM hobby
      WHERE is_active = TRUE
      ORDER BY label_pt
    `;
    const result = await db.query(query);
    return res.json(result.rows);
  } catch (err) {
    console.error('[GET /hobbies/all]', err);
    return res.status(500).json({ message: 'Erro ao buscar todos os hobbies.' });
  }
});

module.exports = router;
