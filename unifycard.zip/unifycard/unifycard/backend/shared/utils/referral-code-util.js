// /backend/shared/utils/referral-code-util.js

function generateReferralCode(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function isValidReferralCode(code) {
  const regex = /^[a-zA-Z0-9]{6,12}$/;
  return regex.test(code);
}

module.exports = {
  generateReferralCode,
  isValidReferralCode,
};
