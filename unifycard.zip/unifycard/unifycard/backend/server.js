'use strict';

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
require('dotenv').config();

const authRoutes = require('./routes/auth-routes');
const userRoutes = require('./routes/user-routes');
const adminRoutes = require('./routes/admin-routes');
const unifyBankRoutes = require('./routes/unify-bank-routes');
const enumRoutes = require('./routes/enum-routes'); // ✅ Rota ENUM

const app = express();

// 🔒 Middlewares globais
app.use(cors());
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());

// 🌐 Rotas principais
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes); // ✅ Rotas de user centralizam rotas de empresa, produtos etc.
app.use('/api/admin', adminRoutes);
app.use('/api/unifybank', unifyBankRoutes);
app.use('/api/enums', enumRoutes); // ✅ ENUMs como gender_identity

// ✅ Teste básico
app.get('/', (req, res) => {
  res.send('🚀 UnifyCard backend rodando com sucesso!');
});

// 🚀 Inicializar servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Servidor backend rodando na porta ${PORT}`);
});
