// src/contexts/SessionProvider.tsx
// Bootstrap centralizado de sessão: autenticação + actors + activeActor
// Garante que activeActor nunca seja null após o bootstrap

import { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { getAvailableActors, type AvailableActor } from '../api/social';
import { isAuthenticated, getTenantId, getAuthToken, setTenantId } from '../config/auth';
import { setBootstraping } from '../api/client';
import { getProfile, type Profile } from '../api/profile';

interface SessionContextType {
  sessionReady: boolean;
  activeActor: AvailableActor | null;
  actors: AvailableActor[];
  setActiveActor: (actorId: string | null) => void;
  refreshActors: () => Promise<void>;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);

const ACTOR_STORAGE_KEY = 'unificard_active_actor_id';

export function SessionProvider({ children }: { children: ReactNode }) {
  const [sessionReady, setSessionReady] = useState(false);
  const [activeActor, setActiveActorState] = useState<AvailableActor | null>(null);
  const [actors, setActors] = useState<AvailableActor[]>([]);
  const [_isBootstrapping, setIsBootstrapping] = useState(false);
  
  // Guard síncrono usando useRef para prevenir race conditions
  // useRef é síncrono e imediato, não tem janela de race condition como useState
  const bootstrapInProgressRef = useRef(false);
  
  // Ref para rastrear se o bootstrap está em andamento (para tolerar 401)
  const isBootstrappingRef = useRef(false);
  
  // 🔴 ESTABILIDADE DE SESSÃO: Refs para garantir que sessionReady e activeActor não sejam resetados
  // Uma vez que sessionReady = true, não pode voltar para false (exceto logout explícito)
  const sessionReadyStableRef = useRef(false);
  // Uma vez que activeActor é definido, não pode ser resetado para null (exceto logout explícito)
  const activeActorStableRef = useRef<AvailableActor | null>(null);

  const bootstrapSession = async () => {
    // Prevenir múltiplas chamadas simultâneas usando ref síncrono
    if (bootstrapInProgressRef.current) {
      console.warn('[SessionProvider] Bootstrap já em andamento, ignorando chamada duplicada');
      return;
    }
    
    // Marcar imediatamente (síncrono) para prevenir race condition
    bootstrapInProgressRef.current = true;
    // Marcar que bootstrap está em andamento (para tolerar 401)
    isBootstrappingRef.current = true;

    console.log('[SessionProvider] 🚀 Iniciando bootstrap de sessão...');

    // ============================================
    // FASE 1: VALIDAÇÃO DE AUTENTICAÇÃO
    // ============================================
    // Se não estiver autenticado, não fazer bootstrap
    if (!isAuthenticated()) {
      console.log('[SessionProvider] ❌ Não autenticado - bootstrap cancelado');
      // Resetar flags se não autenticado
      bootstrapInProgressRef.current = false;
      isBootstrappingRef.current = false;
      setSessionReady(true);
      return;
    }

    // 🔴 GARANTIA CANÔNICA: tenantId vem SEMPRE do JWT (fonte única de verdade)
    // Storage é apenas cache, nunca fonte primária
    // Se tenantId não estiver no storage, extrair do JWT ANTES de qualquer chamada de API
    const token = getAuthToken();
    if (!token) {
      console.log('[SessionProvider] ❌ Token ausente - bootstrap cancelado');
      bootstrapInProgressRef.current = false;
      isBootstrappingRef.current = false;
      setSessionReady(false);
      return;
    }

    // 🔴 FASE 1.1: Extrair tenantId do JWT (fonte única de verdade)
    let tenantId: string | null = getTenantId(); // Tentar do storage primeiro (cache)
    
    if (!tenantId) {
      // 🔴 GARANTIA CANÔNICA: Se não estiver no storage, extrair do JWT
      try {
        const tokenPayload = JSON.parse(atob(token.split('.')[1]));
        tenantId = tokenPayload.tenantId;
        
        // 🔴 VALIDAÇÃO EXPLÍCITA: tenantId deve ser string não vazia
        if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
          throw new Error('tenantId ausente ou inválido no JWT');
        }
        
        // 🔴 SALVAR IMEDIATAMENTE: Persistir no storage para próximas requisições
        setTenantId(tenantId);
        console.log('[SessionProvider] ✅ tenantId extraído do JWT e salvo:', tenantId);
      } catch (e) {
        // 🔴 FALHA FATAL: Não conseguir extrair tenantId do JWT é erro crítico
        const errorMessage = e instanceof Error ? e.message : 'Falha ao extrair tenantId do JWT';
        console.error('[SessionProvider] ❌ ERRO CRÍTICO:', errorMessage, e);
        
        // Resetar flags
        bootstrapInProgressRef.current = false;
        isBootstrappingRef.current = false;
        setBootstraping(false);
        setIsBootstrapping(false);
        
        // 🔴 ERRO FATAL: Não marcar sessionReady - bootstrap falhou
        setSessionReady(false);
        return; // Interromper bootstrap - não continuar sem tenantId
      }
    } else {
      // 🔴 VALIDAÇÃO: Garantir que tenantId do storage corresponde ao JWT
      try {
        const tokenPayload = JSON.parse(atob(token.split('.')[1]));
        const jwtTenantId = tokenPayload.tenantId;
        
        if (jwtTenantId && tenantId !== jwtTenantId) {
          console.warn('[SessionProvider] ⚠️ tenantId no storage não corresponde ao JWT - corrigindo...');
          tenantId = jwtTenantId; // Usar JWT como fonte de verdade
          setTenantId(tenantId);
          console.log('[SessionProvider] ✅ tenantId corrigido do JWT:', tenantId);
        }
      } catch (e) {
        console.error('[SessionProvider] ❌ Erro ao validar tenantId do JWT:', e);
        // Não falhar - tenantId do storage pode ser válido mesmo se JWT estiver corrompido
      }
    }

    // 🔴 GARANTIA CANÔNICA: tenantId OBRIGATÓRIO antes de qualquer chamada de API
    if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
      console.error('[SessionProvider] ❌ ERRO CRÍTICO: tenantId inválido após extração do JWT');
      bootstrapInProgressRef.current = false;
      isBootstrappingRef.current = false;
      setBootstraping(false);
      setIsBootstrapping(false);
      setSessionReady(false);
      return; // Interromper bootstrap - não continuar sem tenantId válido
    }

    console.log('[SessionProvider] ✅ FASE 1 (Auth) concluída: token e tenantId presentes');

    // Marcar que estamos em bootstrap para logs e UI (useState para re-render)
    setIsBootstrapping(true);

    // Marcar que estamos em bootstrap inicial no client.ts
    // Isso previne que 401s durante bootstrap causem logout
    setBootstraping(true);

    try {
      // 🔴 GARANTIA CANÔNICA: tenantId já foi validado acima
      // Esta verificação é redundante mas explícita para clareza arquitetural
      const finalTenantId = getTenantId();
      if (!finalTenantId || finalTenantId !== tenantId) {
        console.error('[SessionProvider] ❌ ERRO CRÍTICO: tenantId perdido após validação inicial');
        bootstrapInProgressRef.current = false;
        isBootstrappingRef.current = false;
        setBootstraping(false);
        setIsBootstrapping(false);
        setSessionReady(false);
        return; // Interromper bootstrap - não continuar sem tenantId válido
      }

      // ============================================
      // FASE 2: CARREGAMENTO DE PERFIL
      // ============================================
      // 🔴 ORDEM DETERMINÍSTICA: Profile deve ser carregado ANTES de actors
      // Profile existe independente de actors - não pode depender de actor
      console.log('[SessionProvider] 🔄 FASE 2 (Perfil): Carregando perfil existente...');
      
      try {
        const profile = await getProfile();
        // Profile carregado com sucesso - não precisa fazer nada além de garantir que foi carregado
        // Profile existente no backend será disponibilizado para componentes via cache/query
        console.log('[SessionProvider] ✅ Perfil carregado:', profile.profileId);
      } catch (err: unknown) {
        const status =
          typeof err === 'object' && err !== null && 'status' in err
            ? (err as any).status
            : undefined;

        const code =
          typeof err === 'object' && err !== null && 'code' in err
            ? (err as any).code
            : undefined;

        // 404 = perfil não existe ainda (primeiro acesso) - estado esperado, não é erro
        if (status === 404 || code === 'NOT_FOUND') {
          // Não logar - é estado esperado (primeiro acesso)
          // Continuar bootstrap - perfil será criado quando necessário
        } else if (status === 401 || code === 'UNAUTHORIZED') {
          // 401 durante carregamento de profile = sessão inválida
          console.error('[SessionProvider] ❌ ERRO CRÍTICO: 401 ao carregar profile durante bootstrap');
          console.error('[SessionProvider] 🔒 Invalidando sessão');

          // INVALIDAÇÃO DE SESSÃO (OBRIGATÓRIA)
          window.dispatchEvent(new Event('auth-changed'));

          // Resetar flags de bootstrap
          bootstrapInProgressRef.current = false;
          isBootstrappingRef.current = false;
          setBootstraping(false);
          setIsBootstrapping(false);

          // Resetar estado de sessão
          setActors([]);
          setSessionReady(false);
          return;
        } else {
          // Outros erros não são críticos - perfil pode não existir ainda
          // Apenas logar se for erro real (não 404)
          if (import.meta.env.DEV) {
            console.warn('[SessionProvider] ⚠️ Falha ao carregar profile durante bootstrap (não crítico):', err);
          }
          // Continuar bootstrap - perfil será carregado quando necessário
        }
      }

      // ============================================
      // FASE 3: CARREGAMENTO DE CONTEXTO (ACTORS)
      // ============================================
      console.log('[SessionProvider] 🔄 FASE 3 (Contexto): Carregando actors disponíveis...');

      // 1. Carregar actors disponíveis
      // IMPORTANTE: Este endpoint é OBRIGATÓRIO para definir activeActor
      // Se falhar, não podemos marcar sessionReady como true
      let availableActors: AvailableActor[] = [];
      try {
        // Durante bootstrap inicial, usar silent401 para evitar ruído no console
        const actorsResult = await getAvailableActors({ silent401: isBootstrappingRef.current });
        // 🔧 FIX: Garantir que availableActors seja sempre um array
        availableActors = Array.isArray(actorsResult) ? actorsResult : [];
        setActors(availableActors);
        console.log(`[SessionProvider] ✅ Actors carregados: ${availableActors.length} encontrado(s)`);
      } catch (err: unknown) {
        const status =
          typeof err === 'object' && err !== null && 'status' in err
            ? (err as any).status
            : undefined;

        const code =
          typeof err === 'object' && err !== null && 'code' in err
            ? (err as any).code
            : undefined;

        if (status === 401 || code === 'UNAUTHORIZED') {
          console.error('[SessionProvider] ❌ ERRO CRÍTICO: 401 ao carregar actors durante bootstrap');
          console.error('[SessionProvider] 🔒 Invalidando sessão');

          // INVALIDAÇÃO DE SESSÃO (OBRIGATÓRIA)
          window.dispatchEvent(new Event('auth-changed'));

          // Resetar flags de bootstrap
          bootstrapInProgressRef.current = false;
          isBootstrappingRef.current = false;
          setBootstraping(false);
          setIsBootstrapping(false);

          // Resetar estado de sessão
          setActors([]);
          setSessionReady(false);
          return;
        }

        console.warn(
          '[SessionProvider] ⚠️ Falha ao carregar actors durante bootstrap (não crítico):',
          err
        );
        // Actors são opcionais - não resetar sessionReady
        // Continuar para marcar sessionReady = true (token + tenantId são suficientes)
        setActors([]);
        setActiveActorState(null);
      }

      // 2. Todos os actors podem postar (can_post sempre true para empresas)
      // 🔧 FIX: Garantir que postableActors seja sempre um array antes de usar métodos de array
      const postableActors = Array.isArray(availableActors) ? availableActors : [];

      // 3. Decisão de activeActor (OBRIGATÓRIO para sessionReady = true)
      // 🔧 FIX: Garantir que sempre selecionamos um actor quando houver disponível
      let selectedActor: AvailableActor | null = null;

      if (postableActors.length === 0) {
        // Sem atores disponíveis - sessão continua válida (actors são opcionais)
        console.warn('[SessionProvider] ⚠️ Nenhum actor disponível - sessão continua válida sem activeActor');
        // Manter actors vazio e activeActor null
        setActors([]);
        setActiveActorState(null);
        // Sessão está pronta mesmo sem actors (token + tenantId são suficientes)
        // Pular seleção de actor e ir direto para marcar sessionReady = true
        selectedActor = null;
      } else if (postableActors.length === 1) {
        // Apenas um ator - selecionar automaticamente
        selectedActor = postableActors[0];
        console.log(`[SessionProvider] ✅ Actor único selecionado: ${selectedActor.display_name} (${selectedActor.actor_id})`);
      } else {
        // Múltiplos atores - usar último usado OU default consistente
        const savedActorId = localStorage.getItem(ACTOR_STORAGE_KEY);
        if (savedActorId) {
          const savedActor = postableActors.find(a => a.actor_id === savedActorId);
          if (savedActor) {
            selectedActor = savedActor;
            console.log(`[SessionProvider] ✅ Actor salvo restaurado: ${selectedActor.display_name} (${selectedActor.actor_id})`);
          }
        }

        // Se não encontrou salvo, usar default: pessoa física primeiro, depois qualquer um
        if (!selectedActor) {
          selectedActor = postableActors.find(a => a.actor_type === 'user') || postableActors[0];
          console.log(`[SessionProvider] ✅ Actor padrão selecionado: ${selectedActor.display_name} (${selectedActor.actor_id})`);
        }
      }

      // 4. Definir activeActor e salvar
      // 🔧 FIX: Garantir que selectedActor seja sempre definido quando houver actors disponíveis
      if (!selectedActor && postableActors.length > 0) {
        // Fallback de segurança: se por algum motivo selectedActor ainda for null, selecionar o primeiro
        selectedActor = postableActors.find(a => a.actor_type === 'user') || postableActors[0];
        console.warn(`[SessionProvider] ⚠️ Fallback: selecionando actor padrão: ${selectedActor.display_name} (${selectedActor.actor_id})`);
      }

      if (selectedActor) {
        // 🔴 ESTABILIDADE: Uma vez definido, activeActor não pode ser resetado para null
        // (exceto em logout explícito)
        setActiveActorState(selectedActor);
        activeActorStableRef.current = selectedActor;
        localStorage.setItem(ACTOR_STORAGE_KEY, selectedActor.actor_id);
        
        console.log(`[SessionProvider] ✅ activeActor definido: ${selectedActor.display_name} (${selectedActor.actor_id})`);
        
        // Disparar evento para componentes que precisam reagir
        window.dispatchEvent(new CustomEvent('active-actor-changed', { 
          detail: { actorId: selectedActor.actor_id, actor: selectedActor } 
        }));
      } else if (postableActors.length > 0) {
        // Se ainda não há selectedActor e há actors disponíveis, algo está errado
        console.error('[SessionProvider] ❌ ERRO CRÍTICO: Há actors disponíveis mas selectedActor é null!', {
          postableActorsLength: postableActors.length,
          postableActors: postableActors
        });
      }
      // Se selectedActor é null E postableActors.length === 0, isso é OK (actors opcionais)

      // ============================================
      // SESSÃO PRONTA: token + tenantId + estado de actor resolvido
      // ============================================
      // REGRA CRÍTICA: sessionReady só é true quando:
      // - token existe
      // - tenantId existe
      // - estado de actor resolvido (definido OU explicitamente ausente)
      // 🔴 ESTABILIDADE: Uma vez true, não pode voltar para false
      
      // 🔴 VALIDAÇÃO FINAL: Garantir que tenantId === jwt.payload.tenantId
      // Esta validação é redundante mas explícita para garantir consistência final
      const finalToken = getAuthToken();
      if (finalToken) {
        try {
          const tokenPayload = JSON.parse(atob(finalToken.split('.')[1]));
          const jwtTenantId = tokenPayload.tenantId;
          const storedTenantId = getTenantId();
          
          // 🔴 GARANTIA CANÔNICA: JWT é fonte de verdade
          if (jwtTenantId && storedTenantId !== jwtTenantId) {
            console.warn('[SessionProvider] ⚠️ tenantId no storage não corresponde ao JWT - corrigindo...');
            setTenantId(jwtTenantId);
            console.log('[SessionProvider] ✅ tenantId corrigido do JWT:', jwtTenantId);
          }
          
          // 🔴 VALIDAÇÃO FINAL: Garantir que tenantId está presente no JWT
          if (!jwtTenantId || typeof jwtTenantId !== 'string' || jwtTenantId.trim() === '') {
            console.error('[SessionProvider] ❌ ERRO CRÍTICO: tenantId ausente no JWT após bootstrap');
            bootstrapInProgressRef.current = false;
            isBootstrappingRef.current = false;
            setBootstraping(false);
            setIsBootstrapping(false);
            setSessionReady(false);
            return; // Interromper bootstrap - não marcar sessionReady sem tenantId válido
          }
        } catch (e) {
          console.error('[SessionProvider] ❌ ERRO CRÍTICO ao validar tenantId do JWT:', e);
          bootstrapInProgressRef.current = false;
          isBootstrappingRef.current = false;
          setBootstraping(false);
          setIsBootstrapping(false);
          setSessionReady(false);
          return; // Interromper bootstrap - não marcar sessionReady sem validação
        }
      } else {
        // 🔴 ERRO FATAL: Token ausente após validação inicial
        console.error('[SessionProvider] ❌ ERRO CRÍTICO: Token perdido após validação inicial');
        bootstrapInProgressRef.current = false;
        isBootstrappingRef.current = false;
        setBootstraping(false);
        setIsBootstrapping(false);
        setSessionReady(false);
        return; // Interromper bootstrap - não marcar sessionReady sem token
      }
      
      // 🔴 GARANTIA CANÔNICA: sessionReady só é true quando token E tenantId estão válidos
      // tenantId já foi validado acima (vem do JWT, não do storage)
      const finalValidationTenantId = getTenantId();
      if (!finalValidationTenantId || typeof finalValidationTenantId !== 'string' || finalValidationTenantId.trim() === '') {
        console.error('[SessionProvider] ❌ ERRO CRÍTICO: tenantId inválido antes de marcar sessionReady');
        bootstrapInProgressRef.current = false;
        isBootstrappingRef.current = false;
        setBootstraping(false);
        setIsBootstrapping(false);
        setSessionReady(false);
        return; // Interromper bootstrap - não marcar sessionReady sem tenantId válido
      }
      
      if (!sessionReadyStableRef.current) {
        setSessionReady(true);
        sessionReadyStableRef.current = true;
        console.log('[SessionProvider] ✅✅✅ sessionReady = true (bootstrap completo - token e tenantId validados)');
      } else {
        console.log('[SessionProvider] ✅ sessionReady já estava true (estabilidade mantida)');
      }
    } catch (err) {
      // Erro no bootstrap é CRÍTICO - não pode marcar sessão como pronta
      console.error('[SessionProvider] ❌ ERRO CRÍTICO no bootstrap:', err);
      // Resetar flags
      bootstrapInProgressRef.current = false;
      isBootstrappingRef.current = false;
      setBootstraping(false);
      setIsBootstrapping(false);
      // NÃO marcar sessionReady - erro no bootstrap invalida a sessão
      setSessionReady(false);
    } finally {
      // Sempre desativar flags de bootstrap após tentativa
      setBootstraping(false);
      setIsBootstrapping(false);
      // Resetar ref síncrono para permitir próxima chamada
      bootstrapInProgressRef.current = false;
      // Marcar que bootstrap não está mais em andamento (401 agora é erro real)
      isBootstrappingRef.current = false;
      console.log('[SessionProvider] 🏁 Bootstrap finalizado');
    }
  };

  const setActiveActor = (actorId: string | null) => {
    if (!actorId) {
      // 🔴 ESTABILIDADE: Permitir reset apenas se não foi definido ainda
      // OU se for logout explícito (verificar se há token)
      const hasToken = isAuthenticated();
      if (!hasToken) {
        // Logout explícito - permitir reset
        setActiveActorState(null);
        activeActorStableRef.current = null;
        localStorage.removeItem(ACTOR_STORAGE_KEY);
        return;
      } else if (!activeActorStableRef.current) {
        // Nunca foi definido - permitir null
        setActiveActorState(null);
        localStorage.removeItem(ACTOR_STORAGE_KEY);
        return;
      } else {
        // 🔴 REGRA: Não permitir reset de activeActor se já foi definido e há token
        console.warn('[SessionProvider] ⚠️ Tentativa de resetar activeActor bloqueada (estabilidade de sessão)');
        return;
      }
    }

    // 🔧 FIX: Garantir que actors seja sempre um array antes de usar métodos de array
    const safeActors = Array.isArray(actors) ? actors : [];
    const actor = safeActors.find(a => a.actor_id === actorId);
    if (actor) {
      // 🔴 REGRA: Não verificar can_post - todas as empresas podem ser selecionadas
      // 🔴 ESTABILIDADE: Atualizar ref estável
      setActiveActorState(actor);
      activeActorStableRef.current = actor;
      localStorage.setItem(ACTOR_STORAGE_KEY, actorId);
      
      // Disparar evento para componentes que precisam reagir
      window.dispatchEvent(new CustomEvent('active-actor-changed', { 
        detail: { actorId, actor } 
      }));
      
      // CONTINUOUS PRODUCTION: Invalidar queries ao trocar actor
      // Isso força recarregamento de dados quando actor muda
      window.dispatchEvent(new CustomEvent('invalidate-queries', { 
        detail: { reason: 'actor-changed', actorId } 
      }));
    }
  };

  /**
   * Refresh de actors - independente do bootstrap
   * Busca actors diretamente do backend e atualiza estado
   * NÃO usa bootstrapSession() para evitar guards
   */
  const refreshActors = async () => {
    // 🔴 GARANTIA CANÔNICA: tenantId OBRIGATÓRIO antes de chamada de API
    // Se não estiver no storage, tentar extrair do JWT
    const token = getAuthToken();
    let tenantId = getTenantId();
    
    if (!tenantId && token) {
      try {
        const tokenPayload = JSON.parse(atob(token.split('.')[1]));
        tenantId = tokenPayload.tenantId;
        
        if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
          setTenantId(tenantId);
          console.log('[SessionProvider] ✅ tenantId extraído do JWT no refreshActors:', tenantId);
        } else {
          console.error('[SessionProvider] ❌ tenantId ausente ou inválido no JWT');
          return; // Não continuar sem tenantId válido
        }
      } catch (e) {
        console.error('[SessionProvider] ❌ ERRO CRÍTICO ao extrair tenantId do JWT no refreshActors:', e);
        return; // Não continuar sem tenantId válido
      }
    }
    
    // 🔴 VALIDAÇÃO FINAL: tenantId deve ser válido
    if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
      console.error('[SessionProvider] ❌ tenantId inválido - pulando refresh de actors');
      return;
    }

    try {
      console.log('[SessionProvider] 🔄 Refresh de actors (sem bootstrap)...');
      
      // Buscar actors diretamente do backend (sem usar bootstrap)
      const actorsResult = await getAvailableActors();
      // 🔧 FIX: Garantir que availableActors seja sempre um array
      const availableActors = Array.isArray(actorsResult) ? actorsResult : [];
      setActors(availableActors);
      
      console.log(`[SessionProvider] ✅ Actors atualizados: ${availableActors.length} encontrado(s)`);
      
      // Atualizar activeActor se ainda existir na nova lista
      if (activeActor) {
        const currentActor = availableActors.find(a => a.actor_id === activeActor.actor_id);
        if (currentActor) {
          // Actor ainda existe - atualizar com dados novos (display_name pode ter mudado)
          // 🔴 ESTABILIDADE: Atualizar ref estável
          setActiveActorState(currentActor);
          activeActorStableRef.current = currentActor;
          localStorage.setItem(ACTOR_STORAGE_KEY, currentActor.actor_id);
          
          console.log(`[SessionProvider] ✅ activeActor atualizado: ${currentActor.display_name} (${currentActor.actor_id})`);
          
          // Disparar evento para componentes que precisam reagir
          window.dispatchEvent(new CustomEvent('active-actor-changed', { 
            detail: { actorId: currentActor.actor_id, actor: currentActor } 
          }));
        } else {
          // Actor não existe mais - selecionar novo
          console.warn('[SessionProvider] ⚠️ activeActor não existe mais, selecionando novo...');
          const firstActor = availableActors.find(a => a.actor_type === 'user') || availableActors[0];
          if (firstActor) {
            // 🔴 ESTABILIDADE: Atualizar ref estável
            setActiveActorState(firstActor);
            activeActorStableRef.current = firstActor;
            localStorage.setItem(ACTOR_STORAGE_KEY, firstActor.actor_id);
            console.log(`[SessionProvider] ✅ Novo activeActor selecionado: ${firstActor.display_name}`);
            
            // Disparar evento para componentes que precisam reagir
            window.dispatchEvent(new CustomEvent('active-actor-changed', { 
              detail: { actorId: firstActor.actor_id, actor: firstActor } 
            }));
          } else {
            // Nenhum actor disponível - manter activeActor se houver token
            const hasToken = isAuthenticated();
            if (!hasToken) {
              // Logout explícito - permitir limpeza
              setActiveActorState(null);
              activeActorStableRef.current = null;
              localStorage.removeItem(ACTOR_STORAGE_KEY);
              console.warn('[SessionProvider] ⚠️ Nenhum actor disponível após refresh (sem token)');
            } else {
              // Há token mas não há actors - manter activeActor (pode ser temporário)
              console.warn('[SessionProvider] ⚠️ Nenhum actor disponível após refresh mas há token - mantendo activeActor');
            }
          }
        }
      } else if (availableActors.length > 0) {
        // Se não há activeActor mas há actors disponíveis, selecionar automaticamente
        const firstActor = availableActors.find(a => a.actor_type === 'user') || availableActors[0];
        if (firstActor) {
          // 🔴 ESTABILIDADE: Atualizar ref estável
          setActiveActorState(firstActor);
          activeActorStableRef.current = firstActor;
          localStorage.setItem(ACTOR_STORAGE_KEY, firstActor.actor_id);
          console.log(`[SessionProvider] ✅ Actor selecionado automaticamente após refresh: ${firstActor.display_name}`);
          
          // Disparar evento para componentes que precisam reagir
          window.dispatchEvent(new CustomEvent('active-actor-changed', { 
            detail: { actorId: firstActor.actor_id, actor: firstActor } 
          }));
        }
      }
      
      console.log('[SessionProvider] ✅ Refresh de actors concluído');
    } catch (err) {
      console.error('[SessionProvider] ❌ Erro ao atualizar actors:', err);
      // Não propagar erro - refresh não é crítico
    }
  };

  // Bootstrap inicial - apenas uma vez na montagem do componente
  // 🔴 CRÍTICO: Usar ref para prevenir execução duplicada em React StrictMode
  const hasInitialBootstrappedRef = useRef(false);
  
  useEffect(() => {
    // Prevenir execução duplicada (React StrictMode executa useEffect duas vezes em DEV)
    // Não logar - é comportamento esperado do React StrictMode em desenvolvimento
    if (hasInitialBootstrappedRef.current) {
      return;
    }
    
    // 🔴 GARANTIA CANÔNICA: Verificar autenticação e tenantId antes de bootstrap
    // Se autenticado mas sem tenantId, tentar extrair do JWT antes de bootstrap
    if (isAuthenticated()) {
      const token = getAuthToken();
      let tenantId = getTenantId();
      
      // 🔴 GARANTIA CANÔNICA: Se tenantId não estiver no storage, extrair do JWT
      if (!tenantId && token) {
        try {
          const tokenPayload = JSON.parse(atob(token.split('.')[1]));
          tenantId = tokenPayload.tenantId;
          
          if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
            setTenantId(tenantId);
            console.log('[SessionProvider] ✅ tenantId extraído do JWT no useEffect inicial:', tenantId);
          } else {
            console.error('[SessionProvider] ❌ tenantId ausente ou inválido no JWT');
            hasInitialBootstrappedRef.current = true;
            setSessionReady(false); // Não marcar como pronto sem tenantId válido
            return;
          }
        } catch (e) {
          console.error('[SessionProvider] ❌ ERRO CRÍTICO ao extrair tenantId do JWT no useEffect inicial:', e);
          hasInitialBootstrappedRef.current = true;
          setSessionReady(false); // Não marcar como pronto sem tenantId válido
          return;
        }
      }
      
      // 🔴 GARANTIA CANÔNICA: tenantId OBRIGATÓRIO antes de bootstrap
      if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
        hasInitialBootstrappedRef.current = true;
        bootstrapSession();
      } else {
        // Token presente mas tenantId inválido - não marcar como pronto
        console.error('[SessionProvider] ❌ tenantId inválido após extração do JWT');
        hasInitialBootstrappedRef.current = true;
        setSessionReady(false);
      }
    } else {
      // Se não estiver autenticado, marcar sessão como pronta (sem bootstrap)
      // Não precisa de tenantId se não há token
      hasInitialBootstrappedRef.current = true;
      setSessionReady(true);
    }
  }, []); // Executar apenas uma vez na montagem

  // Garantir activeActor automático quando actors são carregados
  // 🔧 FIX: Este useEffect garante que activeActor seja sempre definido quando houver actors disponíveis
  useEffect(() => {
    // 🔧 FIX: Garantir que actors seja sempre um array antes de usar métodos de array
    const safeActors = Array.isArray(actors) ? actors : [];
    
    // Se sessionReady, há actors disponíveis, mas activeActor é null:
    // selecionar automaticamente seguindo a mesma lógica do bootstrap
    if (sessionReady && safeActors.length > 0 && !activeActor) {
      let actorToSelect: AvailableActor | null = null;
      
      // Priorizar actor do tipo 'user' se houver múltiplos
      if (safeActors.length === 1) {
        actorToSelect = safeActors[0];
      } else {
        // Múltiplos: tentar restaurar do localStorage primeiro
        const savedActorId = localStorage.getItem(ACTOR_STORAGE_KEY);
        if (savedActorId) {
          const savedActor = safeActors.find(a => a.actor_id === savedActorId);
          if (savedActor) {
            actorToSelect = savedActor;
          }
        }
        
        // Se não encontrou salvo, priorizar 'user', depois qualquer um
        if (!actorToSelect) {
          actorToSelect = safeActors.find(a => a.actor_type === 'user') || safeActors[0];
        }
      }
      
      if (actorToSelect) {
        // 🔴 ESTABILIDADE: Atualizar ref estável
        setActiveActorState(actorToSelect);
        activeActorStableRef.current = actorToSelect;
        localStorage.setItem(ACTOR_STORAGE_KEY, actorToSelect.actor_id);
        console.log(`[SessionProvider] ✅ Actor selecionado automaticamente (useEffect): ${actorToSelect.display_name} (${actorToSelect.actor_id})`);
        
        // Disparar evento para componentes que precisam reagir
        window.dispatchEvent(new CustomEvent('active-actor-changed', { 
          detail: { actorId: actorToSelect.actor_id, actor: actorToSelect } 
        }));
      }
    } else if (sessionReady && (!Array.isArray(actors) || actors.length === 0) && activeActor) {
      // Se não há actors mas há activeActor, limpar
      console.warn('[SessionProvider] ⚠️ Nenhum actor disponível - limpando activeActor');
      setActiveActorState(null);
      localStorage.removeItem(ACTOR_STORAGE_KEY);
    }
  }, [sessionReady, actors.length, activeActor?.actor_id]); // Usar actor_id para evitar loops

  // Re-bootstrap quando autenticação mudar (login/logout) ou empresa for criada/removida
  useEffect(() => {
    // Guard para prevenir múltiplos bootstraps simultâneos
    let isHandling = false;

    const handleAuthChange = () => {
      // Prevenir múltiplas chamadas simultâneas
      if (isHandling) {
        console.warn('[SessionProvider] handleAuthChange já em andamento, ignorando...');
        return;
      }

      isHandling = true;
      
      // 🔴 GARANTIA CANÔNICA: Verificar token E tenantId antes de fazer bootstrap
      // Se autenticado mas sem tenantId, tentar extrair do JWT antes de bootstrap
      if (isAuthenticated()) {
        const token = getAuthToken();
        let tenantId = getTenantId();
        
        // 🔴 GARANTIA CANÔNICA: Se tenantId não estiver no storage, extrair do JWT
        if (!tenantId && token) {
          try {
            const tokenPayload = JSON.parse(atob(token.split('.')[1]));
            tenantId = tokenPayload.tenantId;
            
            if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
              setTenantId(tenantId);
              console.log('[SessionProvider] ✅ tenantId extraído do JWT no handleAuthChange:', tenantId);
            } else {
              console.error('[SessionProvider] ❌ tenantId ausente ou inválido no JWT');
              // Não marcar como pronto sem tenantId válido
              setActiveActorState(null);
              activeActorStableRef.current = null;
              setActors([]);
              setSessionReady(false);
              sessionReadyStableRef.current = false;
              isHandling = false;
              return;
            }
          } catch (e) {
            console.error('[SessionProvider] ❌ ERRO CRÍTICO ao extrair tenantId do JWT no handleAuthChange:', e);
            // Não marcar como pronto sem tenantId válido
            setActiveActorState(null);
            activeActorStableRef.current = null;
            setActors([]);
            setSessionReady(false);
            sessionReadyStableRef.current = false;
            isHandling = false;
            return;
          }
        }
        
        // 🔴 GARANTIA CANÔNICA: tenantId OBRIGATÓRIO antes de bootstrap
        if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
          // Pequeno delay para garantir que localStorage foi atualizado
          setTimeout(() => {
            bootstrapSession();
            isHandling = false;
          }, 100);
        } else {
          // Token presente mas tenantId inválido - não marcar como pronto
          console.error('[SessionProvider] ❌ tenantId inválido após extração do JWT');
          setActiveActorState(null);
          activeActorStableRef.current = null;
          setActors([]);
          setSessionReady(false);
          sessionReadyStableRef.current = false;
          isHandling = false;
        }
      } else {
        // Se não estiver autenticado, limpar estado
        // 🔴 ESTABILIDADE: Resetar refs estáveis apenas em logout
        setActiveActorState(null);
        activeActorStableRef.current = null;
        setActors([]);
        // Resetar sessionReady apenas se não estava estável antes
        if (sessionReadyStableRef.current) {
          setSessionReady(false);
          sessionReadyStableRef.current = false;
        } else {
          // Não autenticado - marcar como pronto (não precisa de tenantId)
          setSessionReady(true);
        }
        isHandling = false;
      }
    };

    const handleCompanyChange = () => {
      // Recarregar actors quando empresa for criada ou removida
      // 🔴 GARANTIA CANÔNICA: Não fazer bootstrap sem tenantId válido
      if (isAuthenticated() && !isHandling) {
        const token = getAuthToken();
        let tenantId = getTenantId();
        
        // 🔴 GARANTIA CANÔNICA: Se tenantId não estiver no storage, extrair do JWT
        if (!tenantId && token) {
          try {
            const tokenPayload = JSON.parse(atob(token.split('.')[1]));
            tenantId = tokenPayload.tenantId;
            
            if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
              setTenantId(tenantId);
              console.log('[SessionProvider] ✅ tenantId extraído do JWT no handleCompanyChange:', tenantId);
            } else {
              console.error('[SessionProvider] ❌ tenantId ausente ou inválido no JWT');
              return; // Não continuar sem tenantId válido
            }
          } catch (e) {
            console.error('[SessionProvider] ❌ ERRO CRÍTICO ao extrair tenantId do JWT no handleCompanyChange:', e);
            return; // Não continuar sem tenantId válido
          }
        }
        
        // 🔴 VALIDAÇÃO FINAL: tenantId deve ser válido
        if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
          isHandling = true;
          bootstrapSession().finally(() => {
            isHandling = false;
          });
        }
      }
    };

    // Escutar mudanças no localStorage (login/logout de outras abas)
    window.addEventListener('storage', handleAuthChange);
    
    // Escutar evento customizado de login
    window.addEventListener('auth-changed', handleAuthChange);
    
    // Escutar evento de mudança de empresa
    window.addEventListener('company-changed', handleCompanyChange);

    return () => {
      window.removeEventListener('storage', handleAuthChange);
      window.removeEventListener('auth-changed', handleAuthChange);
      window.removeEventListener('company-changed', handleCompanyChange);
    };
  }, []);

  return (
    <SessionContext.Provider
      value={{
        sessionReady,
        activeActor,
        actors,
        setActiveActor,
        refreshActors,
      }}
    >
      {children}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const context = useContext(SessionContext);
  if (context === undefined) {
    throw new Error('useSession deve ser usado dentro de SessionProvider');
  }
  return context;
}

