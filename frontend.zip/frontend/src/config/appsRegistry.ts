// src/config/appsRegistry.ts
// FONTE ÚNICA DE VERDADE para aplicativos do sistema
// Home é um launcher - nenhum app pode ser hardcoded fora deste registry

export type AppContext = 'pf' | 'pj' | 'group' | 'channel';
export type AppStatus = 'ready' | 'wip';

export interface AppDefinition {
  id: string;
  name: string;
  icon: string;
  route: string;
  contexts: AppContext[];
  status: AppStatus;
  category:
    | 'core'
    | 'finance'
    | 'commerce'
    | 'mobility'
    | 'hospitality'
    | 'services'
    | 'social'
    | 'governance'
    | 'system';
}

export const APPS_REGISTRY: AppDefinition[] = [
  // CORE
  {
    id: 'social',
    name: 'Rede Social',
    icon: '💬',
    route: '/social',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'core',
  },
  {
    id: 'profile',
    name: 'Perfil',
    icon: '👤',
    route: '/perfil',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'core',
  },
  {
    id: 'companies',
    name: 'Empresas',
    icon: '🏢',
    route: '/empresas',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'core',
  },

  // FINANCEIRO
  {
    id: 'bank',
    name: 'UnifyBank',
    icon: '🏦',
    route: '/bank',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'finance',
  },
  {
    id: 'card',
    name: 'UnifyCard',
    icon: '💳',
    route: '/em-desenvolvimento?feature=card',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'finance',
  },
  {
    id: 'regional-fund',
    name: 'Fundo Regional',
    icon: '🌱',
    route: '/fundo-regional',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'finance',
  },

  // COMÉRCIO
  {
    id: 'marketplace',
    name: 'Mercado & Shop',
    icon: '🛒',
    route: '/marketplace',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'commerce',
  },
  {
    id: 'food',
    name: 'Pedir Comida',
    icon: '🍕',
    route: '/em-desenvolvimento?feature=food',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'commerce',
  },

  // MOBILIDADE & VIAGEM
  {
    id: 'mobility',
    name: 'Mobilidade',
    icon: '🚗',
    route: '/em-desenvolvimento?feature=mobility',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'mobility',
  },
  {
    id: 'tickets',
    name: 'Passagens',
    icon: '✈️',
    route: '/em-desenvolvimento?feature=tickets',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'mobility',
  },
  {
    id: 'hosting',
    name: 'Hospedagem',
    icon: '🏨',
    route: '/em-desenvolvimento?feature=hosting',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'hospitality',
  },

  // EXPERIÊNCIAS & SERVIÇOS
  {
    id: 'events',
    name: 'Eventos',
    icon: '🎭',
    route: '/eventos',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'services',
  },
  {
    id: 'services',
    name: 'Serviços',
    icon: '🔧',
    route: '/em-desenvolvimento?feature=services',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'services',
  },
  {
    id: 'communities',
    name: 'Comunidades',
    icon: '👥',
    route: '/em-desenvolvimento?feature=communities',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'social',
  },

  // GOVERNANÇA (SEMPRE VISÍVEL, INDEPENDENTE DE PERFIL)
  {
    id: 'votes',
    name: 'Votações',
    icon: '🗳️',
    route: '/votes',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'governance',
  },
  {
    id: 'projects',
    name: 'Projetos',
    icon: '📋',
    route: '/em-desenvolvimento?feature=projects',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'governance',
  },
  {
    id: 'transparency',
    name: 'Transparência',
    icon: '🔍',
    route: '/em-desenvolvimento?feature=transparency',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'governance',
  },
  {
    id: 'accountability',
    name: 'Prestação de Contas',
    icon: '📑',
    route: '/em-desenvolvimento?feature=accountability',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'governance',
  },

  // NEGÓCIOS (APENAS CONTEXTO PJ)
  {
    id: 'crm',
    name: 'CRM',
    icon: '📊',
    route: '/em-desenvolvimento?feature=crm',
    contexts: ['pj'],
    status: 'wip',
    category: 'system',
  },
  {
    id: 'erp',
    name: 'ERP',
    icon: '📈',
    route: '/em-desenvolvimento?feature=erp',
    contexts: ['pj'],
    status: 'wip',
    category: 'system',
  },
  {
    id: 'orders',
    name: 'Pedidos',
    icon: '📦',
    route: '/em-desenvolvimento?feature=orders',
    contexts: ['pj'],
    status: 'wip',
    category: 'commerce',
  },
  {
    id: 'analytics',
    name: 'Analytics',
    icon: '📉',
    route: '/em-desenvolvimento?feature=analytics',
    contexts: ['pj'],
    status: 'wip',
    category: 'system',
  },

  // SISTEMA
  {
    id: 'config',
    name: 'Configurações',
    icon: '⚙️',
    route: '/em-desenvolvimento?feature=config',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'wip',
    category: 'system',
  },
  {
    id: 'admin',
    name: 'Admin',
    icon: '🔧',
    route: '/admin',
    contexts: ['pf', 'pj', 'group', 'channel'],
    status: 'ready',
    category: 'system',
  },
];

/**
 * Mapeia actor_type do sistema para AppContext
 */
export function mapActorTypeToContext(actorType: string): AppContext {
  const mapping: Record<string, AppContext> = {
    user: 'pf',
    page: 'pj',
    group: 'group',
    channel: 'channel',
  };
  return mapping[actorType] || 'pf';
}

/**
 * Filtra apps por contexto do ator ativo
 */
export function getAppsForContext(context: AppContext | null): AppDefinition[] {
  if (!context) {
    return APPS_REGISTRY.filter((app) => app.contexts.includes('pf'));
  }
  return APPS_REGISTRY.filter((app) => app.contexts.includes(context));
}

/**
 * Busca app por ID
 */
export function getAppById(id: string): AppDefinition | undefined {
  return APPS_REGISTRY.find((app) => app.id === id);
}

/**
 * Busca apps por nome (para autocomplete)
 */
export function searchAppsByName(query: string): AppDefinition[] {
  const normalizedQuery = query.toLowerCase().trim();
  if (!normalizedQuery) return [];
  
  return APPS_REGISTRY.filter((app) =>
    app.name.toLowerCase().includes(normalizedQuery)
  );
}

