// src/api/inference.ts
// API de inferências e sugestões contextuais

import { apiFetch } from './client';

export type UserState = 
  | 'explorer'
  | 'curious'
  | 'in_transition'
  | 'professional_training'
  | 'professional_stable'
  | 'at_risk';

export interface InferenceSuggestion {
  id: string;
  type: 'physical_to_learning' | 'learning_to_professional' | 'professional_needs_physical' | 'learning_stagnant';
  title: string;
  message: string;
  actionLabel?: string;
  actionUrl?: string;
  categoryId?: string;
  categoryName?: string;
  categoryPath?: string[];
  priority: number;
  dismissible: boolean;
  shownCount?: number;
  lastShown?: string;
}

export interface InferenceResult {
  userState: UserState;
  suggestions: InferenceSuggestion[];
  insights: {
    hasPhysicalWithoutLearning: boolean;
    hasLearningWithoutProfessional: boolean;
    hasProfessionalWithoutPhysical: boolean;
    learningStagnant: boolean;
  };
}

export interface SuggestionAction {
  suggestionId: string;
  action: 'accept' | 'dismiss';
}

export async function getInferences(): Promise<InferenceResult> {
  const response = await apiFetch('/profile/inference');
  const result = await response.json();
  if (!result.ok) {
    throw new Error(result.message || 'Erro ao buscar inferências');
  }
  return result.data;
}

export async function recordSuggestionAction(action: SuggestionAction): Promise<void> {
  const response = await apiFetch('/profile/inference/action', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(action),
  });
  const result = await response.json();
  if (!result.ok) {
    throw new Error(result.message || 'Erro ao registrar ação');
  }
}


























