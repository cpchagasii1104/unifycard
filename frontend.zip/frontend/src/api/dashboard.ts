// frontend/src/api/dashboard.ts
// SPRINT 49: API client para dashboards operacionais

import { apiFetch } from './client';

export interface DashboardFilters {
  startDate?: string;
  endDate?: string;
  actorId?: string;
  channel?: 'PDV' | 'MARKETPLACE' | 'ALL';
  // SPRINT 51: Multi-empresa e consolidação
  organizationUnitId?: string;
  consolidated?: boolean;
}

export interface TodayOverview {
  date: string;
  sales: {
    totalOrders: number;
    totalAmount: number;
    totalPaid: number;
    averageTicket: number;
  };
  inventory: {
    totalVariants: number;
    lowStockCount: number;
    outOfStockCount: number;
  };
  financial: {
    totalReceived: number;
    pendingAmount: number;
    failedAmount: number;
  };
}

export interface MonthOverview {
  month: string;
  sales: {
    totalOrders: number;
    totalAmount: number;
    totalPaid: number;
    averageTicket: number;
  };
  financial: {
    totalReceived: number;
    totalPaidOut: number;
    platformFees: number;
  };
  trends: {
    dailySales: Array<{
      date: string;
      amount: number;
      orders: number;
    }>;
  };
}

export interface ChannelSplit {
  channel: 'PDV' | 'MARKETPLACE';
  sales: {
    totalOrders: number;
    totalAmount: number;
    totalPaid: number;
    averageTicket: number;
  };
  percentage: number;
}

export interface DashboardOverview {
  today: TodayOverview;
  month: MonthOverview;
  channels: ChannelSplit[];
  inventory: {
    totalVariants: number;
    lowStockCount: number;
    outOfStockCount: number;
    criticalVariants: Array<{
      variantId: string;
      variantName: string;
      currentQuantity: number;
      reservedQuantity: number;
      availableQuantity: number;
    }>;
  };
}

/**
 * Obtém visão geral do dashboard
 */
export async function getDashboardOverview(
  filters?: DashboardFilters
): Promise<DashboardOverview> {
  const params = new URLSearchParams();
  if (filters?.actorId) params.append('actorId', filters.actorId);
  if (filters?.channel) params.append('channel', filters.channel);
  // SPRINT 51: Filtros de consolidação
  if (filters?.organizationUnitId) params.append('organizationUnitId', filters.organizationUnitId);
  if (filters?.consolidated) params.append('consolidated', 'true');

  const query = params.toString();
  const response = await apiFetch(`/dashboard/overview${query ? `?${query}` : ''}`);
  return response.json();
}

/**
 * Obtém visão do dia
 */
export async function getTodayOverview(
  filters?: DashboardFilters
): Promise<TodayOverview> {
  const params = new URLSearchParams();
  if (filters?.actorId) params.append('actorId', filters.actorId);
  if (filters?.channel) params.append('channel', filters.channel);

  const query = params.toString();
  const response = await apiFetch(`/dashboard/today${query ? `?${query}` : ''}`);
  return response.json();
}

/**
 * Obtém visão do mês
 */
export async function getMonthOverview(
  filters?: DashboardFilters
): Promise<MonthOverview> {
  const params = new URLSearchParams();
  if (filters?.actorId) params.append('actorId', filters.actorId);
  if (filters?.channel) params.append('channel', filters.channel);

  const query = params.toString();
  const response = await apiFetch(`/dashboard/month${query ? `?${query}` : ''}`);
  return response.json();
}

/**
 * Obtém dashboard de vendas
 */
export async function getSalesDashboard(filters?: DashboardFilters): Promise<any> {
  const params = new URLSearchParams();
  if (filters?.startDate) params.append('startDate', filters.startDate);
  if (filters?.endDate) params.append('endDate', filters.endDate);
  if (filters?.actorId) params.append('actorId', filters.actorId);
  if (filters?.channel) params.append('channel', filters.channel);

  const query = params.toString();
  const response = await apiFetch(`/dashboard/sales${query ? `?${query}` : ''}`);
  return response.json();
}

/**
 * Obtém dashboard de estoque
 */
export async function getInventoryDashboard(filters?: DashboardFilters): Promise<any> {
  const params = new URLSearchParams();
  if (filters?.actorId) params.append('variantId', filters.actorId || '');

  const query = params.toString();
  const response = await apiFetch(`/dashboard/inventory${query ? `?${query}` : ''}`);
  return response.json();
}

// Backwards compatibility - flexible type for Dashboard.tsx
export type DashboardData = Record<string, any>;

/**
 * Obtém dashboard do usuário (perfil, wallet, reputação, fundo)
 * Esta é a API para o Dashboard.tsx principal, NÃO para DashboardPage.tsx
 */
export async function getDashboard(): Promise<DashboardData> {
  const response = await apiFetch('/dashboard');
  if (!response.ok) {
    throw new Error(`Erro ao carregar dashboard: ${response.status}`);
  }
  const result = await response.json();
  // API retorna { ok: true, data: {...} } ou diretamente os dados
  return result.data || result;
}
