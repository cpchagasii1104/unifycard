// src/api/client.ts
import { getAuthToken, getTenantId } from '../config/auth';

// Usar valor padrão se não estiver configurado (desenvolvimento local)
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

// Aviso apenas em console, não quebra o sistema
if (!import.meta.env.VITE_API_BASE_URL) {
  console.warn('[API] VITE_API_BASE_URL não configurada, usando padrão:', API_BASE_URL);
  console.warn('[API] Para configurar, crie arquivo .env na pasta frontend/ com: VITE_API_BASE_URL=http://localhost:3000');
}

// Flag global para indicar se estamos em bootstrap inicial (após login)
// Durante bootstrap, 401s não devem causar logout
let isBootstraping = false;
let bootstrapStartTime = 0;
const BOOTSTRAP_GRACE_PERIOD = 5000; // 5 segundos após login

export function setBootstraping(value: boolean) {
  isBootstraping = value;
  if (value) {
    bootstrapStartTime = Date.now();
  }
}

export function isInBootstrapGracePeriod(): boolean {
  if (!isBootstraping) return false;
  return Date.now() - bootstrapStartTime < BOOTSTRAP_GRACE_PERIOD;
}

// 🔴 ESTABILIZAÇÃO DE SESSÃO: Lista explícita de endpoints NÃO-CRÍTICOS para 401
// Estes endpoints podem retornar 401 sem limpar a sessão
// Critérios: token presente + sessão autenticada + endpoint na lista
const NON_CRITICAL_401_ENDPOINTS = [
  '/profile/progress',
  '/profile/inference',
  '/plan',
  // ✅ FIX: REMOVIDO daqui porque é endpoint CRÍTICO pro bootstrap
  // '/social/actors/available',
] as const;

/**
 * Verifica se um endpoint é considerado NÃO-CRÍTICO para 401
 * @param path Caminho do endpoint
 * @returns true se o endpoint está na lista de não-críticos
 */
function isNonCritical401Endpoint(path: string): boolean {
  return NON_CRITICAL_401_ENDPOINTS.some(endpoint => path.includes(endpoint));
}

/**
 * Verifica se um 401 deve ser tratado como CRÍTICO (limpar sessão) ou NÃO-CRÍTICO (apenas logar)
 * @param path Caminho do endpoint
 * @param errorMessage Mensagem de erro da resposta
 * @returns true se for 401 CRÍTICO (deve limpar sessão)
 */
function isCritical401(path: string, errorMessage: string): boolean {
  // 1. Endpoints de identidade/autenticação são SEMPRE críticos
  if (path.startsWith('/auth/') || path.startsWith('/session/') || path === '/auth/me') {
    return true;
  }
  
  // 2. Mensagem explícita de token inválido/expirado é SEMPRE crítica
  const expiredKeywords = [
    'expired',
    'expirada',
    'invalid or expired token',
    'token expired',
    'token inválido',
    'token invalido',
  ];
  const isExplicitlyExpired = expiredKeywords.some(keyword => 
    errorMessage.toLowerCase().includes(keyword.toLowerCase())
  );
  if (isExplicitlyExpired) {
    return true;
  }
  
  // 3. Se endpoint está na lista de não-críticos, não é crítico
  if (isNonCritical401Endpoint(path)) {
    return false;
  }
  
  // 4. Por padrão, outros 401s são críticos (comportamento conservador)
  return true;
}

export interface ApiFetchContextOptions {
  silent401?: boolean;
  silent404?: boolean; // Tratar 404 como feature indisponível (não erro)
}

export async function apiFetch(
  path: string, 
  options: RequestInit = {},
  contextOptions?: ApiFetchContextOptions
): Promise<Response> {
  const url = `${API_BASE_URL}${path}`;
  
  // Se body for FormData, não definir Content-Type (browser define automaticamente com boundary)
  const isFormData = options.body instanceof FormData;
  
  const headers: Record<string, string> = {
    ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers as Record<string, string>),
  };

  // Adicionar token de autenticação se existir
  const token = getAuthToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // 🔴 INVARIANTE ABSOLUTA: tenantId é OBRIGATÓRIO após autenticação
  // JWT é a fonte única de verdade - storage é apenas cache
  // Nenhuma request autenticada pode prosseguir sem tenantId válido
  
  // FASE 1: Tentar obter do storage (cache)
  let tenantId = getTenantId();
  
  // FASE 2: Se não estiver no storage E houver token, extrair do JWT (UMA VEZ)
  // Após extrair e salvar, nunca re-extrai (storage é atualizado imediatamente)
  if (!tenantId && token) {
    try {
      const tokenPayload = JSON.parse(atob(token.split('.')[1]));
      tenantId = tokenPayload.tenantId;
      
      // 🔴 VALIDAÇÃO EXPLÍCITA: tenantId deve ser string não vazia
      if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
        throw new Error('tenantId ausente ou inválido no JWT');
      }
      
      // 🔴 SALVAR IMEDIATAMENTE: Persistir no storage para próximas requisições
      // Após salvar, nunca re-extrai (storage é atualizado)
      const { setTenantId } = await import('../config/auth');
      setTenantId(tenantId);
      // Log apenas em desenvolvimento para diagnóstico
      if (import.meta.env.DEV) {
        console.log('[API] tenantId extraído do JWT e salvo no storage');
      }
    } catch (e) {
      // 🔴 ERRO FATAL: Não continuar sem tenantId válido
      const errorMessage = e instanceof Error ? e.message : 'Falha ao extrair tenantId do JWT';
      const error = new Error(`TENANT_ID_REQUIRED: ${errorMessage}`) as any;
      error.code = 'MISSING_TENANT';
      error.status = 400;
      error.details = { 
        tokenPresent: !!token, 
        extractionFailed: true,
        path 
      };
      throw error;
    }
  }
  
  // 🔴 INVARIANTE ABSOLUTA: Se não houver tenantId após tentativas, ERRO FATAL
  // Nenhuma request autenticada pode prosseguir sem tenantId
  if (!tenantId) {
    const error = new Error('TENANT_ID_REQUIRED: tenantId ausente — estado inválido de sessão') as any;
    error.code = 'MISSING_TENANT';
    error.status = 400;
    error.details = { 
      tokenPresent: !!token,
      path 
    };
    throw error;
  }
  
  // 🔴 GARANTIA FINAL: tenantId válido - sempre enviar header
  headers['x-tenant-id'] = tenantId;

  // 🔴 INVARIANTE ABSOLUTA: x-acting-actor-id só é enviado APÓS tenantId estar validado
  // Actor nunca existe fora de tenant válido - garantir ordem determinística
  // Backend espera x-acting-actor-id (não x-actor-id) para action context
  // Prioridade: header explícito > localStorage > não enviar (não quebra)
  const ACTOR_STORAGE_KEY = 'unificard_active_actor_id';
  const explicitActorId = (options.headers as Record<string, string>)?.['x-acting-actor-id'] 
    || (options.headers as Record<string, string>)?.['x-actor-id']; // Fallback para compatibilidade
  const storedActorId = localStorage.getItem(ACTOR_STORAGE_KEY);
  
  // 🔴 GARANTIA: Actor só é enviado se tenantId já estiver validado
  // tenantId foi validado acima (linha 158-167) - garantia de ordem determinística
  if (explicitActorId) {
    headers['x-acting-actor-id'] = explicitActorId;
  } else if (storedActorId) {
    headers['x-acting-actor-id'] = storedActorId;
  }
  // Se não houver actorId, não enviar header (backend retornará erro claro se necessário)
  
  // 🔴 DIAGNÓSTICO: Log apenas em desenvolvimento e apenas para endpoints específicos
  // Eliminar logs ambíguos - apenas informações essenciais
  if (import.meta.env.DEV && (path.includes('/autocomplete') || path.includes('/categories/tree'))) {
    console.log('[apiFetch]', {
      path,
      tenantId: headers['x-tenant-id'] ? 'present' : 'MISSING',
      hasToken: !!token
    });
  }

  let response: Response;
  try {
    // 🔴 TIMEOUT OTIMIZADO: Backend agora tenta BrasilAPI primeiro (5s) + ViaCEP fallback (8s)
    // Total máximo: ~13s, mas geralmente responde em 1-3s
    const timeoutMs = path.includes('/location/cep/') ? 15000 : 10000;
    
    response = await fetch(url, {
      ...options,
      headers,
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    // Erro de rede (Failed to fetch) - mensagem mais amigável
    if (error instanceof TypeError && error.message.includes('fetch')) {
      // Não lançar erro imediatamente - deixar o sistema tentar reconectar
      // Apenas logar no console para debug
      console.warn('[API] Backend não disponível, tentando reconectar...', API_BASE_URL);
      
      // Retornar uma resposta de erro amigável que não quebra o sistema
      const friendlyMessage = 'Aguardando conexão com o servidor...';
      const errorObj = new Error(friendlyMessage) as any;
      errorObj.code = 'BACKEND_OFFLINE';
      errorObj.isRetryable = true;
      throw errorObj;
    }
    
    // Timeout - mensagem mais amigável
    if (error instanceof Error && error.name === 'AbortError') {
      console.warn('[API] Timeout ao conectar:', API_BASE_URL);
      const errorObj = new Error('Aguardando conexão com o servidor...') as any;
      errorObj.code = 'BACKEND_OFFLINE';
      errorObj.isRetryable = true;
      throw errorObj;
    }
    
    throw error;
  }

  if (!response.ok) {
    // Tentar extrair mensagem de erro da resposta primeiro
    let errorMessage = `HTTP ${response.status}`;
    let errorDetails: any = null;
    
    try {
      errorDetails = await response.json();
      
      // 🔴 DIAGNÓSTICO: Log apenas em desenvolvimento e apenas para erros críticos
      if (import.meta.env.DEV && (path.includes('/autocomplete') || path.includes('/categories/tree'))) {
        console.error('[apiFetch] ERROR:', {
          path,
          status: response.status,
          error: errorDetails.error || errorDetails.message
        });
      }
      
      // Priorizar mensagem específica do backend (suporta ambos os formatos)
      errorMessage = errorDetails.message || errorDetails.error || errorMessage;
      
      // Preservar código de erro se disponível
      const error = new Error(errorMessage) as any;
      if (errorDetails.code) {
        error.code = errorDetails.code;
      }
      
      // Tratamento especial para 404 (feature indisponível)
      if (response.status === 404) {
        // Se silent404 estiver ativado, tratar silenciosamente
        if (contextOptions?.silent404) {
          const silentError = new Error('FEATURE_UNAVAILABLE') as any;
          silentError.status = 404;
          silentError.code = 'FEATURE_UNAVAILABLE';
          // Não logar - feature simplesmente não está disponível
          throw silentError;
        }
      }

      // 🔴 ESTABILIZAÇÃO DE SESSÃO: Tratamento especial para 401
      if (response.status === 401) {
        // Se silent401 estiver ativado, tratar silenciosamente (sem acesso bancário, etc)
        if (contextOptions?.silent401) {
          const silentError = new Error('FEATURE_UNAVAILABLE') as any;
          silentError.status = 401;
          silentError.code = 'FEATURE_UNAVAILABLE';
          // Não logar - é condição esperada (ex: sem escopo bancário)
          throw silentError;
        }
        
        // 🔴 VALIDAÇÃO: Verificar se token está presente e sessão está autenticada
        // tenantId já foi validado acima (invariante absoluta - sempre presente após autenticação)
        const token = getAuthToken();
        const tenantId = getTenantId();
        const hasToken = !!token;
        // 🔴 GARANTIA: tenantId sempre presente após autenticação (invariante)
        const isAuthenticated = hasToken && !!tenantId;
        
        // Verificar se está em bootstrap grace period
        const inBootstrap = isInBootstrapGracePeriod();
        
        // ✅ FIX: Durante bootstrap, 401 é sessão inválida (não ignorar)
        if (inBootstrap) {
          console.error('[API] ❌ 401 durante bootstrap - sessão inválida:', path);
          const { clearSession } = await import('../config/auth');
          clearSession();
          throw new Error('Sessão expirada. Por favor, faça login novamente.');
        }
        
        // 🔴 REGRA: Verificar se é 401 CRÍTICO ou NÃO-CRÍTICO
        const isCritical = isCritical401(path, errorMessage);
        
        // Se for CRÍTICO: limpar sessão
        if (isCritical) {
          console.error('[API] ❌ 401 CRÍTICO - limpando sessão:', path);
          const { clearSession } = await import('../config/auth');
          clearSession();
          throw new Error('Sessão expirada. Por favor, faça login novamente.');
        }
        
        // Se for NÃO-CRÍTICO: verificar critérios obrigatórios
        // TODOS devem ser verdadeiros para não limpar sessão:
        // 1. Token presente
        // 2. Sessão autenticada (token + tenantId)
        // 3. Endpoint na lista de não-críticos
        if (hasToken && isAuthenticated && isNonCritical401Endpoint(path)) {
          // 🔴 REGRA: 401 NÃO-CRÍTICO - NÃO limpar sessão
          // Apenas logar warning e propagar erro
          console.warn('[API] ⚠️ 401 NÃO-CRÍTICO (não limpar sessão):', path);
          // Propagar erro para caller (componente deve tratar)
          throw error;
        } else {
          // Se não atende critérios de não-crítico, tratar como crítico
          console.error('[API] ❌ 401 sem critérios de não-crítico - limpando sessão:', path);
          const { clearSession } = await import('../config/auth');
          clearSession();
          throw new Error('Sessão expirada. Por favor, faça login novamente.');
        }
      }
      
      throw error;
    } catch (parseError: any) {
      // Se não conseguir parsear JSON, usar status
      // Se já foi lançado erro acima, re-lançar
      if (parseError.code || parseError.message) {
        throw parseError;
      }
      errorMessage = `Erro ${response.status}: ${response.statusText || 'Erro desconhecido'}`;
      const error = new Error(errorMessage) as any;
      // Tentar inferir código baseado no status
      if (response.status === 400) {
        error.code = 'BAD_REQUEST';
      } else if (response.status === 401) {
        error.code = 'UNAUTHORIZED';
      } else if (response.status === 403) {
        error.code = 'FORBIDDEN';
      } else if (response.status >= 500) {
        error.code = 'INTERNAL_ERROR';
      }
      throw error;
    }
  }

  return response;
}

/**
 * Wrapper para apiFetch que retorna JSON tipado diretamente.
 * Valida response.ok e retorna o JSON parseado.
 */
export async function apiFetchJson<T>(
  path: string, 
  options: RequestInit = {},
  contextOptions?: ApiFetchContextOptions
): Promise<T> {
  const response = await apiFetch(path, options, contextOptions);
  if (!response.ok) {
    // apiFetch já lança erro para !response.ok, mas garantimos aqui também
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }
  return response.json() as Promise<T>;
}

