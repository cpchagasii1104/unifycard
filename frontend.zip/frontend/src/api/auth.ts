// src/api/auth.ts
// API de autenticação - Registro e Login

import { apiFetch } from './client';

// Usar valor padrão se não estiver configurado (desenvolvimento local)
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

// Aviso apenas em console, não quebra o sistema
if (!import.meta.env.VITE_API_BASE_URL) {
  console.warn('[API] VITE_API_BASE_URL não configurada, usando padrão:', API_BASE_URL);
}

export interface RegisterRequest {
  email: string;
  password: string;
  cpf?: string;
  referralCode?: string;
  // 🔴 DADOS CIVIS IMUTÁVEIS (coletados no cadastro)
  fullName?: string;
  birthdate?: string; // YYYY-MM-DD
  gender?: 'male' | 'female';
}

export interface LoginRequest {
  email: string;
  password: string;
  // tenantId é enviado via header x-tenant-id, não no body
}

export interface AuthResponse {
  success: boolean;
  data: {
    user: {
      userId: string;
      email: string;
    };
    tokens: {
      accessToken: string;
      refreshToken: string;
    };
    tenantId?: string;
    requiresOnboarding?: boolean; // 🔴 PARTE 2 - ONBOARDING: Flag de primeiro acesso
  };
}

export async function register(
  email: string,
  password: string,
  cpf?: string,
  referralCode?: string,
  fullName?: string,
  birthdate?: string,
  gender?: 'male' | 'female'
): Promise<AuthResponse> {
  let response: Response;
  
  try {
    const body: RegisterRequest = { email, password };
    if (cpf) {
      body.cpf = cpf;
    }
    if (referralCode) {
      body.referralCode = referralCode;
    }
    // 🔴 DADOS CIVIS IMUTÁVEIS
    if (fullName) {
      body.fullName = fullName;
    }
    if (birthdate) {
      body.birthdate = birthdate;
    }
    if (gender) {
      body.gender = gender;
    }
    
    response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
  } catch (error) {
    // Erro de rede (Failed to fetch)
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.warn('[API] Backend não disponível:', API_BASE_URL);
      const friendlyMessage = 'Aguardando conexão com o servidor...';
      const errorObj = new Error(friendlyMessage) as any;
      errorObj.code = 'BACKEND_OFFLINE';
      errorObj.isRetryable = true;
      throw errorObj;
    }
    throw error;
  }

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Erro ao registrar' }));
    // Suporta ambos os formatos: { error: ... } e { ok: false, message: ... }
    const errorMessage = error.message || error.error || `HTTP ${response.status}`;
    const errorObj = new Error(errorMessage) as Error & { statusCode?: number };
    errorObj.statusCode = response.status;
    throw errorObj;
  }

  return response.json();
}

// Guard para prevenir múltiplas chamadas simultâneas de login
let loginInProgress = false;
let loginPromise: Promise<AuthResponse> | null = null;

export async function login(email: string, password: string, tenantId?: string): Promise<AuthResponse> {
  // 🔴 GARANTIA CANÔNICA: Login NUNCA deve enviar tenantId
  // tenantId vem do JWT após login bem-sucedido
  if (tenantId) {
    console.warn('[API] ⚠️ AVISO: tenantId fornecido ao login será ignorado (tenantId vem do JWT após login)');
    // Não bloquear, mas avisar - backend ignora mesmo assim
  }

  // Proteção contra múltiplas chamadas simultâneas
  if (loginInProgress && loginPromise) {
    console.warn('[API] Login já em andamento, aguardando requisição existente...');
    return loginPromise;
  }

  loginInProgress = true;
  
  loginPromise = (async () => {
    let response: Response;
    
    // Timeout de 10 segundos
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    
    try {
      // 🔴 GARANTIA CANÔNICA: NUNCA enviar x-tenant-id no login
      // Backend busca usuário apenas por email, tenantId vem do JWT após login
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      // tenantId NÃO é enviado - backend ignora mesmo se fornecido
      
      response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ email, password }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
    } catch (error: any) {
      clearTimeout(timeoutId);
      
      // Erro de timeout ou abort
      if (error.name === 'AbortError' || error.name === 'TimeoutError') {
        console.warn('[API] Timeout ao conectar com backend:', API_BASE_URL);
        const errorObj = new Error('Servidor não respondeu. Verifique se o backend está rodando.') as any;
        errorObj.code = 'BACKEND_OFFLINE';
        errorObj.isRetryable = true;
        throw errorObj;
      }
      
      // Erro de rede (Failed to fetch)
      if (error instanceof TypeError && error.message.includes('fetch')) {
        console.warn('[API] Backend não disponível:', API_BASE_URL);
        const errorObj = new Error('Não foi possível conectar ao servidor. Verifique se o backend está rodando.') as any;
        errorObj.code = 'BACKEND_OFFLINE';
        errorObj.isRetryable = true;
        throw errorObj;
      }
      throw error;
    } finally {
      // Resetar flag após conclusão (sucesso ou erro)
      loginInProgress = false;
      loginPromise = null;
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Erro ao fazer login' }));
      // Suporta ambos os formatos: { error: ... } e { ok: false, message: ... }
      const errorMessage = error.message || error.error || `HTTP ${response.status}`;
      
      // Tratar erro 429 especificamente
      if (response.status === 429) {
        const rateLimitError = new Error('Muitas tentativas de login. Aguarde alguns segundos antes de tentar novamente.') as any;
        rateLimitError.code = 'RATE_LIMIT';
        rateLimitError.status = 429;
        throw rateLimitError;
      }
      
      throw new Error(errorMessage);
    }

    return response.json();
  })();

  return loginPromise;
}

/**
 * Verifica se um CPF já está cadastrado no sistema
 * @param cpf - CPF a ser verificado (apenas números)
 * @returns true se CPF existe, false caso contrário
 */
export async function checkCpfExists(cpf: string): Promise<boolean> {
  const cpfNumbers = cpf.replace(/\D/g, '');
  
  if (cpfNumbers.length !== 11) {
    return false;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/auth/check-cpf?cpf=${encodeURIComponent(cpfNumbers)}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      // Se der erro, assumir que não existe (não bloquear cadastro)
      return false;
    }

    const data = await response.json();
    return data.exists === true;
  } catch (error) {
    // Em caso de erro de rede, não bloquear cadastro
    console.warn('[API] Erro ao verificar CPF:', error);
    return false;
  }
}

// 🔧 FIX (api consolidation): Funções de código de indicação movidas de referral.ts
export interface ReferralCodeResponse {
  referralCode: string;
}

export interface ApplyReferralCodeRequest {
  referralCode: string;
}

export interface ApplyReferralCodeResponse {
  referrerUserId: string;
}

export interface ValidateReferralCodeResponse {
  valid: boolean;
}

export async function getReferralCode(): Promise<ReferralCodeResponse> {
  const response = await apiFetch('/referral/code');
  return response.json();
}

export async function applyReferralCode(referralCode: string): Promise<ApplyReferralCodeResponse> {
  const response = await apiFetch('/referral/apply', {
    method: 'POST',
    body: JSON.stringify({ referralCode }),
  });
  return response.json();
}

export async function validateReferralCode(code: string): Promise<ValidateReferralCodeResponse> {
  const response = await apiFetch(`/referral/validate?code=${encodeURIComponent(code)}`);
  return response.json();
}
