// src/api/intent-orchestrator.ts
// API client para o IntentOrchestratorService

import { apiFetch } from './client';

export interface ActorContext {
  actorId: string;
  actorType: 'user' | 'page' | 'group' | 'channel';
  actorName?: string;
  isCompany?: boolean;
  companyId?: string;
}

export interface AnalyzeIntentResponse {
  analysisId: string;
  analysis: {
    intentType: 'event' | 'service_offer' | 'product_offer' | 'booking' | 'personal_post' | 'friends_post' | 'project' | 'vote' | 'invitation';
    confidence: number;
    extractedData: Record<string, any>;
    missingFields: Array<{
      field: string;
      fieldLabel: string;
      fieldType: string;
      question: string;
      required: boolean;
    }>;
    suggestedActions: Array<{
      action: string;
      actionLabel: string;
      canExecute: boolean;
      requiresConfirmation: boolean;
      description: string;
    }>;
    questions: string[];
    reasoning: string;
    canProceed: boolean;
  };
  conversationState: 'collecting_info' | 'ready_to_create' | 'needs_clarification';
  nextMessage?: string;
}

export interface ContinueConversationResponse {
  analysisId: string;
  updatedAnalysis: AnalyzeIntentResponse['analysis'];
  conversationState: 'collecting_info' | 'ready_to_create' | 'needs_clarification';
  nextMessage: string;
  questions: string[];
}

export interface ExecuteActionResult {
  success: boolean;
  actionId: string;
  result?: {
    postId?: string;
    eventId?: string;
    reservationId?: string;
    [key: string]: any;
  };
  error?: string;
  nextSteps?: string[];
}

/**
 * Analisa intenção do texto
 */
export async function analyzeIntent(
  text: string,
  actorContext: ActorContext,
  conversationHistory?: Array<{ role: string; content: string }>
): Promise<AnalyzeIntentResponse> {
  const response = await apiFetch('/social/intent/analyze', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      text,
      actorContext,
      conversationHistory,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(error.error || 'Erro ao analisar intenção');
  }

  return response.json();
}

/**
 * Continua conversa com resposta do usuário
 */
export async function continueConversation(
  analysisId: string,
  userResponse: string,
  actorContext: ActorContext
): Promise<ContinueConversationResponse> {
  const response = await apiFetch('/social/intent/continue', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      analysisId,
      userResponse,
      actorContext,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(error.error || 'Erro ao continuar conversa');
  }

  return response.json();
}

/**
 * Executa ação sugerida
 */
export async function executeAction(
  analysisId: string,
  actionId: string,
  actorContext: ActorContext,
  confirmations?: Record<string, any>
): Promise<ExecuteActionResult> {
  const response = await apiFetch('/social/intent/execute', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      analysisId,
      actionId,
      actorContext,
      confirmations,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(error.error || 'Erro ao executar ação');
  }

  return response.json();
}

/**
 * Recupera análise armazenada
 */
export async function getAnalysis(analysisId: string): Promise<AnalyzeIntentResponse['analysis'] | null> {
  const response = await apiFetch(`/social/intent/${analysisId}`, {
    method: 'GET',
  });

  if (!response.ok) {
    if (response.status === 404) {
      return null;
    }
    const error = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(error.error || 'Erro ao recuperar análise');
  }

  return response.json();
}


























