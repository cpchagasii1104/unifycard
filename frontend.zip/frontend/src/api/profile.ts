// src/api/profile.ts
// API de perfil de usuário

import { apiFetch } from './client';

export interface Profile {
  profileId: string;
  tenantId: string;
  userId: string;
  fullName: string | null;
  phone: string | null;
  metadata: Record<string, any>;
  profile_personal_confirmed?: boolean;
  can_edit_personal_data?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UpdateProfileInput {
  fullName?: string;
  phone?: string;
  metadata?: Record<string, any>;
}

export async function getProfile(): Promise<Profile> {
  const response = await apiFetch('/profile');
  const result = await response.json();
  // Suportar formato antigo e novo
  if (result.ok && result.data) {
    return result.data;
  }
  return result;
}

export async function updateProfile(input: UpdateProfileInput): Promise<Profile> {
  console.log('[profile.ts] Enviando updateProfile:', input);
  
  const response = await apiFetch('/profile', {
    method: 'PUT',
    body: JSON.stringify(input),
  });
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    console.error('[profile.ts] Erro na resposta:', {
      status: response.status,
      statusText: response.statusText,
      error: errorData,
    });
    throw new Error(errorData.error || errorData.message || `Erro ${response.status}: ${response.statusText}`);
  }
  
  const result = await response.json();
  console.log('[profile.ts] Resposta recebida:', result);
  
  // Suportar formato antigo e novo
  if (result.ok && result.data) {
    return result.data;
  }
  return result;
}

// 🔴 PARTE 2 - ONBOARDING: Funções de onboarding
export interface OnboardingStatus {
  onboarding_completed: boolean;
  onboarding_completed_at?: string;
}

export async function completeOnboarding(): Promise<Profile> {
  // 🔧 FIX (send empty body to completeOnboarding)
  const response = await apiFetch('/profile/complete-onboarding', {
    method: 'POST',
    body: JSON.stringify({}),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(errorData.error || errorData.message || `Erro ${response.status}: ${response.statusText}`);
  }

  const result = await response.json();
  if (result.ok && result.data) {
    return result.data;
  }
  return result;
}

/**
 * 🔴 CORREÇÃO PRIMEIRO ACESSO: Confirma primeiro acesso do usuário
 * Seta profile_personal_confirmed = true no backend
 * Só deve ser chamado quando o usuário clicar "Entendi, continuar" no modal
 * NUNCA deve ser chamado automaticamente ao salvar perfil
 */
export async function confirmFirstAccess(body?: Record<string, any>): Promise<Profile> {
  console.log('[profile.ts] Confirmando primeiro acesso...');

  // 🔧 FIX: Sempre enviar body JSON vazio para evitar erro 400
  const response = await apiFetch('/profile/confirm-first-access', {
    method: 'POST',
    body: JSON.stringify(body || {}),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    console.error('[profile.ts] Erro ao confirmar primeiro acesso:', errorData);
    throw new Error(errorData.error || errorData.message || `Erro ${response.status}: ${response.statusText}`);
  }

  const result = await response.json();
  console.log('[profile.ts] Primeiro acesso confirmado:', result);

  if (result.ok && result.data) {
    return result.data;
  }
  return result;
}

// 🔴 PARTE 3 - BARRA DE PROGRESSO: Interface e função de progresso
export interface ProfileProgress {
  progress: number;
  maxProgressWithoutValidation: number;
  hasPresentialValidation: boolean;
  breakdown: {
    personalData: number;
    professionalProfile: number;
    physicalProfile: number;
    learningProfile: number;
    companies: number;
    presentialValidation: number;
  };
  messages: string[];
}

export async function getProfileProgress(): Promise<ProfileProgress> {
  const response = await apiFetch('/profile/progress');
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(errorData.error || errorData.message || `Erro ${response.status}: ${response.statusText}`);
  }
  
  const result = await response.json();
  if (result.ok && result.data) {
    return result.data;
  }
  return result;
}

