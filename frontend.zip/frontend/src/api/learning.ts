// src/api/learning.ts
// API de perfil de aprendizado/trilha

import { apiFetch } from './client';

export interface LearningCategory {
  categoryId: string;
  categoryName: string;
  categoryPath: string[];
  level: number;
}

export interface LearningProfile {
  globalUserId: string;
  learnings: LearningCategory[];
  preferences: {
    [categoryId: string]: {
      details?: string[];
      notes?: string;
      progress?: 'beginner' | 'intermediate' | 'advanced' | null;
    };
  };
  metadata: Record<string, any>;
}

export interface UpdateLearningProfileInput {
  learnings?: string[];
  preferences?: {
    [categoryId: string]: {
      details?: string[];
      notes?: string;
      progress?: 'beginner' | 'intermediate' | 'advanced' | null;
    };
  };
  metadata?: Record<string, any>;
}

export async function getLearningProfile(): Promise<LearningProfile> {
  const response = await apiFetch('/profile/learning');
  const result = await response.json();
  if (!result.ok) {
    throw new Error(result.message || 'Erro ao buscar perfil de aprendizado');
  }
  return result.data;
}

export async function updateLearningProfile(input: UpdateLearningProfileInput): Promise<LearningProfile> {
  const response = await apiFetch('/profile/learning', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(input),
  });
  const result = await response.json();
  if (!result.ok) {
    throw new Error(result.message || 'Erro ao atualizar perfil de aprendizado');
  }
  return result.data;
}


























