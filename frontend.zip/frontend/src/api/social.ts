// frontend/src/api/social.ts
// SPRINT 47: API client para referências do marketplace no social
// Re-exports para compatibilidade com imports legados

import { apiFetch } from './client';
import { getAuthToken, getTenantId, setTenantId } from '../config/auth';

// Re-export from social-2.0.ts for backwards compatibility
export {
  getFeed as getSocialFeed,
  createPost as createSocialPost,
  toggleReaction,
  createComment,
  getActorProfile,
  getActorProfile as getActor,
} from './social-2.0';

export type { Comment, Actor, Post } from './social-2.0';
export type { Actor as ActorResponse } from './social-2.0';
export type { Post as PostCardData } from './social-2.0';

// Extended Actor type with legacy fields
export interface AvailableActor {
  actor_id: string;
  actor_type: 'user' | 'page' | 'group' | 'channel';
  display_name: string;
  slug: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  bio: string | null;
  user_id?: string;
  user_role?: string;
  company_status?: string;
  can_post?: boolean;
}

export async function getAvailableActors(_options?: any): Promise<AvailableActor[]> {
  // 🔴 GUARD EXPLÍCITO: Validar contexto antes de fazer requisição
  // Prevenir chamadas inválidas durante bootstrap que geram 400 e warnings
  
  // 1. Verificar token (autenticação obrigatória)
  const token = getAuthToken();
  if (!token) {
    // Sem token = não autenticado = não fazer chamada
    return [];
  }
  
  // 2. Verificar tenantId (obrigatório para requisições autenticadas)
  let tenantId = getTenantId();
  
  // 3. Se não estiver no storage, tentar extrair do JWT
  if (!tenantId) {
    try {
      const tokenPayload = JSON.parse(atob(token.split('.')[1]));
      tenantId = tokenPayload.tenantId;
      
      // Validar tenantId extraído
      if (tenantId && typeof tenantId === 'string' && tenantId.trim() !== '') {
        setTenantId(tenantId);
      } else {
        // tenantId inválido no JWT = não fazer chamada
        return [];
      }
    } catch (e) {
      // Falha ao extrair tenantId = não fazer chamada
      return [];
    }
  }
  
  // 4. Validação final: tenantId deve ser válido
  if (!tenantId || typeof tenantId !== 'string' || tenantId.trim() === '') {
    // tenantId inválido = não fazer chamada
    return [];
  }
  
  // 5. Contexto válido: fazer requisição
  const response = await apiFetch('/social/actors/available');
  const data = await response.json();
  // Backend retorna { actors: [...] }
  return Array.isArray(data.actors) ? data.actors : [];
}

// Type alias for backwards compatibility
export type CreatePostPayload = any;

// Re-export vote from votes.ts
export { vote } from './votes';

// Stubs for missing functions (to be implemented)
export async function getLedger(_options?: any): Promise<any> {
  return { entries: [] };
}

export type LedgerSummary = Record<string, any>;

export async function getLedgerSummary(_actorId?: string): Promise<any> {
  return { total: 0, breakdown: [], group_contributions: [] };
}

export async function getComments(_postId: string, _options?: any): Promise<any> {
  return { comments: [], next_cursor: null, has_more: false };
}

export async function followActor(_actorId: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function unfollowActor(_actorId: string): Promise<{ success: boolean }> {
  return { success: true };
}

export interface ConfirmCTAResponse {
  success: boolean;
  transactionId?: string;
  message?: string;
  revenue_entry?: any;
  profit_share_entry?: any;
}

export async function confirmCTA(_ctaId: string, _data?: any): Promise<ConfirmCTAResponse> {
  return { success: true };
}

export interface CreateSocialMarketplaceRefInput {
  postId: string;
  refType: 'PRODUCT' | 'ORDER' | 'CAMPAIGN';
  refId: string;
  metadata?: Record<string, any>;
}

export interface SocialMarketplaceRef {
  id: string;
  tenantId: string;
  postId: string;
  refType: 'PRODUCT' | 'ORDER' | 'CAMPAIGN';
  refId: string;
  metadata: Record<string, any> | null;
  createdAt: string;
}

export interface SocialMarketplaceRefWithDetails {
  ref: SocialMarketplaceRef;
  details: {
    type: 'PRODUCT' | 'ORDER' | 'CAMPAIGN';
    id: string;
    name: string;
    status?: string;
    link: string;
  } | null;
}

/**
 * Cria referência do marketplace no social
 */
export async function createSocialMarketplaceRef(
  input: CreateSocialMarketplaceRefInput
): Promise<SocialMarketplaceRef> {
  const response = await apiFetch('/social/marketplace-ref', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  return response.json();
}

/**
 * Busca referências do marketplace por post
 */
export async function getSocialMarketplaceRefsByPost(
  postId: string
): Promise<{ refs: SocialMarketplaceRefWithDetails[] }> {
  const response = await apiFetch(`/social/marketplace-ref/${postId}`);
  return response.json();
}

/**
 * Busca detalhes de uma referência específica
 */
export async function getSocialMarketplaceRefDetails(
  refId: string
): Promise<SocialMarketplaceRefWithDetails> {
  const response = await apiFetch(`/social/marketplace-ref/details/${refId}`);
  return response.json();
}
