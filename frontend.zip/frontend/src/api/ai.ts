// frontend/src/api/ai.ts
import { apiFetch } from './client';

export interface ChatRequest {
  message: string;
  tab: string;
}

export interface ChatResponse {
  response: string;
}

export async function postChat(message: string, tab: string): Promise<ChatResponse> {
  const response = await apiFetch('/ai/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ message, tab }),
  });

  if (!response.ok) {
    throw new Error('Erro ao enviar mensagem');
  }

  return response.json();
}















