// src/pages/SocialCompanyPage.tsx
// Página de empresa social (actor)

import { useParams } from 'react-router-dom';
import CompanyPage from '../components/social/CompanyPage';

export default function SocialCompanyPage() {
  const { id } = useParams<{ id: string }>();

  if (!id) {
    return <div>ID da empresa não fornecido</div>;
  }

  return <CompanyPage actorId={id} />;
}


























