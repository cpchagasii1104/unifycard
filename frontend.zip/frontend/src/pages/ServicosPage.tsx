// src/pages/ServicosPage.tsx
// Tela de Serviços Disponíveis - lista ofertas de serviço do feed

import { useState, useEffect } from 'react';
import { useActiveActor } from '../contexts/ActiveActorContext';
import { getSocialFeed, type PostCardData } from '../api/social';
import PostCard from '../components/social/PostCard';
import { toggleReaction, createComment } from '../api/social';
import { validateActiveActor, safeApiCall, safeArray } from '../utils/guardrails';
import { devLog } from '../utils/devLog';
import './ServicosPage.css';

export default function ServicosPage() {
  const { activeActor, isLoading: actorsLoading } = useActiveActor();
  const [services, setServices] = useState<PostCardData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (validateActiveActor(activeActor) && !actorsLoading) {
      loadServices();
    }
  }, [activeActor?.actor_id, actorsLoading]);

  const loadServices = async () => {
    // Guardrail: validar activeActor antes de carregar
    if (!validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);

    // Usar safeApiCall com fallback
    const feedData = await safeApiCall(
      async () => {
        // Tentar buscar com parâmetro intent na query string
        // Se backend não suportar, filtrar no frontend
        const data = await getSocialFeed({
          limit: 50,
          actor_type: activeActor!.actor_type as 'user' | 'page',
          actor_id: activeActor!.actor_id,
          actor_status: activeActor!.company_status,
        });
        return data;
      },
      { posts: [], next_cursor: null, has_more: false },
      'Erro ao carregar serviços'
    );

    // Filtrar apenas posts com intent = service_offer usando safeArray
    const allPosts = safeArray<PostCardData>(feedData.posts, []);
    const servicePosts = allPosts.filter(
      (post) => post.intent === 'service_offer'
    );

    setServices(servicePosts);
    setIsLoading(false);
  };

  const handleReaction = async (postId: string, reactionType: string) => {
    // Guardrail: validar activeActor
    if (!validateActiveActor(activeActor)) {
      devLog.warn('activeActor não válido para reagir');
      return;
    }

    try {
      const queryParams = new URLSearchParams();
      queryParams.append('actor_id', activeActor!.actor_id);
      queryParams.append('actor_type', activeActor!.actor_type);

      await toggleReaction(
        postId,
        reactionType as 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry',
        queryParams.toString()
      );

      // Atualizar post localmente
      setServices((prev) =>
        prev.map((post) => {
          if (post.post_id === postId) {
            const wasLiked = post.user_reaction === reactionType;
            return {
              ...post,
              user_reaction: wasLiked ? null : reactionType,
              reactions_count: wasLiked
                ? post.reactions_count - 1
                : post.reactions_count + (post.user_reaction ? 0 : 1),
            };
          }
          return post;
        })
      );
    } catch (err) {
      devLog.error('Erro ao reagir:', err);
      throw new Error(err instanceof Error ? err.message : 'Erro ao reagir');
    }
  };

  const handleComment = async (postId: string, content: string) => {
    try {
      await createComment(postId, { content });

      // Atualizar contador de comentários
      setServices((prev) =>
        prev.map((post) => {
          if (post.post_id === postId) {
            return {
              ...post,
              comments_count: post.comments_count + 1,
            };
          }
          return post;
        })
      );
    } catch (err) {
      devLog.error('Erro ao comentar:', err);
      throw new Error(err instanceof Error ? err.message : 'Erro ao comentar');
    }
  };

  const handleCTAConfirmed = async (_postId: string) => {
    // Recarregar serviços para atualizar
    await loadServices();
    // Notificar ledger para recarregar
    window.dispatchEvent(new CustomEvent('cta-confirmed'));
  };

  // Não renderizar se activeActor não estiver válido (após bootstrap)
  if (!validateActiveActor(activeActor) && !actorsLoading) {
    return null; // Redirecionamento em andamento
  }

  return (
    <div className="servicos-page">
      <div className="servicos-header">
        <h1 className="servicos-title">🛠️ Serviços Disponíveis</h1>
        <p className="servicos-subtitle">
          Ofertas de serviço publicadas no ecossistema
        </p>
      </div>

      {isLoading ? (
        <div className="servicos-loading">
          <div className="loading-spinner"></div>
          <p>Carregando serviços...</p>
        </div>
      ) : services.length === 0 ? (
        <div className="servicos-empty">
          <div className="empty-icon">🛠️</div>
          <p className="empty-title">Nenhum serviço disponível no momento</p>
          <p className="empty-description">
            Quando houver ofertas de serviço no ecossistema, elas aparecerão aqui.
          </p>
        </div>
      ) : (
        <div className="servicos-grid">
          {services.map((service) => (
            <PostCard
              key={service.post_id}
              post={service}
              onReaction={handleReaction}
              onComment={handleComment}
              onCTAConfirmed={handleCTAConfirmed}
            />
          ))}
        </div>
      )}
    </div>
  );
}


