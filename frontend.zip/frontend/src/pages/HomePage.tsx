// src/pages/HomePage.tsx
// CONTINUOUS PRODUCTION: Home Contextual - SPRINT 1
// Home state-driven com "Situação Atual" e cards dinâmicos

import HomeContextual from '../components/home/HomeContextual';
import SearchBar from '../components/home/SearchBar';
import AppGrid from '../components/home/AppGrid';
import './HomePage.css';

export default function HomePage() {
  return (
    <div className="home-page">
      {/* 1) Ação Imediata - TOPO (logo após login) */}
      <SearchBar />
      <AppGrid />
      
      {/* 2) Identidade e Estado */}
      <HomeContextual />
    </div>
  );
}

