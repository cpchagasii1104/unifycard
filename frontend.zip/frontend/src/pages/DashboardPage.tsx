// frontend/src/pages/DashboardPage.tsx
// SPRINT 49: DASHBOARDS OPERACIONAIS (BI INTERNO)

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useActiveActor } from '../hooks/useActiveActor';
import { getDashboardOverview, type DashboardOverview } from '../api/dashboard';
import { countOpenAlerts } from '../api/automation';
import { listOrganizationUnits, type OrganizationUnit } from '../api/organization';
import { showToast } from '../utils/toast';
import './DashboardPage.css';

export default function DashboardPage() {
  const navigate = useNavigate();
  const { activeActor } = useActiveActor();
  const [overview, setOverview] = useState<DashboardOverview | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [alertCount, setAlertCount] = useState<number>(0);
  const [organizationUnits, setOrganizationUnits] = useState<OrganizationUnit[]>([]);
  const [selectedUnitId, setSelectedUnitId] = useState<string>('');
  const [consolidated, setConsolidated] = useState<boolean>(false);

  useEffect(() => {
    if (activeActor?.id) {
      loadOrganizationUnits();
      loadAlertCount();
    }
  }, [activeActor?.id]);

  useEffect(() => {
    if (activeActor?.id) {
      loadDashboard();
    }
  }, [activeActor?.id, selectedUnitId, consolidated]);

  const loadOrganizationUnits = async () => {
    try {
      const data = await listOrganizationUnits();
      setOrganizationUnits(data.units);
    } catch (err) {
      console.warn('Erro ao carregar unidades organizacionais:', err);
    }
  };

  const loadDashboard = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const filters: any = {
        actorId: activeActor?.id,
      };
      // SPRINT 51: Multi-empresa e consolidação
      if (selectedUnitId) {
        filters.organizationUnitId = selectedUnitId;
      }
      if (consolidated) {
        filters.consolidated = true;
      }

      const data = await getDashboardOverview(filters);
      setOverview(data);
    } catch (err: any) {
      // 🔴 TRATAMENTO CANÔNICO: Detectar erro de permissão específico
      const errorMessage = err instanceof Error ? err.message : 'Erro ao carregar dashboard';
      const isPermissionError = errorMessage.includes('permission') || 
                                 errorMessage.includes('dashboard:view') ||
                                 errorMessage.includes('missing required permission') ||
                                 (err?.response?.status === 403);
      
      if (isPermissionError) {
        // Erro de permissão - mensagem canônica conforme MAPA_CANONICO_PERMISSIONS
        setError('PERMISSION_DENIED');
      } else {
        setError(errorMessage);
      }
      
      // Não mostrar toast para erro de permissão (já será exibido na UI)
      if (!isPermissionError) {
        showToast(errorMessage, 'error');
      }
      console.error('Erro ao carregar dashboard:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadAlertCount = async () => {
    try {
      const data = await countOpenAlerts();
      setAlertCount(data.count);
    } catch (err) {
      console.warn('Erro ao carregar contagem de alertas:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="dashboard-page">
        <div className="dashboard-loading">Carregando dashboard...</div>
      </div>
    );
  }

  // 🔴 TRATAMENTO CANÔNICO: Exibir mensagem apropriada para erro de permissão
  if (error === 'PERMISSION_DENIED') {
    return (
      <div className="dashboard-page">
        <div className="dashboard-permission-denied">
          <div className="permission-denied-icon">🔒</div>
          <h2 className="permission-denied-title">Acesso Restrito</h2>
          <p className="permission-denied-message">
            Você não possui a permissão necessária para visualizar o dashboard.
          </p>
          <p className="permission-denied-detail">
            A permissão <strong>dashboard:view</strong> é necessária para acessar esta página.
          </p>
          <div className="permission-denied-actions">
            <button 
              className="permission-denied-button"
              onClick={() => navigate('/home')}
            >
              Voltar para Home
            </button>
            <button 
              className="permission-denied-button secondary"
              onClick={() => navigate('/perfil')}
            >
              Ver Meu Perfil
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (error || !overview) {
    return (
      <div className="dashboard-page">
        <div className="dashboard-error">
          <div className="error-icon">⚠️</div>
          <h2>Erro ao carregar dashboard</h2>
          <p>{error || 'Não foi possível carregar os dados do dashboard.'}</p>
          <button 
            className="error-retry-button"
            onClick={loadDashboard}
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Dashboard Operacional</h1>
        <div className="dashboard-header-actions">
          {/* SPRINT 51: Filtro de unidade organizacional */}
          {organizationUnits.length > 0 && (
            <div className="dashboard-filters">
              <select
                className="dashboard-unit-filter"
                value={selectedUnitId}
                onChange={(e) => setSelectedUnitId(e.target.value)}
              >
                <option value="">Todas as unidades</option>
                {organizationUnits.map((unit) => (
                  <option key={unit.id} value={unit.id}>
                    {unit.name} ({unit.type})
                  </option>
                ))}
              </select>
              <label className="dashboard-consolidated-label">
                <input
                  type="checkbox"
                  checked={consolidated}
                  onChange={(e) => setConsolidated(e.target.checked)}
                />
                <span>Consolidado</span>
              </label>
            </div>
          )}
          {alertCount > 0 && (
            <div
              className="dashboard-alert-badge"
              onClick={() => navigate('/alerts')}
              title="Ver alertas"
            >
              <span className="dashboard-alert-count">{alertCount}</span>
              <span className="dashboard-alert-label">Alerta{alertCount > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>
      </div>

      {/* Cards do Dia */}
      <div className="dashboard-section">
        <h2 className="dashboard-section-title">Hoje</h2>
        <div className="dashboard-cards">
          <div className="dashboard-card">
            <div className="dashboard-card-label">Vendas Hoje</div>
            <div className="dashboard-card-value">{overview.today.sales.totalOrders}</div>
            <div className="dashboard-card-subtitle">pedidos</div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Faturamento</div>
            <div className="dashboard-card-value">
              R$ {overview.today.sales.totalPaid.toFixed(2)}
            </div>
            <div className="dashboard-card-subtitle">recebido</div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Ticket Médio</div>
            <div className="dashboard-card-value">
              R$ {overview.today.sales.averageTicket.toFixed(2)}
            </div>
            <div className="dashboard-card-subtitle">por pedido</div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Estoque Crítico</div>
            <div className="dashboard-card-value">{overview.inventory.lowStockCount}</div>
            <div className="dashboard-card-subtitle">variantes com estoque baixo</div>
          </div>
        </div>
      </div>

      {/* Visão do Mês */}
      <div className="dashboard-section">
        <h2 className="dashboard-section-title">Mês Atual</h2>
        <div className="dashboard-cards">
          <div className="dashboard-card">
            <div className="dashboard-card-label">Total de Pedidos</div>
            <div className="dashboard-card-value">{overview.month.sales.totalOrders}</div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Faturamento Mensal</div>
            <div className="dashboard-card-value">
              R$ {overview.month.sales.totalPaid.toFixed(2)}
            </div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Taxas/Plataforma</div>
            <div className="dashboard-card-value">
              R$ {overview.month.financial.platformFees.toFixed(2)}
            </div>
          </div>
          <div className="dashboard-card">
            <div className="dashboard-card-label">Repassado</div>
            <div className="dashboard-card-value">
              R$ {overview.month.financial.totalPaidOut.toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Divisão por Canal */}
      <div className="dashboard-section">
        <h2 className="dashboard-section-title">Por Canal</h2>
        <div className="dashboard-channels">
          {overview.channels.map((channel) => (
            <div key={channel.channel} className="dashboard-channel-card">
              <div className="dashboard-channel-name">{channel.channel}</div>
              <div className="dashboard-channel-stats">
                <div className="dashboard-channel-stat">
                  <span className="dashboard-channel-stat-label">Pedidos:</span>
                  <span className="dashboard-channel-stat-value">{channel.sales.totalOrders}</span>
                </div>
                <div className="dashboard-channel-stat">
                  <span className="dashboard-channel-stat-label">Faturamento:</span>
                  <span className="dashboard-channel-stat-value">
                    R$ {channel.sales.totalPaid.toFixed(2)}
                  </span>
                </div>
                <div className="dashboard-channel-stat">
                  <span className="dashboard-channel-stat-label">Ticket Médio:</span>
                  <span className="dashboard-channel-stat-value">
                    R$ {channel.sales.averageTicket.toFixed(2)}
                  </span>
                </div>
                <div className="dashboard-channel-stat">
                  <span className="dashboard-channel-stat-label">Participação:</span>
                  <span className="dashboard-channel-stat-value">
                    {channel.percentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Estoque Crítico */}
      {overview.inventory.criticalVariants.length > 0 && (
        <div className="dashboard-section">
          <h2 className="dashboard-section-title">Estoque Crítico</h2>
          <div className="dashboard-table">
            <table>
              <thead>
                <tr>
                  <th>Variante</th>
                  <th>Estoque Real</th>
                  <th>Reservado</th>
                  <th>Disponível</th>
                </tr>
              </thead>
              <tbody>
                {overview.inventory.criticalVariants.map((variant) => (
                  <tr key={variant.variantId}>
                    <td>{variant.variantName}</td>
                    <td>{variant.currentQuantity}</td>
                    <td>{variant.reservedQuantity}</td>
                    <td className={variant.availableQuantity <= 0 ? 'text-danger' : ''}>
                      {variant.availableQuantity}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Gráfico Simples de Tendências */}
      {overview.month.trends.dailySales.length > 0 && (
        <div className="dashboard-section">
          <h2 className="dashboard-section-title">Tendências (Últimos 30 dias)</h2>
          <div className="dashboard-chart">
            <div className="dashboard-chart-bars">
              {overview.month.trends.dailySales.slice(-7).map((day) => {
                const maxAmount = Math.max(
                  ...overview.month.trends.dailySales.map((d) => d.amount)
                );
                const height = maxAmount > 0 ? (day.amount / maxAmount) * 100 : 0;
                return (
                  <div key={day.date} className="dashboard-chart-bar-container">
                    <div
                      className="dashboard-chart-bar"
                      style={{ height: `${height}%` }}
                      title={`${day.date}: R$ ${day.amount.toFixed(2)}`}
                    />
                    <div className="dashboard-chart-label">
                      {new Date(day.date).toLocaleDateString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
