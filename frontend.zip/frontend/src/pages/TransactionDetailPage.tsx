// src/pages/TransactionDetailPage.tsx
// Página de detalhes de transação

import { useParams, useNavigate } from 'react-router-dom';
import TransactionDetail from '../components/TransactionDetail';

export default function TransactionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  if (!id) {
    return <div>ID de transação não fornecido</div>;
  }

  return (
    <TransactionDetail
      transactionId={id}
      onClose={() => navigate(-1)}
    />
  );
}


























