// src/pages/SearchPage.tsx
// Página de busca global - preparada para evolução com IA

import { useSearchParams } from 'react-router-dom';
import './SearchPage.css';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  return (
    <div className="search-page">
      <div className="search-page-container">
        <h1 className="search-page-title">Busca</h1>
        
        {query ? (
          <div className="search-results">
            <p className="search-query">Resultados para: <strong>"{query}"</strong></p>
            <div className="search-empty-state">
              <p>Busca global em desenvolvimento.</p>
              <p className="search-hint">
                Em breve você poderá buscar por:
              </p>
              <ul className="search-features-list">
                <li>📱 Aplicativos</li>
                <li>👥 Pessoas e empresas</li>
                <li>📝 Posts e conteúdo</li>
                <li>🎭 Eventos</li>
                <li>🔧 Serviços</li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="search-empty-state">
            <p>Digite algo para buscar.</p>
          </div>
        )}
      </div>
    </div>
  );
}





















