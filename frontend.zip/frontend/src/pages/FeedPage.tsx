// src/pages/FeedPage.tsx
// Feed com eventos integrados (read-only)
// SPRINT 47: Integração com marketplace como plugin
import { useState, useEffect } from 'react';
import { apiFetch } from '../api/client';
import EventCard from '../components/events/EventCard';
import MarketplaceRefCard from '../components/marketplace/MarketplaceRefCard';
import { getSocialMarketplaceRefsByPost } from '../api/social';
import './FeedPage.css';

export interface FeedPost {
  postId: string;
  content: string;
  type: string;
  createdAt: string;
  eventId?: string | null;
  event?: {
    id: string;
    title: string;
    eventType: string;
    startTime: string;
    endTime: string | null;
    cityId: string | null;
    ticketPrice: number | null;
    acceptsConsumption: boolean;
    status: string;
  } | null;
  globalUserId: string;
  media: any[];
  metadata: Record<string, any>;
}

export default function FeedPage() {
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [marketplaceRefsMap, setMarketplaceRefsMap] = useState<Record<string, any[]>>({});

  useEffect(() => {
    loadFeed();
  }, []);

  const loadFeed = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiFetch('/api/feed?limit=50');
      const data = await response.json();
      const loadedPosts = data.posts || [];
      setPosts(loadedPosts);

      // SPRINT 47: Carregar referências do marketplace para cada post
      const refsMap: Record<string, any[]> = {};
      await Promise.all(
        loadedPosts.map(async (post: FeedPost) => {
          try {
            const refsData = await getSocialMarketplaceRefsByPost(post.postId);
            if (refsData.refs && refsData.refs.length > 0) {
              refsMap[post.postId] = refsData.refs;
            }
          } catch (refError) {
            // Falha no social não quebra feed
            console.warn(`Erro ao carregar referências do marketplace para post ${post.postId}:`, refError);
          }
        })
      );
      setMarketplaceRefsMap(refsMap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao carregar feed');
      console.error('Erro ao carregar feed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNavigateToEvent = (eventId: string) => {
    // Navegação simples (pode ser ajustada para react-router)
    window.location.href = `/events/${eventId}`;
  };

  if (isLoading) {
    return (
      <div className="feed-page">
        <div className="feed-page-loading">Carregando feed...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="feed-page">
        <div className="feed-page-error">{error}</div>
      </div>
    );
  }

  return (
    <div className="feed-page">
      <h1 className="feed-page-title">Feed</h1>
      <div className="feed-page-content">
        {posts.map((post) => {
          // Se post tem evento vinculado, renderiza EventCard
          if (post.eventId && post.event) {
            return (
              <EventCard
                key={post.postId}
                eventId={post.event.id}
                title={post.event.title}
                eventType={post.event.eventType}
                cityId={post.event.cityId}
                status={post.event.status}
                ticketPrice={post.event.ticketPrice}
                acceptsConsumption={post.event.acceptsConsumption}
                onClick={() => handleNavigateToEvent(post.event!.id)}
              />
            );
          }

          // SPRINT 47: Verificar se tem referências do marketplace no social
          const marketplaceRefs = marketplaceRefsMap[post.postId] || [];
          // Verificar também se tem marketplace_ref no metadata (legado)
          const legacyMarketplaceRef = post.metadata?.marketplace_ref;

          // Se tem referências do marketplace, renderizar cards
          if (marketplaceRefs.length > 0 || legacyMarketplaceRef) {
            return (
              <div key={post.postId} className="feed-post">
                <div className="feed-post-content">{post.content}</div>
                {/* SPRINT 47: Renderizar referências do social */}
                {marketplaceRefs.map((refWithDetails) => {
                  if (!refWithDetails.details) return null;
                  const refType = refWithDetails.details.type.toLowerCase() === 'product' 
                    ? 'product_variant' 
                    : refWithDetails.details.type.toLowerCase();
                  return (
                    <MarketplaceRefCard
                      key={refWithDetails.ref.id}
                      type={refType}
                      id={refWithDetails.details.id}
                    />
                  );
                })}
                {/* Legado: marketplace_ref no metadata */}
                {legacyMarketplaceRef && (
                  <MarketplaceRefCard type={legacyMarketplaceRef.type} id={legacyMarketplaceRef.id} />
                )}
              </div>
            );
          }

          // Caso contrário, renderiza PostCard normal
          return (
            <div key={post.postId} className="feed-post-card">
              <div className="feed-post-content">{post.content}</div>
              <div className="feed-post-date">
                {new Date(post.createdAt).toLocaleDateString()}
              </div>
            </div>
          );
        })}

        {posts.length === 0 && (
          <div className="feed-page-empty">Nenhum post encontrado</div>
        )}
      </div>
    </div>
  );
}
