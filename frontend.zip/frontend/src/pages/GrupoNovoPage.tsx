// src/pages/GrupoNovoPage.tsx
// Página de criação de novo grupo
// Agora usa o wizard de 2 etapas

import CreateGroupWizard from '../components/groups/CreateGroupWizard';

export default function GrupoNovoPage() {
  return <CreateGroupWizard />;
}








