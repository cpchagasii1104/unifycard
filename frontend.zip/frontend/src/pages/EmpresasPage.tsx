// src/pages/EmpresasPage.tsx
// Página de listagem e gerenciamento de empresas

import { CompaniesManager } from '../components/CompaniesManager';

export default function EmpresasPage() {
  return <CompaniesManager />;
}













