// src/components/social/ImpactBalanceBadge.tsx
// Badge de saldo de impacto no topo do feed

import { useState, useEffect, useCallback } from 'react';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { getImpactBalance, type ImpactBalance } from '../../api/impact';
import { validateActiveActor, safeNumber, safeApiCall } from '../../utils/guardrails';
import { devLog } from '../../utils/devLog';
import './ImpactBalanceBadge.css';

export default function ImpactBalanceBadge() {
  const { activeActor } = useActiveActor();
  const [balance, setBalance] = useState<ImpactBalance | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);

  const loadBalance = useCallback(async () => {
    // Guardrail: validar activeActor
    if (!validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      const impactBalance = await safeApiCall(
        async () => getImpactBalance(
          activeActor!.actor_id,
          activeActor!.actor_type as 'user' | 'page'
        ),
        {
          actor_id: activeActor!.actor_id,
          actor_type: activeActor!.actor_type as 'user' | 'page',
          balance: 0,
        },
        'Erro ao carregar saldo de impacto'
      );
      
      // Animação quando o saldo aumenta
      const previousBalance = safeNumber(balance?.balance, 0);
      const newBalance = safeNumber(impactBalance.balance, 0);
      if (newBalance > previousBalance) {
        setIsAnimating(true);
        setTimeout(() => setIsAnimating(false), 600);
      }
      
      setBalance(impactBalance);
    } catch (err) {
      // Erro inesperado - usar fallback
      devLog.error('Erro inesperado ao carregar saldo de impacto:', err);
      setBalance({
        actor_id: activeActor!.actor_id,
        actor_type: activeActor!.actor_type as 'user' | 'page',
        balance: 0,
      });
    } finally {
      setIsLoading(false);
    }
  }, [activeActor?.actor_id, balance?.balance]); // Usar apenas campos necessários para evitar loops

  useEffect(() => {
    loadBalance();
  }, [loadBalance]);

  // Escutar eventos de mudança de impacto
  useEffect(() => {
    if (!validateActiveActor(activeActor)) {
      return;
    }

    const handleImpactChanged = (event: CustomEvent<{ actor_id: string; actor_type: string }>) => {
      if (activeActor && validateActiveActor(activeActor) && 
          event.detail?.actor_id === activeActor.actor_id && 
          event.detail?.actor_type === activeActor.actor_type) {
        // Pequeno delay para garantir que o backend atualizou
        setTimeout(() => {
          loadBalance();
        }, 500);
      }
    };

    window.addEventListener('impact-changed', handleImpactChanged as EventListener);
    return () => {
      window.removeEventListener('impact-changed', handleImpactChanged as EventListener);
    };
  }, [activeActor?.actor_id, activeActor?.actor_type, loadBalance]);

  if (!validateActiveActor(activeActor) || isLoading) {
    return null;
  }

  const formatBalance = (value: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className={`impact-balance-badge ${isAnimating ? 'impact-balance-badge--animating' : ''}`}>
      <div className="impact-balance-icon">💚</div>
      <div className="impact-balance-content">
        <span className="impact-balance-label">Seu Impacto</span>
        <span className="impact-balance-value">{formatBalance(balance?.balance || 0)} pontos</span>
      </div>
    </div>
  );
}

