// src/components/social/TransactionImpactSummary.tsx
// Bloco 4.2: Mini-resumo de impacto após transação (usa apenas dados já retornados)
// Feedback curto, não invasivo - clareza > marketing

import { safeNumber } from '../../utils/guardrails';
import './TransactionImpactSummary.css';

interface TransactionImpactSummaryProps {
  totalAmount: number;
  currency?: string;
  revenueEntry?: {
    amount_cents: number;
    currency: string;
    recipient_actor_id?: string | null;
  };
  profitShareEntry?: {
    amount_cents: number;
    currency: string;
    recipient_group_id?: string | null;
  };
  isProduct?: boolean;
  onViewLedger?: () => void;
  onBackToFeed?: () => void;
}

export default function TransactionImpactSummary({
  totalAmount,
  currency = 'BRL',
  revenueEntry,
  profitShareEntry,
  onViewLedger,
  onBackToFeed,
}: TransactionImpactSummaryProps) {
  const formatPrice = (cents: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency,
    }).format(safeNumber(cents, 0) / 100);
  };

  // Bloco 4.2: Usar apenas dados reais retornados pela API (não calcular)
  const totalFormatted = formatPrice(totalAmount);

  return (
    <div className="transaction-impact-summary">
      <div className="impact-summary-header">
        <span className="impact-summary-icon">💰</span>
        <h3 className="impact-summary-title">Impacto Gerado</h3>
      </div>

      <div className="impact-summary-content">
        <div className="impact-summary-total">
          <span className="total-label">Total pago:</span>
          <span className="total-value">{totalFormatted}</span>
        </div>

        {/* Bloco 4.2: Exibir apenas dados reais, sem marketing excessivo */}
        {(revenueEntry || profitShareEntry) ? (
          <div className="impact-summary-destinations">
            <p className="destinations-label">Distribuição:</p>
            
            {revenueEntry && safeNumber(revenueEntry.amount_cents, 0) > 0 && (
              <div className="destination-item">
                <span className="destination-label">Prestador / Organizador</span>
                <span className="destination-value">{formatPrice(revenueEntry.amount_cents)}</span>
              </div>
            )}
            
            {profitShareEntry && safeNumber(profitShareEntry.amount_cents, 0) > 0 && (
              <div className="destination-item">
                <span className="destination-label">Comunidade / Grupo</span>
                <span className="destination-value">{formatPrice(profitShareEntry.amount_cents)}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="impact-summary-note">
            <span className="note-icon">💡</span>
            <p className="note-text">
              A distribuição será processada automaticamente pelo Split Engine.
            </p>
          </div>
        )}

        {/* Bloco 4.2: Mensagem simples, 2-3 linhas máximo */}
        <div className="impact-summary-message">
          <span className="message-icon">💚</span>
          <span className="message-text">Transação concluída. Impacto registrado no ledger.</span>
        </div>
      </div>

      <div className="impact-summary-actions">
        {onViewLedger && (
          <button
            className="impact-action-btn impact-action-ledger"
            onClick={onViewLedger}
          >
            Ver no Ledger
          </button>
        )}
        {/* Bloco 4.3: Link para transparência */}
        <button
          className="impact-action-btn impact-action-transparency"
          onClick={() => {
            window.location.href = '/transparency';
          }}
        >
          🔍 Transparência
        </button>
        {onBackToFeed && (
          <button
            className="impact-action-btn impact-action-feed"
            onClick={onBackToFeed}
          >
            Voltar ao Feed
          </button>
        )}
      </div>
    </div>
  );
}

