// src/components/social/TransactionImpact.tsx
// Bloco 4.1: Mostra "Para onde foi meu dinheiro" em posts com transação
// Exibe apenas dados reais do ledger, sem calcular split no frontend

import { useState, useEffect } from 'react';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { getLedger } from '../../api/social';
import { validateActiveActor, safeApiCall, safeNumber, safeArray } from '../../utils/guardrails';
import { devLog } from '../../utils/devLog';
import './TransactionImpact.css';

interface TransactionImpactProps {
  postId: string;
  ctaId?: string | null;
  currency?: string;
}

interface LedgerEntry {
  ledger_id: string;
  post_id: string | null;
  cta_id: string | null;
  recipient_actor_id: string | null;
  recipient_group_id: string | null;
  amount_cents: number;
  currency: string;
  amount_type: 'revenue' | 'profit_share' | 'donation' | 'commission';
  description: string | null;
  created_at: string;
}

export default function TransactionImpact({ postId, ctaId, currency = 'BRL' }: TransactionImpactProps) {
  const { activeActor } = useActiveActor();
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Bloco 4.1: Validar activeActor antes de carregar
    if (!postId || !validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    loadLedgerEntries();
  }, [postId, ctaId, activeActor?.actor_id]);

  // Bloco 4.1: Usar safeApiCall para buscar ledger
  const loadLedgerEntries = async () => {
    if (!validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);

    try {
      const response = await safeApiCall(
        async () => getLedger({ limit: 100 }),
        { entries: [] },
        'Erro ao buscar dados de transação'
      );

      const allEntries = safeArray<LedgerEntry>(response.entries, []);
      
      // Bloco 4.1: Filtrar entries relacionadas a este post (apenas dados reais)
      const postEntries = allEntries.filter(
        (entry: LedgerEntry) => 
          entry.post_id === postId || 
          (ctaId && entry.cta_id === ctaId)
      );

      setLedgerEntries(postEntries);
    } catch (error) {
      devLog.warn('Erro ao buscar ledger entries:', error);
      setLedgerEntries([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Bloco 4.1: Renderizar APENAS se houver dados reais
  if (isLoading) {
    return null; // Não mostrar nada enquanto carrega
  }

  if (ledgerEntries.length === 0) {
    return null; // Não mostrar se não houver transações
  }

  // Bloco 4.1: Agrupar entries por tipo (apenas valores reais do ledger, não calcular split)
  const revenueEntry = ledgerEntries.find(e => e.amount_type === 'revenue');
  const profitShareEntry = ledgerEntries.find(e => e.amount_type === 'profit_share') as LedgerEntry & { recipient_group_id?: string | null; group_name?: string | null } | undefined;
  const donationEntry = ledgerEntries.find(e => e.amount_type === 'donation');
  const commissionEntry = ledgerEntries.find(e => e.amount_type === 'commission');
  
  // Bloco 4.1: Calcular total apenas somando valores reais do ledger (não calcular split)
  const totalAmount = ledgerEntries.reduce((sum, entry) => sum + safeNumber(entry.amount_cents, 0), 0);
  
  // Bloco 4.1: Renderizar APENAS se houver dados reais com valor > 0
  if (totalAmount === 0) {
    return null;
  }

  const formatPrice = (cents: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency,
    }).format(safeNumber(cents, 0) / 100);
  };

  // Bloco 4.1: UI discreta, abaixo do conteúdo do post
  return (
    <div className="transaction-impact">
      <div className="transaction-impact-header">
        <span className="impact-icon">💰</span>
        <span className="impact-title">Para onde foi meu dinheiro</span>
      </div>
      
      <div className="transaction-impact-list">
        {/* Bloco 4.1: Exibir apenas valores reais do ledger */}
        {revenueEntry && safeNumber(revenueEntry.amount_cents, 0) > 0 && (
          <div className="transaction-impact-item">
            <span className="impact-item-label">Prestador / Organizador</span>
            <span className="impact-item-value">{formatPrice(revenueEntry.amount_cents)}</span>
          </div>
        )}
        
        {profitShareEntry && safeNumber(profitShareEntry.amount_cents, 0) > 0 && (
          <div className="transaction-impact-item transaction-impact-item--group">
            <div className="impact-item-group-info">
              <span className="impact-item-label">
                {profitShareEntry.recipient_group_id ? (
                  <>
                    <span className="group-icon">👥</span>
                    Comunidade beneficiada
                  </>
                ) : (
                  'Comunidade / Grupo'
                )}
              </span>
              {profitShareEntry.recipient_group_id && (
                <button
                  className="impact-item-group-link"
                  onClick={() => {
                    window.location.href = `/groups/${profitShareEntry.recipient_group_id}`;
                  }}
                >
                  Ver comunidade →
                </button>
              )}
            </div>
            <span className="impact-item-value">{formatPrice(profitShareEntry.amount_cents)}</span>
          </div>
        )}
        
        {donationEntry && safeNumber(donationEntry.amount_cents, 0) > 0 && (
          <div className="transaction-impact-item">
            <span className="impact-item-label">Doação</span>
            <span className="impact-item-value">{formatPrice(donationEntry.amount_cents)}</span>
          </div>
        )}
        
        {commissionEntry && safeNumber(commissionEntry.amount_cents, 0) > 0 && (
          <div className="transaction-impact-item">
            <span className="impact-item-label">Comissão</span>
            <span className="impact-item-value">{formatPrice(commissionEntry.amount_cents)}</span>
          </div>
        )}
      </div>

      <div className="transaction-impact-total">
        <span className="total-label">Total da transação</span>
        <span className="total-value">{formatPrice(totalAmount)}</span>
      </div>

      {/* Bloco 4.3: Link para transparência */}
      <div className="transaction-impact-footer">
        <a
          href="/transparency"
          className="transaction-impact-transparency-link"
        >
          🔍 Ver transparência completa →
        </a>
      </div>
    </div>
  );
}

