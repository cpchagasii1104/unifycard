// src/components/social/PostCard.tsx
// Card de post com header, conteúdo, ações e preview de comentários

import { useState } from 'react';
import CTAModal from './CTAModal';
import CommentsDrawer from './CommentsDrawer';
import TransactionImpact from './TransactionImpact';
import CommunitiesBenefited from './CommunitiesBenefited';
import AuthorCard from './AuthorCard';
import { showToast } from '../common/Toast';
import { getPostTrustSignals } from '../../utils/trustSignals';
import './PostCard.css';

export interface PostCardData {
  post_id: string;
  actor: {
    actor_id: string;
    actor_type: string;
    display_name: string;
    avatar_url: string | null;
    cover_url?: string | null;
  } | null;
  content: string;
  media: any[];
  intent?: 'personal' | 'friends' | 'booking' | 'service_offer' | 'product_offer' | 'project' | 'vote' | 'event';
  intent_metadata?: Record<string, any>;
  created_at: string;
  reactions_count: number;
  comments_count: number;
  user_reaction: string | null;
  vote_results?: {
    options: Array<{ index: number; text: string; count: number; percentage: number }>;
    total_votes: number;
    closes_at?: string;
    is_closed?: boolean;
  };
  cta?: {
    cta_id: string;
    cta_type: 'booking' | 'service' | 'payment';
    target_actor_id: string | null;
    target_group_id: string | null;
    price: number | null;
    currency: string;
  };
  social_impact?: {
    group_name: string | null;
    total_impact_cents: number; // Em centavos
  };
  linked_event?: {
    id: string;
    title: string;
    datetime_start: string;
    location_cultural_profile_id: string | null;
    shared_by: string;
  };
}

interface PostCardProps {
  post: PostCardData;
  onReaction: (postId: string, reactionType: string) => Promise<void>;
  onComment: (postId: string, content: string) => Promise<void>;
  onViewComments?: (postId: string) => void;
  onCTAConfirmed?: (postId: string) => void; // Callback quando CTA é confirmado
  onVote?: (postId: string, optionIndex: number) => Promise<void>; // Callback para votar
}

export default function PostCard({ post, onReaction, onCTAConfirmed, onVote }: PostCardProps) {
  const [showCommentsDrawer, setShowCommentsDrawer] = useState(false);
  const [showCTAModal, setShowCTAModal] = useState(false);
  const [selectedVoteOption, setSelectedVoteOption] = useState<number | null>(null);
  const [isReacting, setIsReacting] = useState(false);
  const [isVoting, setIsVoting] = useState(false);

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'agora';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  };

  const handleReaction = async (reactionType: string) => {
    if (isReacting) return;
    
    setIsReacting(true);
    try {
      await onReaction(post.post_id, reactionType);
      // Feedback visual já acontece via atualização do estado
    } catch (error) {
      console.error('Erro ao reagir:', error);
      showToast('Erro ao reagir. Tente novamente.', 'error');
    } finally {
      setIsReacting(false);
    }
  };


  const handleShare = async () => {
    const postUrl = `${window.location.origin}/social/post/${post.post_id}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(postUrl);
        showToast('Link copiado!', 'success');
      } else {
        // Fallback para navegadores antigos
        const textArea = document.createElement('textarea');
        textArea.value = postUrl;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
          showToast('Link copiado!', 'success');
        } catch (fallbackErr) {
          showToast('Não foi possível copiar o link', 'error');
        }
        document.body.removeChild(textArea);
      }
    } catch (err) {
      showToast('Erro ao copiar link', 'error');
    }
  };

  // Função para determinar badge de tipo baseado no intent e actor_type
  const getTypeBadge = () => {
    if (post.intent === 'vote') return { emoji: '🗳️', label: 'Votação' };
    if (post.intent === 'project') return { emoji: '📋', label: 'Projeto' };
    if (post.intent === 'service_offer') return { emoji: '🛠️', label: 'Serviço' };
    if (post.intent === 'product_offer') return { emoji: '🛍️', label: 'Produto' };
    if (post.intent === 'booking') return { emoji: '📅', label: 'Agendamento' };
    if (post.intent === 'event') return { emoji: '🎭', label: 'Evento' };
    if (post.intent === 'friends') return { emoji: '👥', label: 'Amigos' };
    if (post.actor?.actor_type === 'page') return { emoji: '🏢', label: 'Empresa' };
    return { emoji: '👤', label: 'Pessoa' };
  };

  const typeBadge = getTypeBadge();
  const isServiceOffer = post.intent === 'service_offer';
  const isProductOffer = post.intent === 'product_offer';
  const isEvent = post.intent === 'event';
  const isProject = post.intent === 'project';
  const isVote = post.intent === 'vote';
  const hasIntent = post.intent && post.intent !== 'personal' && post.intent !== 'friends';
  const hasTransaction = post.cta && post.cta.price && post.cta.price > 0;

  // Sinais de confiança para o post
  const postTrustSignals = getPostTrustSignals({
    intent: post.intent,
    actor: post.actor,
    created_at: post.created_at,
    cta: post.cta,
  });

  // Micro social proof: atividade recente
  const getSocialProofText = (): string | null => {
    const postDate = new Date(post.created_at).getTime();
    const now = Date.now();
    const hoursOld = (now - postDate) / (1000 * 60 * 60);
    const daysOld = hoursOld / 24;

    // Novo hoje
    if (hoursOld < 24) {
      if (hoursOld < 1) {
        return 'Novo agora';
      } else if (hoursOld < 6) {
        return 'Novo hoje';
      } else {
        return 'Atividade recente';
      }
    }

    // Atividade nas últimas 48h
    if (daysOld < 2) {
      return 'Atividade recente';
    }

    // Comentários ou reações recentes indicam atividade
    if (post.comments_count > 0 || post.reactions_count > 0) {
      if (daysOld < 7) {
        return 'Apoiando agora';
      }
    }

    return null;
  };

  const socialProofText = getSocialProofText();

  return (
    <article 
      className={`post-card ${isServiceOffer ? 'post-card--service' : ''} ${isProductOffer ? 'post-card--product' : ''} ${isEvent ? 'post-card--event' : ''} ${isProject ? 'post-card--project' : ''} ${isVote ? 'post-card--vote' : ''} ${hasIntent ? 'post-card--has-intent' : ''}`}
      data-post-id={post.post_id}
    >
      {/* Badge de Tipo (obrigatório) - destacado para posts com intent */}
      <div className={`card-type-badge ${hasIntent ? 'card-type-badge--highlight' : ''}`}>
        <span className="type-badge-emoji">{typeBadge.emoji}</span>
        <span className="type-badge-label">{typeBadge.label}</span>
        {hasTransaction && (
          <span className="type-badge-transaction">💰 Transação</span>
        )}
      </div>

      {/* Header */}
      <div className="post-header">
        {post.actor ? (
          <AuthorCard
            actorId={post.actor.actor_id}
            actorType={post.actor.actor_type}
            displayName={post.actor.display_name}
            avatarUrl={post.actor.avatar_url}
            companyStatus={(post.actor as any).company_status}
            onClick={() => {
              if (!post.actor) return;
              if (post.actor.actor_type === 'page') {
                window.history.pushState({}, '', `/company/${post.actor.actor_id}`);
                window.dispatchEvent(new PopStateEvent('popstate'));
              } else {
                window.history.pushState({}, '', `/profile/${post.actor.actor_id}`);
                window.dispatchEvent(new PopStateEvent('popstate'));
              }
            }}
            compact={true}
          />
        ) : (
          <div className="post-author">
            <div className="author-avatar-placeholder">U</div>
            <div className="author-info">
              <span className="author-name">Usuário</span>
            </div>
          </div>
        )}
        <time className="post-time">{formatDate(post.created_at)}</time>
      </div>

      {/* Conteúdo */}
      <div className="post-content">
        {/* Badge de evento compartilhado */}
        {post.linked_event && (
          <div className="post-shared-event-badge">
            🔁 Compartilhado por <strong>{post.linked_event.shared_by}</strong> do evento{' '}
            <strong 
              className="event-link"
              onClick={() => {
                window.location.href = `/cultural/events/${post.linked_event!.id}`;
              }}
            >
              {post.linked_event.title}
            </strong>
          </div>
        )}
        
        {/* Título do serviço (se for service_offer) */}
        {isServiceOffer && post.intent_metadata?.title && (
          <h3 className="service-title">{post.intent_metadata.title}</h3>
        )}
        
        <p className={isServiceOffer ? 'service-description' : ''}>{post.content}</p>
        
        {/* Informações do serviço destacadas */}
        {isServiceOffer && (
          <div className="service-info">
            {post.intent_metadata?.category_name && (
              <span className="service-category">
                📂 {post.intent_metadata.category_name}
              </span>
            )}
            {post.intent_metadata?.duration && (
              <span className="service-duration">
                ⏱️ {post.intent_metadata.duration} {post.intent_metadata.duration_unit || 'horas'}
              </span>
            )}
          </div>
        )}
        
        {post.media && post.media.length > 0 && (
          <div className="post-media">
            {post.media.map((media, idx) => (
              <div key={idx} className="media-item">
                {media.type === 'image' && (
                  <img src={media.url} alt={`Mídia ${idx + 1}`} />
                )}
                {media.type === 'video' && (
                  <video src={media.url} controls />
                )}
              </div>
            ))}
          </div>
        )}


        {/* Vote Interface */}
        {post.intent === 'vote' && post.intent_metadata?.options && (
          <div className="post-vote">
            {post.vote_results?.is_closed ? (
              <div className="vote-results">
                <h4>Resultados da votação:</h4>
                {post.vote_results.options.map((opt, idx) => (
                  <div key={idx} className="vote-option-result">
                    <span>{opt.text}</span>
                    <div className="vote-bar">
                      <div 
                        className="vote-bar-fill" 
                        style={{ width: `${opt.percentage}%` }}
                      />
                    </div>
                    <span>{opt.count} votos ({opt.percentage}%)</span>
                  </div>
                ))}
                <p>Total: {post.vote_results.total_votes} votos</p>
              </div>
            ) : (
              <div className="vote-options">
                <h4>Vote:</h4>
                {post.intent_metadata.options.map((option: string, idx: number) => (
                  <button
                    key={idx}
                    className={`vote-option-btn ${selectedVoteOption === idx ? 'selected' : ''}`}
                    onClick={async () => {
                      if (onVote && !isVoting) {
                        setSelectedVoteOption(idx);
                        setIsVoting(true);
                        try {
                          await onVote(post.post_id, idx);
                          showToast('Voto registrado!', 'success');
                        } catch (error) {
                          console.error('Erro ao votar:', error);
                          setSelectedVoteOption(null);
                          showToast('Erro ao votar. Tente novamente.', 'error');
                        } finally {
                          setIsVoting(false);
                        }
                      }
                    }}
                    disabled={!onVote || selectedVoteOption !== null || isVoting}
                  >
                    {option}
                  </button>
                ))}
                {post.vote_results && (
                  <p className="vote-count">Total: {post.vote_results.total_votes} votos</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* Sinais de confiança do post */}
        {postTrustSignals.length > 0 && (isServiceOffer || isProductOffer || isEvent) && (
          <div className="post-trust-signals">
            {postTrustSignals.map((signal, index) => (
              <span key={index} className="post-trust-badge">
                {signal.icon && <span className="trust-icon">{signal.icon}</span>}
                <span className="trust-label">{signal.label}</span>
              </span>
            ))}
          </div>
        )}

        {/* Micro social proof */}
        {socialProofText && (isServiceOffer || isProductOffer || isEvent) && (
          <div className="post-social-proof">
            <span className="social-proof-icon">💚</span>
            <span className="social-proof-text">{socialProofText}</span>
          </div>
        )}

        {/* CTA */}
        {post.cta && (
          <div className={`post-cta ${isServiceOffer ? 'post-cta--service' : ''} ${isProductOffer ? 'post-cta--product' : ''}`}>
            {post.cta.cta_type === 'booking' && (
              <button 
                className="cta-button booking"
                onClick={() => setShowCTAModal(true)}
              >
                📅 Agendar
              </button>
            )}
            {post.cta.cta_type === 'service' && (
              <div className="service-cta-wrapper">
                {post.cta.price ? (
                  <div className="service-price-highlight">
                    <span className="service-price-label">A partir de</span>
                    <span className="service-price-value">
                      {new Intl.NumberFormat('pt-BR', {
                        style: 'currency',
                        currency: post.cta.currency || 'BRL',
                      }).format(post.cta.price)}
                    </span>
                  </div>
                ) : null}
                <button 
                  className="cta-button service cta-button--service-highlight"
                  onClick={() => setShowCTAModal(true)}
                >
                  🛠️ Contratar
                </button>
              </div>
            )}
            {/* Bloco 2.2: CTA para serviços sem CTA definido - "Ver mais" */}
            {isServiceOffer && !post.cta && (
              <div className="service-cta-wrapper">
                <button 
                  className="cta-button service cta-button--service-view"
                  onClick={() => {
                    // Scroll para o topo do card ou ação de visualização
                    const cardElement = document.querySelector(`[data-post-id="${post.post_id}"]`);
                    if (cardElement) {
                      cardElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                  }}
                >
                  👁️ Ver mais
                </button>
              </div>
            )}
            {post.cta.cta_type === 'payment' && (
              <div className={isProductOffer ? 'product-cta-wrapper' : ''}>
                {isProductOffer && post.cta.price ? (
                  <div className="product-price-highlight">
                    <span className="product-price-label">Preço</span>
                    <span className="product-price-value">
                      {new Intl.NumberFormat('pt-BR', {
                        style: 'currency',
                        currency: post.cta.currency || 'BRL',
                      }).format(post.cta.price)}
                    </span>
                  </div>
                ) : null}
                <button 
                  className={`cta-button payment ${isProductOffer ? 'cta-button--product-highlight' : ''}`}
                  onClick={() => setShowCTAModal(true)}
                >
                  {isProductOffer ? '🛍️ Comprar' : '💳 Pagar'}
                  {post.cta.price && !isProductOffer && (
                    <span className="cta-price">
                      {new Intl.NumberFormat('pt-BR', {
                        style: 'currency',
                        currency: post.cta.currency || 'BRL',
                      }).format(post.cta.price)}
                    </span>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Transaction Impact - Sempre exibir quando houver CTA com preço */}
        {hasTransaction && (
          <>
            <TransactionImpact postId={post.post_id} ctaId={post.cta?.cta_id || null} currency={post.cta?.currency || 'BRL'} />
            <CommunitiesBenefited postId={post.post_id} ctaId={post.cta?.cta_id || null} />
          </>
        )}

        {/* Modal de CTA */}
        {showCTAModal && post.cta && (
          <CTAModal
            cta={post.cta}
            postId={post.post_id}
            postIntent={post.intent}
            onClose={() => setShowCTAModal(false)}
            onConfirm={() => {
              // Notificar componente pai para atualizar feed
              if (onCTAConfirmed) {
                onCTAConfirmed(post.post_id);
              } else {
                // Fallback: recarregar página
                window.location.reload();
              }
            }}
          />
        )}

        {/* Impacto Social */}
        {post.social_impact && post.social_impact.total_impact_cents > 0 && (
          <div className="post-social-impact">
            <span className="impact-badge">
              💚 Este post gerou impacto de{' '}
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL',
              }).format(post.social_impact.total_impact_cents / 100)}{' '}
              para o grupo {post.social_impact.group_name}
            </span>
          </div>
        )}
      </div>

      {/* Ações */}
      <div className="post-actions">
        <button
          className={`action-btn like-btn ${post.user_reaction === 'like' ? 'active' : ''} ${isReacting ? 'loading' : ''}`}
          onClick={() => handleReaction('like')}
          disabled={isReacting}
        >
          {isReacting ? '⏳' : '👍'} Curtir
        </button>
        <button
          className="action-btn comment-btn"
          onClick={() => setShowCommentsDrawer(true)}
        >
          💬 Comentar {post.comments_count > 0 && `(${post.comments_count})`}
        </button>
        <button className="action-btn share-btn" onClick={handleShare}>
          🔗 Compartilhar
        </button>
      </div>

      {/* Estatísticas */}
      {(post.reactions_count > 0 || post.comments_count > 0) && (
        <div className="post-stats">
          {post.reactions_count > 0 && (
            <span className="reactions-count">{post.reactions_count} reações</span>
          )}
          {post.comments_count > 0 && (
            <span className="comments-count">{post.comments_count} comentários</span>
          )}
        </div>
      )}

      {/* CommentsDrawer */}
      <CommentsDrawer
        postId={post.post_id}
        isOpen={showCommentsDrawer}
        onClose={() => setShowCommentsDrawer(false)}
        onCommentAdded={() => {
          // O contador será atualizado quando o feed recarregar
        }}
      />
    </article>
  );
}





