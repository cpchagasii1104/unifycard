// src/components/social/CTAModal.tsx
// Modal para confirmar CTA (agendar/contratar/pagar)

import { useState } from 'react';
import { confirmCTA, type ConfirmCTAResponse } from '../../api/social';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { getSuccessMessage } from '../../utils/actorLanguage';
import { showToast } from '../common/Toast';
import TransactionImpactSummary from './TransactionImpactSummary';
import { validateActiveActor, safeApiCall, safeNumber } from '../../utils/guardrails';
import './CTAModal.css';

interface CTAModalProps {
  cta: {
    cta_id: string;
    cta_type: 'booking' | 'service' | 'payment';
    target_actor_id: string | null;
    target_group_id: string | null;
    price: number | null;
    currency: string;
  };
  postId: string;
  postIntent?: 'personal' | 'friends' | 'booking' | 'service_offer' | 'product_offer' | 'project' | 'vote' | 'event';
  onClose: () => void;
  onConfirm: () => void; // Callback após confirmação bem-sucedida
}

export default function CTAModal({ cta, postId: _postId, postIntent, onClose, onConfirm }: CTAModalProps) {
  const { activeActor } = useActiveActor();
  const [step, setStep] = useState<'confirm' | 'processing' | 'success' | 'error'>('confirm');
  const [error, setError] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmCTAResponse | null>(null);

  const formatPrice = (price: number | null, currency: string = 'BRL'): string => {
    if (!price) return 'A combinar';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency,
    }).format(price);
  };

  const getCTATitle = (): string => {
    if (postIntent === 'product_offer' && cta.cta_type === 'payment') {
      return 'Confirmar Compra';
    }
    switch (cta.cta_type) {
      case 'booking':
        return 'Confirmar Agendamento';
      case 'service':
        return 'Confirmar Contratação';
      case 'payment':
        return 'Confirmar Pagamento';
      default:
        return 'Confirmar Ação';
    }
  };

  const getCTADescription = (): string => {
    if (postIntent === 'product_offer' && cta.cta_type === 'payment') {
      return 'Você está prestes a comprar um produto. Esta ação gerará uma transação econômica e impacto social.';
    }
    switch (cta.cta_type) {
      case 'booking':
        return 'Você está prestes a confirmar um agendamento. Esta ação gerará uma transação econômica.';
      case 'service':
        return 'Você está prestes a contratar um serviço. Esta ação gerará uma transação econômica e impacto social.';
      case 'payment':
        return 'Você está prestes a realizar um pagamento. Esta ação gerará uma transação econômica e impacto social.';
      default:
        return 'Esta ação gerará uma transação econômica.';
    }
  };

  const handleConfirm = async () => {
    // Guardrail: validar activeActor antes de confirmar
    if (!validateActiveActor(activeActor)) {
      setError('Nenhum ator ativo selecionado. Selecione um ator no menu superior.');
      setStep('error');
      showToast('Erro: ator não válido', 'error');
      return;
    }

    setStep('processing');
    setError(null);

    // Usar safeApiCall com fallback
    const result = await safeApiCall(
      async () => confirmCTA(cta.cta_id, {
        notes: notes.trim() || undefined,
      }),
      {
        success: false,
        message: 'Erro ao confirmar ação',
      },
      'Erro ao confirmar CTA'
    );

    // Verificar se houve erro
    if (!result.success) {
      setError(result.message || 'Erro ao confirmar ação');
      setStep('error');
      showToast(result.message || 'Erro ao confirmar ação. Tente novamente.', 'error');
      return;
    }

    // Salvar resultado para mostrar no resumo
    setConfirmationResult(result);
    
    // Sucesso
    setStep('success');
    
    // Mostrar toast simples
    showToast(result.message || 'Transação confirmada com sucesso!', 'success');
    
    // Disparar evento de mudança de impacto
    if (validateActiveActor(activeActor)) {
      window.dispatchEvent(new CustomEvent('impact-changed', {
        detail: {
          actor_id: activeActor!.actor_id,
          actor_type: activeActor!.actor_type,
        },
      }));
    }
    
    // Disparar evento para atualizar feed
    window.dispatchEvent(new CustomEvent('cta-confirmed', {
      detail: {
        cta_id: cta.cta_id,
        cta_type: cta.cta_type,
      },
    }));
    
    // Não fechar automaticamente - usuário escolhe quando fechar via botões do resumo
  };

  if (step === 'success') {
    const successMessage = getSuccessMessage(activeActor, 'supported');
    
    // Bloco 2.3: Usar apenas dados retornados pela API (não calcular)
    // Total vem do revenue_entry ou do preço do CTA (já em centavos se vier da API)
    const totalAmount = confirmationResult?.revenue_entry?.amount_cents || 
                       (cta.price ? safeNumber(Math.round(cta.price * 100), 0) : 0);
    
    return (
      <div className="cta-modal-overlay" onClick={onClose}>
        <div className="cta-modal" onClick={(e) => e.stopPropagation()}>
          <div className="cta-modal-success cta-modal-success--animated">
            <div className="success-icon success-icon--animated">✓</div>
            <h2>Confirmação realizada!</h2>
            <p>{successMessage}</p>
            
            {/* Mini-resumo de impacto */}
            {confirmationResult && totalAmount > 0 && (
              <TransactionImpactSummary
                totalAmount={totalAmount}
                currency={cta.currency}
                revenueEntry={confirmationResult.revenue_entry}
                profitShareEntry={confirmationResult.profit_share_entry}
                isProduct={postIntent === 'product_offer'}
                onViewLedger={() => {
                  window.location.href = '/social/ledger';
                }}
                onBackToFeed={() => {
                  onConfirm();
                  onClose();
                }}
              />
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="cta-modal-overlay" onClick={onClose}>
      <div className="cta-modal" onClick={(e) => e.stopPropagation()}>
        <div className="cta-modal-header">
          <h2>{getCTATitle()}</h2>
          <button className="cta-modal-close" onClick={onClose}>×</button>
        </div>

        <div className="cta-modal-content">
          <p className="cta-modal-description">{getCTADescription()}</p>

          {/* Valor */}
          {cta.price && (
            <div className="cta-modal-price">
              <span className="price-label">Valor:</span>
              <span className="price-value">{formatPrice(cta.price, cta.currency)}</span>
            </div>
          )}

          {/* Notas opcionais */}
          <div className="cta-modal-notes">
            <label htmlFor="cta-notes">Observações (opcional):</label>
            <textarea
              id="cta-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Adicione alguma observação sobre esta transação..."
              rows={3}
              disabled={step === 'processing'}
            />
          </div>

          {/* Erro */}
          {error && (
            <div className="cta-modal-error">
              <p>{error}</p>
              <button onClick={() => { setError(null); setStep('confirm'); }}>
                Tentar novamente
              </button>
            </div>
          )}

          {/* Aviso de impacto */}
          {cta.target_group_id && (
            <div className="cta-modal-impact">
              <span className="impact-icon">💚</span>
              <p>Esta transação gerará impacto social para o grupo associado.</p>
            </div>
          )}
        </div>

        <div className="cta-modal-actions">
          <button
            className="cta-modal-cancel"
            onClick={onClose}
            disabled={step === 'processing'}
          >
            Cancelar
          </button>
          <button
            className="cta-modal-submit"
            onClick={handleConfirm}
            disabled={step === 'processing'}
          >
            {step === 'processing' ? 'Processando...' : 'Confirmar'}
          </button>
        </div>
      </div>
    </div>
  );
}





