// src/components/social/CommunityActivitySummary.tsx
// Resumo de atividade recente da comunidade

import { useState, useEffect } from 'react';
import { getLedger } from '../../api/social';
import { getSocialFeed, type PostCardData } from '../../api/social';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { validateActiveActor, safeLedgerEntries, safePostsArray, safeApiCall, safeNumber, safeDate } from '../../utils/guardrails';
import { devLog } from '../../utils/devLog';
import './CommunityActivitySummary.css';

interface ActivitySummary {
  servicesContracted: number;
  productsPurchased: number;
  eventsCreated: number;
  totalImpactToday: number; // Em centavos
}

export default function CommunityActivitySummary() {
  const { activeActor } = useActiveActor();
  const [summary, setSummary] = useState<ActivitySummary>({
    servicesContracted: 0,
    productsPurchased: 0,
    eventsCreated: 0,
    totalImpactToday: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (validateActiveActor(activeActor)) {
      loadActivitySummary();
    }
  }, [activeActor?.actor_id]);

  const loadActivitySummary = async () => {
    // Guardrail: validar activeActor
    if (!validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      const now = Date.now();
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayStartTime = todayStart.getTime();

      // Buscar ledger entries de hoje - com fallback
      const ledgerResponse = await safeApiCall(
        async () => getLedger({ limit: 100 }),
        { entries: [] },
        'Erro ao buscar ledger para resumo de atividade'
      );
      const allEntries = safeLedgerEntries(ledgerResponse.entries);
      const todayEntries = allEntries.filter((entry: any) => {
        const entryDate = safeDate(entry?.created_at, 0);
        return entryDate >= todayStartTime;
      });

      // Contar serviços contratados (entries com cta_id e amount_type = revenue ou profit_share)
      const serviceEntries = todayEntries.filter(
        (entry: any) =>
          entry?.cta_id &&
          (entry.amount_type === 'revenue' || entry.amount_type === 'profit_share')
      );
      const servicesContracted = new Set(serviceEntries.map((e: any) => e.cta_id)).size;

      // Contar produtos comprados (similar, mas pode ter metadata diferente)
      const productsPurchased = 0; // Pode ser refinado depois

      // Calcular impacto total de hoje (soma de profit_share) - com fallback
      const totalImpactToday = todayEntries
        .filter((entry: any) => entry?.amount_type === 'profit_share')
        .reduce((sum: number, entry: any) => sum + safeNumber(entry?.amount_cents, 0), 0);

      // Buscar posts das últimas 24h para contar eventos criados - não crítico
      let eventsCreated = 0;
      const feedData = await safeApiCall(
        async () => getSocialFeed({
          actor_type: activeActor!.actor_type as 'user' | 'page',
          actor_id: activeActor!.actor_id,
          limit: 50,
        }),
        { posts: [], next_cursor: null, has_more: false },
        'Erro ao buscar eventos recentes'
      );

      const last24h = now - 24 * 60 * 60 * 1000;
      const posts = safePostsArray(feedData.posts);
      const recentEvents = posts.filter((post: PostCardData) => {
        const postDate = safeDate(post?.created_at, 0);
        return (
          postDate >= last24h &&
          (post.intent === 'event' || post.linked_event)
        );
      });
      eventsCreated = recentEvents.length;

      setSummary({
        servicesContracted,
        productsPurchased,
        eventsCreated,
        totalImpactToday,
      });
    } catch (err) {
      // Erro inesperado - não quebrar, apenas logar
      devLog.error('Erro inesperado ao carregar resumo de atividade:', err);
      // Manter estado vazio - componente não será exibido
    } finally {
      setIsLoading(false);
    }
  };

  // Não mostrar se não houver atividade significativa
  const hasActivity =
    summary.servicesContracted > 0 ||
    summary.productsPurchased > 0 ||
    summary.eventsCreated > 0 ||
    summary.totalImpactToday > 0;

  if (isLoading || !hasActivity) {
    return null;
  }

  return (
    <div className="community-activity-summary">
      <div className="activity-header">
        <span className="activity-icon">💚</span>
        <span className="activity-title">Hoje na sua comunidade</span>
      </div>
      <div className="activity-stats">
        {summary.servicesContracted > 0 && (
          <div className="activity-stat-item">
            <span className="stat-icon">🛠️</span>
            <span className="stat-text">
              {summary.servicesContracted} {summary.servicesContracted === 1 ? 'serviço contratado' : 'serviços contratados'}
            </span>
          </div>
        )}
        {summary.productsPurchased > 0 && (
          <div className="activity-stat-item">
            <span className="stat-icon">🛍️</span>
            <span className="stat-text">
              {summary.productsPurchased} {summary.productsPurchased === 1 ? 'produto comprado' : 'produtos comprados'}
            </span>
          </div>
        )}
        {summary.eventsCreated > 0 && (
          <div className="activity-stat-item">
            <span className="stat-icon">🎭</span>
            <span className="stat-text">
              {summary.eventsCreated} {summary.eventsCreated === 1 ? 'evento criado' : 'eventos criados'}
            </span>
          </div>
        )}
        {summary.totalImpactToday > 0 && (
          <div className="activity-stat-item activity-stat-impact">
            <span className="stat-icon">✨</span>
            <span className="stat-text">
              R$ {(summary.totalImpactToday / 100).toFixed(2)} de impacto gerado hoje
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

