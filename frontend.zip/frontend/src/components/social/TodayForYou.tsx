// src/components/social/TodayForYou.tsx
// Sugestão contextual diária para o usuário

import { useState, useEffect } from 'react';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { getSocialFeed, type PostCardData } from '../../api/social';
import { listPublicCulturalEvents, type CulturalEvent } from '../../api/cultural';
import { getLedgerSummary } from '../../api/social';
import { getIdentityProfile } from '../../api/identity';
import { validateActiveActor, safeUserCity, safePostsArray, safeApiCall, safeString, safeDate, safeArray } from '../../utils/guardrails';
import { devLog } from '../../utils/devLog';
import './TodayForYou.css';

interface TodaySuggestion {
  type: 'service' | 'event' | 'community' | 'local';
  title: string;
  description: string;
  action: () => void;
  icon: string;
}

export default function TodayForYou() {
  const { activeActor } = useActiveActor();
  const [suggestion, setSuggestion] = useState<TodaySuggestion | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userCity, setUserCity] = useState<string | null>(null);

  useEffect(() => {
    if (validateActiveActor(activeActor)) {
      loadUserCity();
      generateSuggestion();
    }
  }, [activeActor?.actor_id]);

  const loadUserCity = async () => {
    const city = await safeApiCall(
      async () => {
        const identity = await getIdentityProfile();
        return identity.residence?.city?.name || null;
      },
      null,
      'Erro ao carregar cidade do usuário'
    );
    setUserCity(safeUserCity(city));
  };

  const generateSuggestion = async () => {
    // Guardrail: validar activeActor
    if (!validateActiveActor(activeActor)) {
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);

      // Buscar feed e eventos - com fallbacks
      const [feedData, culturalEvents] = await Promise.all([
        safeApiCall(
          async () => getSocialFeed({
            actor_type: activeActor!.actor_type as 'user' | 'page',
            actor_id: activeActor!.actor_id,
            limit: 20,
          }),
          { posts: [], next_cursor: null, has_more: false },
          'Erro ao buscar feed para sugestão'
        ),
        safeApiCall(
          async () => listPublicCulturalEvents({ limit: 10 }),
          { events: [], next_cursor: null },
          'Erro ao buscar eventos culturais para sugestão'
        ),
      ]);

      // Buscar ledger summary para ver comunidades beneficiadas - não crítico
      const ledgerSummary = await safeApiCall(
        async () => getLedgerSummary(),
        { total_revenue_cents: 0, total_profit_share_received_cents: 0, total_donations_given_cents: 0, total_commissions_cents: 0, group_contributions: [] },
        'Erro ao buscar ledger summary'
      );

      const now = Date.now();
      const last24h = now - 24 * 60 * 60 * 1000;

      // 1. Prioridade: Novo serviço na cidade do usuário
      const safeCity = safeUserCity(userCity);
      if (safeCity) {
        const posts = safePostsArray(feedData.posts);
        const localServices = posts.filter((post: PostCardData) => {
          const postDate = safeDate(post?.created_at, 0);
          const content = safeString(post.content, '').toLowerCase();
          const location = safeString(post.intent_metadata?.location, '').toLowerCase();
          return (
            post.intent === 'service_offer' &&
            post.cta?.cta_type === 'service' &&
            postDate >= last24h &&
            (content.includes(safeCity.toLowerCase()) || location.includes(safeCity.toLowerCase()))
          );
        });

        if (localServices.length > 0) {
          const service = localServices[0];
          const title = safeString(service.intent_metadata?.title || service.content, 'Serviço').substring(0, 50);
          setSuggestion({
            type: 'local',
            title: 'Novo serviço na sua cidade',
            description: `${title}...`,
            action: () => {
              if (service?.post_id) {
                const serviceCard = document.querySelector(`[data-post-id="${service.post_id}"]`);
                if (serviceCard) {
                  serviceCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  return;
                }
              }
              window.scrollTo({ top: 0, behavior: 'smooth' });
            },
            icon: '🛠️',
          });
          setIsLoading(false);
          return;
        }
      }

      // 2. Evento próximo (próximas 48h) - com fallback
      const events = safeArray<CulturalEvent>(culturalEvents.events, []);
      const upcomingEvents = events.filter((event: CulturalEvent) => {
        const eventDate = safeDate(event?.datetime_start, 0);
        if (eventDate === 0) return false;
        const hoursUntilEvent = (eventDate - now) / (1000 * 60 * 60);
        return hoursUntilEvent > 0 && hoursUntilEvent < 48;
      });

      if (upcomingEvents.length > 0) {
        const event = upcomingEvents[0];
        const eventDateTimestamp = safeDate(event?.datetime_start, 0);
        if (eventDateTimestamp > 0) {
          const eventDate = new Date(eventDateTimestamp).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
          setSuggestion({
            type: 'event',
            title: 'Evento próximo',
            description: `${safeString(event.title, 'Evento')} - ${eventDate}`,
            action: () => {
              if (event?.id) {
                window.location.href = `/cultural/events/${event.id}`;
              }
            },
            icon: '🎭',
          });
          setIsLoading(false);
          return;
        }
      }

      // 3. Comunidade que recebeu impacto recentemente - com fallback
      const contributions = safeArray(ledgerSummary?.group_contributions, []) as Array<{
        group_id: string;
        group_name: string;
        total_contributed_cents: number;
      }>;
      if (contributions.length > 0) {
        const recentGroup = contributions[0];
        if (recentGroup?.group_id && recentGroup?.group_name) {
          setSuggestion({
            type: 'community',
            title: 'Comunidade beneficiada',
            description: `${safeString(recentGroup.group_name, 'Comunidade')} recebeu impacto recentemente`,
            action: () => {
              window.location.href = `/grupos/${recentGroup.group_id}`;
            },
            icon: '👥',
          });
          setIsLoading(false);
          return;
        }
      }

      // 4. Novo serviço geral (sem filtro de cidade) - com fallback
      const posts = safePostsArray(feedData.posts);
      const newServices = posts.filter((post: PostCardData) => {
        const postDate = safeDate(post?.created_at, 0);
        return (
          post.intent === 'service_offer' &&
          post.cta?.cta_type === 'service' &&
          postDate >= last24h
        );
      });

      if (newServices.length > 0) {
        const service = newServices[0];
        const title = safeString(service.intent_metadata?.title || service.content, 'Serviço').substring(0, 50);
        setSuggestion({
          type: 'service',
          title: 'Novo serviço disponível',
          description: `${title}...`,
          action: () => {
            if (service?.post_id) {
              const serviceCard = document.querySelector(`[data-post-id="${service.post_id}"]`);
              if (serviceCard) {
                serviceCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                return;
              }
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
          },
          icon: '🛠️',
        });
        setIsLoading(false);
        return;
      }

      // Sem sugestão - não é erro, apenas não há conteúdo relevante
      setSuggestion(null);
    } catch (err) {
      // Erro inesperado - não quebrar, apenas logar
      devLog.error('Erro inesperado ao gerar sugestão:', err);
      setSuggestion(null);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading || !suggestion) {
    return null;
  }

  return (
    <div className="today-for-you">
      <div className="today-header">
        <span className="today-icon">{suggestion.icon}</span>
        <span className="today-title">Hoje para você</span>
      </div>
      <div className="today-content">
        <h3 className="today-suggestion-title">{suggestion.title}</h3>
        <p className="today-suggestion-description">{suggestion.description}</p>
        <button className="today-action-button" onClick={suggestion.action}>
          Ver mais
        </button>
      </div>
    </div>
  );
}

