// src/components/auth/ProtectedRoute.tsx
// Componente para proteger rotas que requerem autenticação

import { Navigate } from 'react-router-dom';
import { isAuthenticated, getTenantId } from '../../config/auth';
import { useSession } from '../../contexts/SessionProvider';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { sessionReady } = useSession();
  
  // REGRA CRÍTICA: Aguardar explicitamente sessionReady
  // Durante bootstrap, NUNCA redirecionar para /login
  // Isso previne loop de login quando bootstrap está em andamento
  if (!sessionReady) {
    // Bootstrap em andamento - aguardar sem redirecionar
    return null;
  }
  
  // Após bootstrap completo, verificar autenticação
  // Requer token E tenantId para considerar autenticado
  // activeActor pode ser null se não houver actors disponíveis (não é erro crítico)
  if (!isAuthenticated() || !getTenantId()) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}












