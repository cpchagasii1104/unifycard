// src/components/ProfileLearning.tsx
// Componente de perfil de aprendizado/trilha - "O Que Você Está Aprendendo"

import { useEffect, useRef, useState } from 'react';
import { CategoryContext } from '@unificard/contracts';
import {
  getLearningProfile,
  updateLearningProfile,
} from '../api/learning';
import {
  getCategoryTree,
  autocompleteCategories,
  createCategoryWithAI,
  suggestCategoryPath,
  type CategoryTree,
  type Category,
  type CategoryAutocompleteResult,
  type CategoryPathSuggestion,
} from '../api/categories';
import { useSession } from '../contexts/SessionProvider';
import { useProfileLearningState } from '../hooks/useProfileLearningState';
import { useProfileLearningLogic } from '../hooks/useProfileLearningLogic';
import ProfileLearningForm from './ProfileLearningForm';
import './ProfileLearning.css';

interface SelectedLearning {
  categoryId: string;
  categoryName: string;
  categoryPath: string[];
  details: string[];
  notes: string;
  progress: 'beginner' | 'intermediate' | 'advanced' | null;
}

export default function ProfileLearning() {
  const {
    categoryTree,
    setCategoryTree,
    searchTerm,
    setSearchTerm,
    searchResults,
    setSearchResults,
    autocompleteResults,
    setAutocompleteResults,
    showAutocomplete,
    setShowAutocomplete,
    isSearching,
    setIsSearching,
    autocompleteError,
    setAutocompleteError,
    isCreatingWithAI,
    setIsCreatingWithAI,
    isRecording,
    setIsRecording,
    _userPlan,
    setUserPlan,
    aiAssistEnabled,
    setAiAssistEnabled,
    recognition,
    setRecognition,
    showSuggestionModal,
    setShowSuggestionModal,
    categorySuggestion,
    setCategorySuggestion,
    isSuggesting,
    setIsSuggesting,
    suggestionError,
    setSuggestionError,
    selectedLearnings,
    setSelectedLearnings,
    expandedCategories,
    setExpandedCategories,
    isLoading,
    setIsLoading,
    isSaving,
    setIsSaving,
    error,
    setError,
    searchFieldError,
    setSearchFieldError,
  } = useProfileLearningState();
  const { isLearningSelected: isLearningSelectedLogic } = useProfileLearningLogic();

  // 🔴 CRÍTICO: Prevenir loop de chamadas - loadData() roda apenas uma vez
  const hasLoadedRef = useRef(false);
  const { sessionReady } = useSession();

  useEffect(() => {
    // GUARD: Não fazer chamadas de API antes de sessionReady
    if (!sessionReady) {
      setIsLoading(false);
      return;
    }
    // Carregar dados apenas uma vez no mount
    if (hasLoadedRef.current) return;
    hasLoadedRef.current = true;

    loadData();
    
    // Carregar features do usuário (versão paga)
    (async () => {
      try {
        const { getUserPlan, getUserFeatures } = await import('../config/features');
        const plan = await getUserPlan();
        const features = await getUserFeatures();
        setUserPlan(plan);
        setAiAssistEnabled(features.aiAssistEnabled);
      } catch (err) {
        console.error('Erro ao carregar features do usuário:', err);
        // Em caso de erro, assumir free (mais restritivo)
        setUserPlan('free');
        setAiAssistEnabled(false);
      }
    })();
  }, [sessionReady]); // Re-executar quando sessionReady mudar para true

  // FEATURE FLAG: Inicializar Web Speech API apenas se feature habilitada (versão paga)
  // Separado em useEffect próprio para não causar loop
  useEffect(() => {
    if (aiAssistEnabled && typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'pt-BR';
      
      recognitionInstance.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSearchTerm(transcript);
        // Disparar busca automática após receber texto da voz
        if (handleSearchRef.current) {
          handleSearchRef.current(transcript);
        }
      };
      
      recognitionInstance.onerror = (event: any) => {
        console.error('Erro no reconhecimento de voz:', event.error);
        setIsRecording(false);
      };
      
      recognitionInstance.onend = () => {
        setIsRecording(false);
      };
      
      setRecognition(recognitionInstance);
    } else {
      // Se feature não habilitada, não inicializar
      setRecognition(null);
    }
  }, [aiAssistEnabled]); // Recriar apenas quando feature flag mudar

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // 🔴 REGRA: Buscar categorias EXCLUSIVAMENTE de context='learning'
      const tree = await getCategoryTree('learning');
      setCategoryTree(tree);

      // Buscar perfil de aprendizado
      const profile = await getLearningProfile().catch(() => ({
        globalUserId: '',
        learnings: [],
        preferences: {},
        metadata: {},
      }));

      // Converter aprendizados do perfil para formato local
      const preferencesObj = profile.preferences as { [categoryId: string]: { details?: string[]; notes?: string; progress?: 'beginner' | 'intermediate' | 'advanced' | null } } || {};
      setSelectedLearnings(
        profile.learnings.map((learning) => ({
          categoryId: learning.categoryId,
          categoryName: learning.categoryName,
          categoryPath: learning.categoryPath,
          details: preferencesObj[learning.categoryId]?.details || [],
          notes: preferencesObj[learning.categoryId]?.notes || '',
          progress: preferencesObj[learning.categoryId]?.progress || null,
        }))
      );
    } catch (err) {
      // 🚫 Nada de retry - falhou → UI mostra erro → fim
      const errorMessage = err instanceof Error ? err.message : 'Não foi possível carregar as categorias agora.';
      setError(errorMessage);
      console.error('[ProfileLearning] Erro ao carregar dados:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Debounce para autocomplete
  const [searchTimeout, setSearchTimeout] = useState<ReturnType<typeof setTimeout> | null>(null);

  // Ref para handleSearch (para uso no callback de voz)
  const handleSearchRef = useRef<((term: string) => Promise<void>) | null>(null);

  // Funções de gravação de voz
  const startRecording = () => {
    if (recognition && !isRecording) {
      try {
        recognition.start();
        setIsRecording(true);
      } catch (err) {
        console.error('Erro ao iniciar gravação:', err);
        setIsRecording(false);
      }
    }
  };

  const stopRecording = () => {
    if (recognition && isRecording) {
      try {
        recognition.stop();
        setIsRecording(false);
      } catch (err) {
        console.error('Erro ao parar gravação:', err);
        setIsRecording(false);
      }
    }
  };

  const handleSearch = async (term: string) => {
    setSearchTerm(term);
    
    // Limpar timeout anterior
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    if (term.length < 1) {
      setSearchResults([]);
      setAutocompleteResults([]);
      setShowAutocomplete(false);
      return;
    }

    // Se termo tem 1+ caractere, usar autocomplete com context='learning'
    if (term.length >= 1) {
      setIsSearching(true);
      setAutocompleteError(null);
      
      // Debounce: aguardar 300ms antes de buscar
      const timeout = setTimeout(async () => {
        try {
          const results = await autocompleteCategories(term, 'learning' as CategoryContext, undefined, 20);
          
          setAutocompleteResults(results);
          setAutocompleteError(null);
          
          // Mostrar dropdown se houver resultados
          if (results.length > 0) {
            setShowAutocomplete(true);
          } else {
            setShowAutocomplete(false);
          }
          
          // Também manter searchResults para compatibilidade
          setSearchResults(results.map(r => ({
            categoryId: r.id,
            parentId: null,
            name: r.name,
            slug: r.slug,
            description: null,
            level: r.level,
            path: r.path,
            createdAt: '',
            updatedAt: '',
          })));
        } catch (err: any) {
          // Tratar erro 429 (rate limit) silenciosamente - não quebrar UI
          if (err?.code === 'RATE_LIMIT' || err?.status === 429) {
            console.warn('[ProfileLearning] Rate limit atingido no autocomplete');
            setAutocompleteResults([]);
            setSearchResults([]);
            setShowAutocomplete(false);
            setAutocompleteError(null); // Não mostrar erro para rate limit
            setIsSearching(false);
            return;
          }
          
          console.error('[ProfileLearning] ERRO:', {
            message: err?.message,
            code: err?.code,
            stack: err?.stack
          });
          
          const errorMessage = err?.message || 'Erro ao buscar sugestões. Verifique sua conexão e tente novamente.';
          setAutocompleteError(errorMessage);
          setAutocompleteResults([]);
          setSearchResults([]);
          setShowAutocomplete(false);
        } finally {
          setIsSearching(false);
        }
      }, 300);
      
      setSearchTimeout(timeout);
    } else {
      // Se termo está vazio, limpar resultados
      setAutocompleteResults([]);
      setSearchResults([]);
      setShowAutocomplete(false);
      setAutocompleteError(null);
      setIsSearching(false);
    }
  };

  // Atualizar ref quando handleSearch mudar
  useEffect(() => {
    handleSearchRef.current = handleSearch;
  }, [handleSearch]);

  const handleSelectAutocomplete = (result: CategoryAutocompleteResult) => {
    // Validar que é um tema de aprendizado (nível 2)
    if (result.level !== 2) {
      setSearchFieldError('Por favor, selecione um tema de aprendizado específico da lista.');
      return;
    }

    // Converter para Category e adicionar como learning
    const category: Category = {
      categoryId: result.id,
      parentId: null,
      name: result.name,
      slug: result.slug,
      description: null,
      level: result.level,
      path: result.path,
      createdAt: '',
      updatedAt: '',
    };
    
    addLearning(category);
    setSearchTerm('');
    setAutocompleteResults([]);
    setShowAutocomplete(false);
    setSearchFieldError(null); // Limpar erro ao selecionar
  };

  const handleSuggestCategory = async () => {
    if (!searchTerm.trim()) {
      setSuggestionError('Digite o nome do tema de aprendizado que deseja sugerir');
      return;
    }

    setIsSuggesting(true);
    setSuggestionError(null);
    try {
      const suggestion = await suggestCategoryPath(searchTerm.trim(), 'learning' as CategoryContext);
      setCategorySuggestion(suggestion);
      setShowSuggestionModal(true);
    } catch (err) {
      console.error('Erro ao sugerir categoria:', err);
      const errorMessage = err instanceof Error ? err.message : 'Erro ao sugerir categoria';
      setSuggestionError(errorMessage);
      if (errorMessage.includes('não permitido') || errorMessage.includes('inválido')) {
        alert(errorMessage);
      }
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleCreateWithAI = async (parentId?: string | null) => {
    if (!searchTerm.trim()) {
      alert('Digite ou fale o nome do tema de aprendizado que deseja criar');
      return;
    }

    setIsCreatingWithAI(true);
    try {
      const result = await createCategoryWithAI(searchTerm.trim(), 'learning' as CategoryContext, parentId);
      
      if (result.created && result.category) {
        // Fechar modal
        setShowSuggestionModal(false);
        setCategorySuggestion(null);
        
        // Mostrar feedback
        if (result.requiresApproval) {
          alert(`📋 ${result.message || `Sua sugestão "${result.category.name}" foi enviada para análise!\n\nO tema será revisado e poderá aparecer no sistema em breve.`}`);
        } else {
          alert(`✅ Tema "${result.category.name}" criado com sucesso!`);
        }
        
        // Recarregar árvore de categorias
        const tree = await getCategoryTree('learning');
        setCategoryTree(tree);
        
        // Adicionar automaticamente se for nível 2 (tema) e já aprovado
        if (result.category.level === 2 && !result.requiresApproval) {
          addLearning(result.category);
        } else {
          // Se não for tema ou precisa aprovação, fazer busca para encontrar
          await handleSearch(searchTerm);
        }
        setSearchTerm('');
      } else if (result.existingCategory) {
        setShowSuggestionModal(false);
        alert(`Tema "${result.existingCategory.name}" já existe!`);
        // Adicionar automaticamente se for nível 2
        if (result.existingCategory.level === 2) {
          addLearning(result.existingCategory);
        } else {
          await handleSearch(searchTerm);
        }
        setSearchTerm('');
      }
    } catch (err) {
      console.error('Erro ao criar categoria via IA:', err);
      const errorMessage = err instanceof Error ? err.message : 'Erro ao criar categoria via IA';
      
      if (errorMessage.includes('❌')) {
        alert(`🚫 ${errorMessage.replace('❌ ', '')}\n\nEste termo não pode ser cadastrado.`);
      } else if (errorMessage.includes('não permitido') || errorMessage.includes('inválido') || errorMessage.includes('Tags HTML') || errorMessage.includes('URLs')) {
        alert(`❌ ${errorMessage}\n\nPor favor, use apenas letras, espaços e hífens.`);
      } else {
        alert(`❌ ${errorMessage}`);
      }
    } finally {
      setIsCreatingWithAI(false);
    }
  };

  const toggleCategory = (categoryId: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId);
    } else {
      newExpanded.add(categoryId);
    }
    setExpandedCategories(newExpanded);
  };

  const isLearningSelected = (categoryId: string): boolean => {
    return isLearningSelectedLogic(categoryId, selectedLearnings);
  };

  const addLearning = (category: Category) => {
    if (isLearningSelected(category.categoryId)) {
      return;
    }

    if (category.level !== 2) {
      alert('Por favor, selecione um tema de aprendizado específico. Navegue pelas subcategorias para encontrar temas.');
      return;
    }

    setSelectedLearnings([
      ...selectedLearnings,
      {
        categoryId: category.categoryId,
        categoryName: category.name,
        categoryPath: category.path,
        details: [],
        notes: '',
        progress: null,
      },
    ]);
    setSearchTerm('');
    setSearchResults([]);
    setSearchFieldError(null); // Limpar erro ao adicionar
  };

  const removeLearning = (categoryId: string) => {
    setSelectedLearnings(selectedLearnings.filter((s) => s.categoryId !== categoryId));
  };

  const updateLearning = (categoryId: string, field: 'details' | 'notes' | 'progress', value: string[] | string | 'beginner' | 'intermediate' | 'advanced' | null) => {
    setSelectedLearnings(
      selectedLearnings.map((s) =>
        s.categoryId === categoryId ? { ...s, [field]: value } : s
      )
    );
  };


  const renderCategoryTree = (categories: CategoryTree[], level: number = 0): JSX.Element[] => {
    return categories.map((category) => {
      const hasChildren = category.children && category.children.length > 0;
      const isExpanded = expandedCategories.has(category.categoryId);
      const isSelected = isLearningSelected(category.categoryId);
      const pathDisplay = category.path.length > 0 
        ? category.path.join(' > ') + ' > ' + category.name
        : category.name;
      
      const isLearning = category.level === 2 || !hasChildren;
      const showAddButton = isLearning && !isSelected;

      return (
        <div key={category.categoryId} className="category-item" style={{ paddingLeft: `${level * 1.5}rem` }}>
          <div className="category-header">
            {hasChildren && (
              <button
                className="expand-button"
                onClick={() => toggleCategory(category.categoryId)}
                aria-label={isExpanded ? 'Recolher' : 'Expandir'}
              >
                {isExpanded ? '▼' : '▶'}
              </button>
            )}
            {!hasChildren && <span className="expand-spacer" />}
            <span className="category-name" title={pathDisplay}>
              {category.name}
            </span>
            {isSelected ? (
              <span className="learning-badge selected">✓ Selecionado</span>
            ) : showAddButton ? (
              <button
                className="add-learning-button"
                onClick={() => addLearning(category)}
                title={`Adicionar ${category.name}`}
              >
                + Adicionar
              </button>
            ) : (
              <span className="category-hint">Navegue para ver temas de aprendizado</span>
            )}
          </div>
          {hasChildren && isExpanded && (
            <div className="category-children">
              {renderCategoryTree(category.children!, level + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError(null);
    setSearchFieldError(null);

    // VALIDAÇÃO OBRIGATÓRIA: Pelo menos um tema deve estar selecionado
    if (selectedLearnings.length === 0) {
      setError('Selecione pelo menos um tema de aprendizado da lista antes de salvar.');
      setIsSaving(false);
      return;
    }

    // VALIDAÇÃO: Se há texto no campo de busca mas nenhum tema selecionado, bloquear
    if (searchTerm.trim().length > 0 && selectedLearnings.length === 0) {
      setSearchFieldError('Selecione um tema de aprendizado da lista. Não é possível salvar apenas texto digitado.');
      setError('Selecione um tema de aprendizado da lista antes de salvar.');
      setIsSaving(false);
      return;
    }

    try {
      await updateLearningProfile({
        learnings: selectedLearnings.map((s) => s.categoryId),
        preferences: selectedLearnings.reduce((acc, learning) => {
          acc[learning.categoryId] = {
            details: learning.details,
            notes: learning.notes || undefined,
            progress: learning.progress || undefined,
          };
          return acc;
        }, {} as Record<string, { details?: string[]; notes?: string; progress?: 'beginner' | 'intermediate' | 'advanced' | null }>),
      });

      alert('Perfil de aprendizado atualizado com sucesso!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao salvar perfil');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="profile-learning">
        <h2>O Que Você Está Aprendendo</h2>
        <div className="loading">Carregando temas de aprendizado...</div>
      </div>
    );
  }

  // 🧠 UI que não quebra - Golden Path: Feed pode estar vazio, app não pode entrar em surto
  if (error && categoryTree.length === 0) {
    return (
      <div className="profile-learning">
        <h2>O Que Você Está Aprendendo</h2>
        <div className="error-message" style={{
          padding: '1.5rem',
          backgroundColor: '#fee2e2',
          border: '1px solid #ef4444',
          borderRadius: '0.5rem',
          color: '#dc2626',
          marginTop: '1rem'
        }}>
          <strong>⚠️ Erro ao carregar categorias</strong>
          <p style={{ marginTop: '0.5rem', marginBottom: 0 }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <ProfileLearningForm
      error={error}
      searchTerm={searchTerm}
      setSearchTerm={setSearchTerm}
      searchFieldError={searchFieldError}
      setSearchFieldError={setSearchFieldError}
      autocompleteResults={autocompleteResults}
      showAutocomplete={showAutocomplete}
      setShowAutocomplete={setShowAutocomplete}
      isSearching={isSearching}
      isCreatingWithAI={isCreatingWithAI}
      autocompleteError={autocompleteError}
      aiAssistEnabled={aiAssistEnabled}
      recognition={recognition}
      isRecording={isRecording}
      searchResults={searchResults}
      categoryTree={categoryTree}
      selectedLearnings={selectedLearnings}
      expandedCategories={expandedCategories}
      showSuggestionModal={showSuggestionModal}
      categorySuggestion={categorySuggestion}
      isSuggesting={isSuggesting}
      suggestionError={suggestionError}
      isSaving={isSaving}
      handleSearch={handleSearch}
      handleSelectAutocomplete={handleSelectAutocomplete}
      handleSuggestCategory={handleSuggestCategory}
      handleCreateWithAI={handleCreateWithAI}
      startRecording={startRecording}
      stopRecording={stopRecording}
      toggleCategory={toggleCategory}
      isLearningSelected={isLearningSelected}
      addLearning={addLearning}
      removeLearning={removeLearning}
      updateLearning={updateLearning}
      handleSave={handleSave}
      renderCategoryTree={renderCategoryTree}
      setShowSuggestionModal={setShowSuggestionModal}
      setCategorySuggestion={setCategorySuggestion}
    />
  );
}


