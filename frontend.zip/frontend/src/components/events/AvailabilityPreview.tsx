// src/components/events/AvailabilityPreview.tsx
// 🔴 CRÍTICO: Read-only, apenas exibe slots, nunca reserva
import { DateTime } from 'luxon';
import './AvailabilityPreview.css';

export interface AvailabilityPreviewProps {
  slots: Array<{
    start: string;
    end: string;
  }>;
  timezone: string;
}

export default function AvailabilityPreview({ slots, timezone }: AvailabilityPreviewProps) {
  const formatSlotTime = (isoString: string): string => {
    const dt = DateTime.fromISO(isoString).setZone(timezone);
    const now = DateTime.now().setZone(timezone);
    const today = now.startOf('day');
    const slotDay = dt.startOf('day');

    if (slotDay.equals(today)) {
      return `Hoje às ${dt.toFormat('HH:mm')}`;
    } else if (slotDay.equals(today.plus({ days: 1 }))) {
      return `Amanhã às ${dt.toFormat('HH:mm')}`;
    } else {
      return dt.toFormat("dd/MM 'às' HH:mm");
    }
  };

  if (slots.length === 0) {
    return null;
  }

  return (
    <div className="availability-preview">
      <div className="availability-preview-label">Próximos horários:</div>
      <div className="availability-preview-slots">
        {slots.map((slot, index) => (
          <div key={index} className="availability-preview-slot">
            🕗 {formatSlotTime(slot.start)}
          </div>
        ))}
      </div>
    </div>
  );
}




























