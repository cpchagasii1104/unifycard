// src/components/events/OrganizerEventMetrics.tsx
// Dashboard de métricas para organizadores (versão simplificada e amigável)
import { useState, useEffect } from 'react';
import { apiFetch } from '../../api/client';
import './OrganizerEventMetrics.css';

export interface OrganizerEventMetrics {
  eventId: string;
  eventTitle: string;
  eventState: 'PRE' | 'DURING' | 'POST';
  reach: {
    totalViews: number;
    viewsFromFeed: number;
    viewsFromPage: number;
    viewsDirect: number;
  };
  engagement: {
    totalCTAClicks: number;
    ctaClickRate: number;
  };
  conversion: {
    totalConversions: number;
    conversionRate: number;
  };
  performance: {
    bestCTAType?: 'ticket' | 'consumption' | 'parking';
    bestState?: 'PRE' | 'DURING' | 'POST';
    improvementTip?: string;
  };
}

interface OrganizerEventMetricsProps {
  eventId: string;
}

export default function OrganizerEventMetrics({ eventId }: OrganizerEventMetricsProps) {
  const [metrics, setMetrics] = useState<OrganizerEventMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadMetrics = async () => {
      try {
        setLoading(true);
        const response = await apiFetch(`/api/events/${eventId}/organizer-metrics`);
        
        if (response.status === 403) {
          setError('Você não tem permissão para ver métricas deste evento');
          return;
        }

        if (!response.ok) {
          throw new Error('Erro ao carregar métricas');
        }

        const data = await response.json();
        setMetrics(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro ao carregar métricas');
      } finally {
        setLoading(false);
      }
    };

    loadMetrics();
  }, [eventId]);

  if (loading) {
    return <div className="organizer-metrics-loading">Carregando métricas...</div>;
  }

  if (error || !metrics) {
    return <div className="organizer-metrics-error">{error || 'Métricas não encontradas'}</div>;
  }

  const { reach, engagement, conversion, performance } = metrics;

  return (
    <div className="organizer-metrics">
      <div className="organizer-metrics-header">
        <h2 className="organizer-metrics-title">📊 Métricas: {metrics.eventTitle}</h2>
        <div className={`organizer-metrics-state organizer-metrics-state-${metrics.eventState.toLowerCase()}`}>
          {metrics.eventState}
        </div>
      </div>

      {/* Alcance */}
      <div className="organizer-metrics-section">
        <h3 className="organizer-metrics-section-title">👁️ Alcance</h3>
        <div className="organizer-metrics-grid">
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Total de Visualizações</div>
            <div className="organizer-metrics-card-value">{reach.totalViews}</div>
          </div>
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Do Feed</div>
            <div className="organizer-metrics-card-value">{reach.viewsFromFeed}</div>
          </div>
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Da Página</div>
            <div className="organizer-metrics-card-value">{reach.viewsFromPage}</div>
          </div>
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Acesso Direto</div>
            <div className="organizer-metrics-card-value">{reach.viewsDirect}</div>
          </div>
        </div>
      </div>

      {/* Engajamento */}
      <div className="organizer-metrics-section">
        <h3 className="organizer-metrics-section-title">🎯 Engajamento</h3>
        <div className="organizer-metrics-grid">
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Cliques no CTA</div>
            <div className="organizer-metrics-card-value">{engagement.totalCTAClicks}</div>
          </div>
          <div className="organizer-metrics-card organizer-metrics-card-highlight">
            <div className="organizer-metrics-card-label">Taxa de Clique</div>
            <div className="organizer-metrics-card-value organizer-metrics-card-value-success">
              {engagement.ctaClickRate.toFixed(2)}%
            </div>
            <div className="organizer-metrics-card-hint">
              {engagement.ctaClickRate >= 10
                ? '✅ Excelente!'
                : engagement.ctaClickRate >= 5
                ? '⚠️ Pode melhorar'
                : '🔴 Precisa atenção'}
            </div>
          </div>
        </div>
      </div>

      {/* Conversão */}
      <div className="organizer-metrics-section">
        <h3 className="organizer-metrics-section-title">💰 Conversão</h3>
        <div className="organizer-metrics-grid">
          <div className="organizer-metrics-card">
            <div className="organizer-metrics-card-label">Total de Conversões</div>
            <div className="organizer-metrics-card-value organizer-metrics-card-value-success">
              {conversion.totalConversions}
            </div>
          </div>
          <div className="organizer-metrics-card organizer-metrics-card-highlight">
            <div className="organizer-metrics-card-label">Taxa de Conversão</div>
            <div className="organizer-metrics-card-value organizer-metrics-card-value-success">
              {conversion.conversionRate.toFixed(2)}%
            </div>
            <div className="organizer-metrics-card-hint">
              {conversion.conversionRate >= 30
                ? '🎉 Excepcional!'
                : conversion.conversionRate >= 15
                ? '✅ Boa'
                : conversion.conversionRate >= 5
                ? '⚠️ Média'
                : '🔴 Baixa'}
            </div>
          </div>
        </div>
      </div>

      {/* Insights de Performance */}
      {performance.bestCTAType || performance.bestState || performance.improvementTip ? (
        <div className="organizer-metrics-section organizer-metrics-section-insights">
          <h3 className="organizer-metrics-section-title">💡 Insights</h3>
          <div className="organizer-metrics-insights">
            {performance.bestCTAType && (
              <div className="organizer-metrics-insight">
                <strong>Melhor CTA:</strong> {performance.bestCTAType === 'ticket' ? 'Ingresso' : performance.bestCTAType === 'consumption' ? 'Consumo' : 'Estacionamento'}
              </div>
            )}
            {performance.bestState && (
              <div className="organizer-metrics-insight">
                <strong>Melhor momento:</strong> {performance.bestState === 'PRE' ? 'Antes do evento' : performance.bestState === 'DURING' ? 'Durante o evento' : 'Após o evento'}
              </div>
            )}
            {performance.improvementTip && (
              <div className="organizer-metrics-insight organizer-metrics-insight-tip">
                <strong>💡 Dica:</strong> {performance.improvementTip}
              </div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}


























