// src/components/CompanyValidationModal.tsx
// Modal para validação presencial com QR Code (FASE 12)

import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { requestCompanyValidation, type ValidationRequest } from '../api/companies';
import './CompanyValidationModal.css';

interface CompanyValidationModalProps {
  companyId: string;
  companyName: string;
  isOpen: boolean;
  onClose: () => void;
  onValidationRequested?: () => void;
}

export default function CompanyValidationModal({
  companyId,
  companyName,
  isOpen,
  onClose,
  onValidationRequested,
}: CompanyValidationModalProps) {
  const [validationRequest, setValidationRequest] = useState<ValidationRequest | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && !validationRequest) {
      loadValidationRequest();
    }
  }, [isOpen, companyId]);

  const loadValidationRequest = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const request = await requestCompanyValidation(companyId);
      setValidationRequest(request);
      if (onValidationRequested) {
        onValidationRequested();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao gerar QR Code de validação');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const expiresAt = validationRequest
    ? new Date(validationRequest.expires_at)
    : null;
  const isExpired = expiresAt ? expiresAt < new Date() : false;

  return (
    <div className="validation-modal-overlay" onClick={onClose}>
      <div className="validation-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="validation-modal-header">
          <h2>Validar Empresa Presencialmente</h2>
          <button className="validation-modal-close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="validation-modal-body">
          <div className="validation-info">
            <p>
              <strong>{companyName}</strong>
            </p>
            <p className="validation-instructions">
              Para validar sua empresa presencialmente:
            </p>
            <ol className="validation-steps">
              <li>Apresente este QR Code a um funcionário autorizado em uma loja parceira</li>
              <li>O funcionário escaneará o código e confirmará a validação</li>
              <li>Após a validação, sua empresa terá status VERIFIED</li>
            </ol>
          </div>

          {isLoading && (
            <div className="validation-loading">
              <p>Gerando QR Code...</p>
            </div>
          )}

          {error && (
            <div className="validation-error">
              <p>{error}</p>
              <button onClick={loadValidationRequest} className="retry-button">
                Tentar novamente
              </button>
            </div>
          )}

          {validationRequest && !isExpired && (
            <div className="validation-qr">
              <div className="qr-code-container">
                <QRCodeSVG
                  value={validationRequest.qr_code_payload}
                  size={256}
                  level="M"
                  includeMargin={true}
                />
              </div>
              <p className="qr-expires">
                Válido até: {expiresAt?.toLocaleString('pt-BR')}
              </p>
              <p className="qr-token">
                Token: <code>{validationRequest.qr_code_payload.substring(0, 20)}...</code>
              </p>
            </div>
          )}

          {validationRequest && isExpired && (
            <div className="validation-expired">
              <p>⚠️ Este QR Code expirou.</p>
              <button onClick={loadValidationRequest} className="retry-button">
                Gerar novo QR Code
              </button>
            </div>
          )}
        </div>

        <div className="validation-modal-footer">
          <button onClick={onClose} className="validation-modal-cancel">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}


























