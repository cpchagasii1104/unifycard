// src/components/MatchSection.tsx
// Seção de matching - agrupa sugestões

import { type MatchSuggestion as MatchSuggestionType } from '../api/matching';
import MatchSuggestion from './MatchSuggestion';
import './MatchSection.css';

interface MatchSectionProps {
  title: string;
  subtitle?: string;
  suggestions: MatchSuggestionType[];
  onSuggestionAccept?: (matchId: string) => void;
  onSuggestionDismiss?: (matchId: string) => void;
}

export default function MatchSection({ 
  title, 
  subtitle, 
  suggestions,
  onSuggestionAccept,
  onSuggestionDismiss,
}: MatchSectionProps) {
  if (suggestions.length === 0) {
    return null;
  }

  return (
    <div className="match-section">
      <div className="match-section-header">
        <h2 className="match-section-title">{title}</h2>
        {subtitle && (
          <p className="match-section-subtitle">{subtitle}</p>
        )}
        <p className="match-section-hint">
          Sugestões baseadas no seu momento atual. Você decide se quer conhecer ou não.
        </p>
      </div>
      <div className="match-section-suggestions">
        {suggestions.map((suggestion) => (
          <MatchSuggestion
            key={suggestion.id}
            suggestion={suggestion}
            onAccept={onSuggestionAccept}
            onDismiss={onSuggestionDismiss}
          />
        ))}
      </div>
    </div>
  );
}



























