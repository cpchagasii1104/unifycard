// src/components/home/ActivityBlock.tsx
// Bloco unificado de atividades: Continuar + Sugestões com tabs

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { MatchSuggestion } from '../../api/matching';
import type { ContinueItem } from '../../hooks/useHomeData';
import './ActivityBlock.css';

interface ActivityBlockProps {
  suggestions: MatchSuggestion[];
  continueItems: ContinueItem[];
}

export default function ActivityBlock({ suggestions, continueItems }: ActivityBlockProps) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'continue' | 'suggestions'>('continue');

  // Não renderizar se não houver dados em nenhuma tab
  if (continueItems.length === 0 && suggestions.length === 0) {
    return null;
  }

  const handleSuggestionClick = (suggestion: MatchSuggestion) => {
    if (suggestion.users && suggestion.users.length > 0) {
      navigate(`/profile/${suggestion.users[0].userId}`);
    } else {
      navigate('/social');
    }
  };

  const handleContinueClick = (path: string) => {
    navigate(path);
  };

  const getSuggestionDisplay = (suggestion: MatchSuggestion) => {
    const typeMap: Record<string, { icon: string; category: string }> = {
      exploration: { icon: '🔍', category: 'Exploração' },
      learning: { icon: '📚', category: 'Aprendizado' },
      mirroring: { icon: '🪞', category: 'Conexão' },
    };

    const display = typeMap[suggestion.type] || { icon: '💡', category: 'Sugestão' };
    
    return {
      icon: display.icon,
      category: display.category,
      title: suggestion.title || 'Nova conexão',
      description: suggestion.message || 'Descubra pessoas com interesses similares',
    };
  };

  return (
    <div className="activity-block">
      <div className="activity-tabs">
        <button
          className={`activity-tab ${activeTab === 'continue' ? 'active' : ''}`}
          onClick={() => setActiveTab('continue')}
          type="button"
        >
          Continuar
          {continueItems.length > 0 && (
            <span className="activity-tab-badge">{continueItems.length}</span>
          )}
        </button>
        <button
          className={`activity-tab ${activeTab === 'suggestions' ? 'active' : ''}`}
          onClick={() => setActiveTab('suggestions')}
          type="button"
        >
          Sugestões
          {suggestions.length > 0 && (
            <span className="activity-tab-badge">{suggestions.length}</span>
          )}
        </button>
      </div>

      <div className="activity-content">
        {activeTab === 'continue' && (
          <div className="activity-continue">
            {continueItems.length === 0 ? (
              <div className="activity-empty">
                <p>Nada para continuar no momento</p>
              </div>
            ) : (
              <div className="activity-continue-grid">
                {continueItems.map((item) => (
                  <div 
                    key={item.id} 
                    className="activity-continue-card"
                    onClick={() => handleContinueClick(item.path)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        handleContinueClick(item.path);
                      }
                    }}
                  >
                    <div className="activity-continue-header">
                      <div className="activity-continue-icon">{item.icon}</div>
                      <span className="activity-continue-status">{item.status}</span>
                    </div>
                    <h3 className="activity-continue-title">{item.title}</h3>
                    <p className="activity-continue-description">{item.description}</p>
                    <button 
                      className="activity-continue-button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleContinueClick(item.path);
                      }}
                    >
                      Continuar →
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'suggestions' && (
          <div className="activity-suggestions">
            {suggestions.length === 0 ? (
              <div className="activity-empty">
                <p>Nenhuma sugestão no momento</p>
              </div>
            ) : (
              <div className="activity-suggestions-grid">
                {suggestions.map((suggestion) => {
                  const display = getSuggestionDisplay(suggestion);
                  return (
                    <div 
                      key={suggestion.id} 
                      className="activity-suggestion-card"
                      onClick={() => handleSuggestionClick(suggestion)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          handleSuggestionClick(suggestion);
                        }
                      }}
                    >
                      <div className="activity-suggestion-icon">{display.icon}</div>
                      <div className="activity-suggestion-category">{display.category}</div>
                      <h3 className="activity-suggestion-title">{display.title}</h3>
                      <p className="activity-suggestion-description">{display.description}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}





















