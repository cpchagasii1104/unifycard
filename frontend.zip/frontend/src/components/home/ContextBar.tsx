// src/components/home/ContextBar.tsx
// Barra de contexto horizontal compacta no topo

import type { HomeContextData } from '../../hooks/useHomeData';
import './ContextBar.css';

interface ContextBarProps {
  context: HomeContextData;
}

export default function ContextBar({ context }: ContextBarProps) {
  const cityDisplay = context.isLoadingCity ? '...' : (context.city || 'Cidade não informada');

  return (
    <div className="context-bar">
      <div className="context-bar-content">
        <div className="context-bar-info">
          <span className="context-bar-actor">{context.actorName}</span>
          <span className="context-bar-separator">·</span>
          <span className="context-bar-type">{context.actorType}</span>
          <span className="context-bar-separator">·</span>
          <span className="context-bar-city">{cityDisplay}</span>
        </div>
        <button className="context-bar-switch" type="button" aria-label="Trocar contexto">
          <span className="context-bar-switch-icon">🔄</span>
          <span className="context-bar-switch-label">Trocar</span>
        </button>
      </div>
    </div>
  );
}





















