// src/components/ComboDiscountRulesManager.tsx
// Componente para gerenciar regras de desconto para combos (múltiplos serviços)

import type { ComboDiscountRule } from '../api/categories';
import { useComboDiscountRulesState } from '../hooks/useComboDiscountRulesState';
import { useComboDiscountRulesLogic } from '../hooks/useComboDiscountRulesLogic';
import ComboDiscountRulesManagerForm from './ComboDiscountRulesManagerForm';
import './ComboDiscountRulesManager.css';

interface ComboDiscountRulesManagerProps {
  rules: ComboDiscountRule[];
  onChange: (rules: ComboDiscountRule[]) => void;
  categoryName: string;
}

export default function ComboDiscountRulesManager({
  rules,
  onChange,
  categoryName: _categoryName,
}: ComboDiscountRulesManagerProps) {
  const { errors, setErrors } = useComboDiscountRulesState();
  const { validateRule } = useComboDiscountRulesLogic();

  const addRule = () => {
    const newRule: ComboDiscountRule = {
      ruleId: `rule-${Date.now()}`,
      minServices: 2,
      discountPercentage: 0,
      description: '',
      isActive: true,
    };
    onChange([...rules, newRule]);
  };

  const updateRule = (index: number, field: keyof ComboDiscountRule, value: any) => {
    const updated = [...rules];
    
    // CORREÇÃO CRÍTICA: Não sanitizar description durante digitação (remove espaços!)
    // Sanitização apenas no submit, não na digitação
    if (typeof value === 'string' && field === 'description') {
      // Apenas limitar tamanho, NÃO fazer trim durante digitação
      value = value.substring(0, 500);
    }
    
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);

    // Validação em tempo real
    const validation = validateRule(updated[index]);
    if (validation.valid) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[index];
        return newErrors;
      });
    } else {
      setErrors((prev) => ({ ...prev, [index]: validation.errors }));
    }
  };

  const removeRule = (index: number) => {
    const updated = rules.filter((_, i) => i !== index);
    onChange(updated);
  };

  return (
    <ComboDiscountRulesManagerForm
      rules={rules}
      errors={errors}
      addRule={addRule}
      removeRule={removeRule}
      updateRule={updateRule}
    />
  );
}










