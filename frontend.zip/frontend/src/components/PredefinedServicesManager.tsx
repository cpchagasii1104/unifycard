// src/components/PredefinedServicesManager.tsx
// Componente para gerenciar serviços pré-definidos com valores fixos

import type { PredefinedService } from '../api/categories';
import { sanitizeString } from '../utils/validation';
import { usePredefinedServicesState } from '../hooks/usePredefinedServicesState';
import { usePredefinedServicesLogic } from '../hooks/usePredefinedServicesLogic';
import PredefinedServicesManagerForm from './PredefinedServicesManagerForm';
import './PredefinedServicesManager.css';

interface PredefinedServicesManagerProps {
  services: PredefinedService[];
  onChange: (services: PredefinedService[]) => void;
  categoryName: string;
}

export default function PredefinedServicesManager({
  services,
  onChange,
  categoryName: _categoryName,
}: PredefinedServicesManagerProps) {
  const { editingIndex, setEditingIndex, errors, setErrors } = usePredefinedServicesState();
  const { validateService, calculateFinalPrice } = usePredefinedServicesLogic();

  const addService = () => {
    const newService: PredefinedService = {
      serviceId: `service-${Date.now()}`,
      name: '',
      description: '',
      basePrice: 0,
      discountPercentage: 0,
      finalPrice: 0,
      isActive: true,
    };
    onChange([...services, newService]);
    setEditingIndex(services.length);
  };

  const updateService = (index: number, field: keyof PredefinedService, value: any) => {
    const updated = [...services];
    
    // CORREÇÃO CRÍTICA: Não sanitizar description durante digitação (remove espaços!)
    // Sanitização apenas no submit, não na digitação
    if (typeof value === 'string') {
      if (field === 'description') {
        // Apenas limitar tamanho, NÃO fazer trim durante digitação
        value = value.substring(0, 500);
      } else if (field === 'name') {
        value = sanitizeString(value, 200);
      }
    }
    
    updated[index] = { ...updated[index], [field]: value };
    
    // Calcular preço final se basePrice ou discountPercentage mudou
    if (field === 'basePrice' || field === 'discountPercentage') {
      const basePrice = field === 'basePrice' ? value : updated[index].basePrice;
      const discount = field === 'discountPercentage' ? (value || 0) : (updated[index].discountPercentage || 0);
      updated[index].finalPrice = calculateFinalPrice(basePrice, discount);
    }
    
    onChange(updated);

    // Validação em tempo real
    const validation = validateService(updated[index]);
    if (validation.valid) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[index];
        return newErrors;
      });
    } else {
      setErrors((prev) => ({ ...prev, [index]: validation.errors }));
    }
  };

  const removeService = (index: number) => {
    const updated = services.filter((_, i) => i !== index);
    onChange(updated);
    if (editingIndex === index) {
      setEditingIndex(null);
    }
  };

  return (
    <PredefinedServicesManagerForm
      services={services}
      errors={errors}
      addService={addService}
      removeService={removeService}
      updateService={updateService}
    />
  );
}










