// src/components/layout/AdminLayout.tsx
// Layout Administrativo - PADRONIZADO COM MENU LATERAL COMPLETO
// Rotas: /dashboard, /alerts, /payouts, etc.
// 🔴 PADRONIZAÇÃO: Usa o mesmo menu lateral do SocialLayout para consistência

import { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { clearSession } from '../../config/auth';
import HeaderGlobal from './HeaderGlobal';
import { useActiveActor } from '../../contexts/ActiveActorContext';
import { getUnreadCounts, type UnreadCounts } from '../../api/unread';
import { getMyInvites } from '../../api/groups';
import { validateActiveActor, safeApiCall, safeNumber } from '../../utils/guardrails';
import { getAppsForContext, mapActorTypeToContext } from '../../config/appsRegistry';
import './AdminLayout.css';
import './SocialLayout.css'; // 🔴 PADRONIZAÇÃO: Usa os mesmos estilos do SocialLayout

export default function AdminLayout() {
  const navigate = useNavigate();
  const { activeActor, isLoading: actorsLoading } = useActiveActor();
  const [unreadCounts, setUnreadCounts] = useState<UnreadCounts>({
    feed: 0,
    groups: 0,
    events: 0,
    services: 0,
  });
  const [pendingInvitesCount, setPendingInvitesCount] = useState(0);

  const getNavLinkClassName = ({ isActive }: { isActive: boolean }) => {
    return `social-nav-link ${isActive ? 'active' : ''}`;
  };

  const handleBankNavigation = () => {
    navigate('/banco');
  };

  const handleLogout = () => {
    clearSession();
    navigate('/login');
  };

  // Obter apps disponíveis para o contexto atual
  const context = activeActor ? mapActorTypeToContext(activeActor.actor_type) : 'pf';
  const availableApps = getAppsForContext(context);
  
  // IDs de apps já renderizados manualmente no menu
  const manuallyRenderedAppIds = new Set([
    'social', // Feed
    'profile', // Meu Perfil
    'companies', // Minhas Empresas
    'bank', // UnifyBank
    'regional-fund', // Fundo Regional
    'events', // Eventos
    'services', // Serviços
    'votes', // Votações
    'config', // Configurações
  ]);

  // Filtrar apps que não estão no menu manual
  const additionalApps = availableApps.filter(app => !manuallyRenderedAppIds.has(app.id));

  // Agrupar apps por categoria
  const appsByCategory: Record<string, typeof availableApps> = {};
  additionalApps.forEach(app => {
    if (!appsByCategory[app.category]) {
      appsByCategory[app.category] = [];
    }
    appsByCategory[app.category].push(app);
  });

  const categoryLabels: Record<string, string> = {
    finance: '💰 FINANCEIRO',
    social: '📣 SOCIAL',
    core: '👤 CONTA',
    admin: '🔧 ADMINISTRATIVO',
  };

  // Carregar contadores não lidos
  useEffect(() => {
    if (!actorsLoading && activeActor) {
      loadUnreadCounts();
      loadPendingInvites();
    }
  }, [actorsLoading, activeActor]);

  const loadUnreadCounts = async () => {
    if (!activeActor) return;
    
    const validated = validateActiveActor(activeActor);
    if (!validated.valid) return;

    const result = await safeApiCall(() => getUnreadCounts(validated.actorId));
    if (result.success && result.data) {
      setUnreadCounts(result.data);
    }
  };

  const loadPendingInvites = async () => {
    if (!activeActor) return;
    
    const validated = validateActiveActor(activeActor);
    if (!validated.valid) return;

    const result = await safeApiCall(() => getMyInvites(validated.actorId, { status: 'pending' }));
    if (result.success && result.data) {
      const count = result.data.invites?.length || 0;
      setPendingInvitesCount(safeNumber(count, 0));
    }
  };

  return (
    <div className="social-layout">
      <HeaderGlobal />
      <div className="social-layout-content">
        <aside className="social-sidebar">
          <nav className="social-sidebar-nav">
            {/* Seção SOCIAL */}
            <div className="nav-section">
              <div className="nav-section-title">📣 SOCIAL</div>
              <NavLink 
                to="/social" 
                className={getNavLinkClassName}
              >
                📰 Feed
                {unreadCounts.feed > 0 && (
                  <span className="nav-badge">{unreadCounts.feed}</span>
                )}
              </NavLink>
              <NavLink 
                to="/grupos" 
                className={getNavLinkClassName}
              >
                👥 Grupos
                {unreadCounts.groups > 0 && (
                  <span className="nav-badge">{unreadCounts.groups}</span>
                )}
              </NavLink>
              <NavLink 
                to="/convites" 
                className={getNavLinkClassName}
              >
                📬 Convites
                {pendingInvitesCount > 0 && (
                  <span className="nav-badge">{pendingInvitesCount}</span>
                )}
              </NavLink>
              <NavLink 
                to="/eventos" 
                className={getNavLinkClassName}
              >
                🎭 Eventos
                {unreadCounts.events > 0 && (
                  <span className="nav-badge">{unreadCounts.events}</span>
                )}
              </NavLink>
              <NavLink 
                to="/servicos" 
                className={getNavLinkClassName}
              >
                🛠️ Serviços
                {unreadCounts.services > 0 && (
                  <span className="nav-badge">{unreadCounts.services}</span>
                )}
              </NavLink>
              <NavLink 
                to="/votacoes" 
                className={getNavLinkClassName}
              >
                🗳️ Votações
              </NavLink>
              <NavLink 
                to="/impacto" 
                className={getNavLinkClassName}
              >
                💚 Impacto
              </NavLink>
            </div>

            {/* Seção CONTA */}
            <div className="nav-section">
              <div className="nav-section-title">👤 CONTA</div>
              <NavLink 
                to="/perfil" 
                className={getNavLinkClassName}
              >
                👤 Meu Perfil
              </NavLink>
              <NavLink 
                to="/empresas" 
                className={getNavLinkClassName}
              >
                🏢 Minhas Empresas
              </NavLink>
              <NavLink 
                to="/dashboard" 
                className={getNavLinkClassName}
              >
                ⚙️ Configurações
              </NavLink>
              <NavLink 
                to="/ledger" 
                className={getNavLinkClassName}
              >
                📜 Ledger Social
              </NavLink>
            </div>

            {/* Seção ADMINISTRATIVO */}
            <div className="nav-section">
              <div className="nav-section-title">🔧 ADMINISTRATIVO</div>
              <NavLink 
                to="/grupos/novo" 
                className={getNavLinkClassName}
              >
                ➕ Criar Grupo
              </NavLink>
              {/* SPRINT 13: Observação de Piloto (apenas se modo piloto ativo) */}
              {import.meta.env.VITE_PILOT_MODE === 'true' && (
                <NavLink 
                  to="/admin/pilot" 
                  className={getNavLinkClassName}
                >
                  👁️ Observação Piloto
                </NavLink>
              )}
            </div>

            {/* Seção FINANCEIRO */}
            <div className="nav-section">
              <div className="nav-section-title">💰 FINANCEIRO</div>
              <button
                onClick={handleBankNavigation}
                className="social-nav-link social-nav-button"
              >
                🏦 UnifyBank
              </button>
              <button
                onClick={() => navigate('/extrato')}
                className="social-nav-link social-nav-button"
              >
                📄 Extrato
              </button>
              <button
                onClick={() => navigate('/fundo-regional')}
                className="social-nav-link social-nav-button"
              >
                🌱 Fundo Regional
              </button>
            </div>

            {/* Renderizar apps adicionais por categoria */}
            {Object.entries(appsByCategory).map(([category, apps]) => {
              // Pular categorias já renderizadas manualmente
              if (category === 'social' || category === 'core' || category === 'finance' || category === 'admin') {
                return null;
              }

              return (
                <div key={category} className="nav-section">
                  <div className="nav-section-title">{categoryLabels[category] || category.toUpperCase()}</div>
                  {apps.map((app) => {
                    if (app.status === 'wip') {
                      return (
                        <button
                          key={app.id}
                          onClick={() => navigate(`/em-desenvolvimento?feature=${app.id}`)}
                          className="social-nav-link social-nav-button"
                        >
                          {app.icon} {app.name}
                        </button>
                      );
                    }
                    return (
                      <button
                        key={app.id}
                        onClick={() => navigate(app.path)}
                        className="social-nav-link social-nav-button"
                      >
                        {app.icon} {app.name}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </nav>
        </aside>
        <main className="social-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

