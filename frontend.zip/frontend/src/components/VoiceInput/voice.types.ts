// src/components/VoiceInput/voice.types.ts

export interface VoiceRecorderState {
  isRecording: boolean;
  isProcessing: boolean;
  error: string | null;
  audioBlob: Blob | null;
}

export interface VoiceResponse {
  ok: boolean;
  data?: {
    text: string;
    transcription: string;
    conversation: any;
    lastMessage: any;
    channel: 'voice';
    timestamp: string;
  };
  error?: string;
  code?: string;
}




























