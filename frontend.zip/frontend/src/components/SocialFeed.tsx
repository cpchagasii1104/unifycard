// src/components/SocialFeed.tsx
// Feed de rede social com integração de serviços (agendar e pagar)
// Integrado com Feed Plugin System

import { useState, useEffect } from 'react';
import { getSocialFeed, createSocialPost, type PostCardData, type CreatePostPayload } from '../api/social';
import { useActiveActor } from '../contexts/ActiveActorContext';
import ServicePostCard from './ServicePostCard';
import FeedEventItem from './feed/FeedEventItem';
import FeedServiceItem from './feed/FeedServiceItem';
import { renderPost, renderBatch, type FeedItemDTO } from '../api/feedPlugins';
import './SocialFeed.css';

export default function SocialFeed() {
  const { activeActor, isLoading: actorsLoading } = useActiveActor();
  const [posts, setPosts] = useState<PostCardData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newPostContent, setNewPostContent] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  // Cache de DTOs renderizados pelos plugins
  const [pluginDTOs, setPluginDTOs] = useState<Record<string, FeedItemDTO | null>>({});
  const [loadingPlugins, setLoadingPlugins] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (activeActor && !actorsLoading) {
      loadFeed();
    }
  }, [activeActor?.actor_id, actorsLoading]);

  // Carregar DTOs dos plugins para posts que suportam (usando batch quando possível)
  useEffect(() => {
    const loadPluginDTOs = async () => {
      const postsToLoad = posts.filter(post => {
        const hasPluginIntent = post.intent === 'event' || post.intent === 'service_offer';
        const notLoaded = !pluginDTOs[post.post_id];
        const notLoading = !loadingPlugins.has(post.post_id);
        return hasPluginIntent && notLoaded && notLoading;
      });

      if (postsToLoad.length === 0) return;

      // Marcar todos como loading
      setLoadingPlugins(prev => {
        const next = new Set(prev);
        postsToLoad.forEach(post => next.add(post.post_id));
        return next;
      });

      try {
        // Usar batch quando houver múltiplos posts
        if (postsToLoad.length > 1) {
          const postIds = postsToLoad.map(post => post.post_id);
          const batchResults = await renderBatch(postIds);
          
          // Atualizar DTOs com resultados do batch
          setPluginDTOs(prev => {
            const updated = { ...prev };
            for (const [postId, result] of Object.entries(batchResults)) {
              updated[postId] = result.dto;
            }
            return updated;
          });
        } else {
          // Fallback para render individual se batch falhar ou houver apenas 1 post
          const post = postsToLoad[0];
          try {
            // Mapear intent legado para intent canônico
            let canonicalIntent = '';
            if (post.intent === 'event') {
              canonicalIntent = 'ANNOUNCE_EVENT';
            } else if (post.intent === 'service_offer') {
              canonicalIntent = 'OFFER_SERVICE';
            }
            
            if (canonicalIntent) {
              const dto = await renderPost(post.post_id, 'post', canonicalIntent);
              setPluginDTOs(prev => ({ ...prev, [post.post_id]: dto }));
            } else {
              setPluginDTOs(prev => ({ ...prev, [post.post_id]: null }));
            }
          } catch (error) {
            console.debug('Plugin não disponível para post:', post.post_id);
            setPluginDTOs(prev => ({ ...prev, [post.post_id]: null }));
          }
        }
      } catch (error) {
        // Se batch falhar, tentar render individual como fallback
        console.warn('Erro ao renderizar posts em batch, tentando individual:', error);
        for (const post of postsToLoad) {
          try {
            let canonicalIntent = '';
            if (post.intent === 'event') {
              canonicalIntent = 'ANNOUNCE_EVENT';
            } else if (post.intent === 'service_offer') {
              canonicalIntent = 'OFFER_SERVICE';
            }
            
            if (canonicalIntent) {
              const dto = await renderPost(post.post_id, 'post', canonicalIntent);
              setPluginDTOs(prev => ({ ...prev, [post.post_id]: dto }));
            } else {
              setPluginDTOs(prev => ({ ...prev, [post.post_id]: null }));
            }
          } catch (err) {
            console.debug('Plugin não disponível para post:', post.post_id);
            setPluginDTOs(prev => ({ ...prev, [post.post_id]: null }));
          }
        }
      } finally {
        // Remover todos do loading
        setLoadingPlugins(prev => {
          const next = new Set(prev);
          postsToLoad.forEach(post => next.delete(post.post_id));
          return next;
        });
      }
    };

    if (posts.length > 0) {
      loadPluginDTOs();
    }
  }, [posts, pluginDTOs, loadingPlugins]);

  const loadFeed = async () => {
    if (!activeActor) {
      setIsLoading(false);
      setError('Você precisa estar logado para ver o feed.');
      return;
    }

    // 🔴 HARDENING: Mensagem de erro clara para usuário
    setIsLoading(true);
    setError(null);
    try {
      const result = await getSocialFeed({ 
        limit: 20,
        actor_type: activeActor.actor_type as 'user' | 'page',
        actor_id: activeActor.actor_id,
        actor_status: activeActor.company_status,
      });
      setPosts(result.posts);
    } catch (err) {
      // 🔴 HARDENING: Mensagem de erro clara e humanizada
      setError('Não foi possível carregar o feed agora. Por favor, tente novamente em alguns instantes.');
      console.error('Erro ao carregar feed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    setIsCreating(true);
    try {
      const input: CreatePostPayload = {
        content: newPostContent.trim(),
      };
      const newPost = await createSocialPost(input);
      setPosts([newPost, ...posts]);
      setNewPostContent('');
    } catch (err) {
      // 🔴 HARDENING: Mensagem de erro clara e humanizada
      setError('Não foi possível criar o post agora. Por favor, tente novamente.');
      console.error('Erro ao criar post:', err);
    } finally {
      setIsCreating(false);
    }
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (isLoading) {
    return (
      <div className="social-feed">
        <div className="loading">Carregando feed...</div>
      </div>
    );
  }

  if (error && posts.length === 0) {
    return (
      <div className="social-feed">
        <div className="error">Erro: {error}</div>
        <button onClick={loadFeed} className="retry-button">
          Tentar novamente
        </button>
      </div>
    );
  }

  return (
    <div className="social-feed">
      <header className="feed-header">
        <h1>Rede Social</h1>
      </header>

      <main className="feed-main">
        {/* Formulário de novo post */}
        <section className="create-post-section">
          <form onSubmit={handleCreatePost} className="create-post-form">
            <textarea
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="O que você está pensando?"
              className="post-input"
              rows={3}
              disabled={isCreating}
            />
            <button
              type="submit"
              disabled={isCreating || !newPostContent.trim()}
              className="create-post-button"
            >
              {isCreating ? 'Publicando...' : 'Publicar'}
            </button>
          </form>
        </section>

        {/* Feed de posts */}
        <section className="posts-section">
          {posts.length === 0 ? (
            <div className="no-posts">
              <p>Nenhum post ainda. Seja o primeiro a publicar!</p>
            </div>
          ) : (
            <div className="posts-list">
              {posts.map((post) => {
                const pluginDTO = pluginDTOs[post.post_id];
                const isLoadingPlugin = loadingPlugins.has(post.post_id);
                
                // Renderizar via plugin se disponível
                if (pluginDTO && !isLoadingPlugin) {
                  return (
                    <article key={post.post_id} className="post-card">
                      <div className="post-header">
                        <div className="post-author">
                          <span className="author-id">{post.actor?.display_name || `Usuário ${post.post_id.substring(0, 8)}`}</span>
                        </div>
                        <time className="post-date">{formatDate(post.created_at)}</time>
                      </div>
                      <div className="post-content">{post.content}</div>
                      
                      {/* Renderizar via plugin baseado no tipo */}
                      {pluginDTO.type === 'event' && (
                        <FeedEventItem dto={pluginDTO} postId={post.post_id} />
                      )}
                      {pluginDTO.type === 'service' && (
                        <FeedServiceItem 
                          dto={pluginDTO} 
                          postId={post.post_id}
                          onBookClick={() => {
                            // Abrir fluxo de booking existente
                            // Por enquanto, apenas logar - pode ser integrado com modal/rota existente
                            console.log('Abrir booking para serviço:', pluginDTO.metadata?.serviceId);
                          }}
                        />
                      )}
                    </article>
                  );
                }
                
                // Renderização padrão (fallback ou enquanto carrega plugin)
                return (
                  <article key={post.post_id} className="post-card">
                    <div className="post-header">
                      <div className="post-author">
                        <span className="author-id">{post.actor?.display_name || `Usuário ${post.post_id.substring(0, 8)}`}</span>
                      </div>
                      <time className="post-date">{formatDate(post.created_at)}</time>
                    </div>
                    <div className="post-content">{post.content}</div>
                    
                    {/* Exibir informações de serviço se for post de serviço (renderização legada) */}
                    {post.intent === 'service_offer' && post.cta && !pluginDTO && !isLoadingPlugin && (
                      <ServicePostCard
                        post={post}
                        onScheduleSuccess={loadFeed}
                        onPaymentSuccess={loadFeed}
                      />
                    )}
                    
                    {/* Loading do plugin */}
                    {isLoadingPlugin && (
                      <div className="plugin-loading">Carregando informações...</div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

