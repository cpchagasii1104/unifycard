// src/components/ProfilePhysical.tsx
// Componente de perfil físico - autoexpressão declarativa
// 🔒 CONTRATO: Físico é um mapa declarativo de interesses, hábitos e práticas de vida.
// É autoexpressão voluntária, mutável e contextual.
// Físico NÃO é: profissão, saúde clínica, personalidade, score, identidade fixa, classificação humana.
// Preferências declaradas NÃO decidem nada no sistema.

import { useEffect } from 'react';
import {
  getPhysicalProfile,
  updatePhysicalProfile,
  type LifestyleInfo,
} from '../api/physical';
import { useProfilePhysicalState } from '../hooks/useProfilePhysicalState';
import { useProfilePhysicalLogic } from '../hooks/useProfilePhysicalLogic';
import ProfilePhysicalForm from './ProfilePhysicalForm';
import './ProfilePhysical.css';

// ============================================================
// CAMADA 1 — DOMÍNIOS DE VIDA (UI/UX apenas)
// ============================================================
// Domínios existem SOMENTE para organizar o formulário e navegação visual.
// NÃO são salvos como identidade e NÃO são usados como filtros sistêmicos.

type LifeDomain = 
  | 'atividades_e_praticas'
  | 'lazer_e_entretenimento'
  | 'leitura_e_conteudo'
  | 'musica_e_cultura'
  | 'gastronomia_e_consumo'
  | 'habitos_e_rotinas'
  | 'experiencias_viagens_e_eventos';

interface LifeDomainConfig {
  id: LifeDomain;
  label: string;
  icon?: string;
}

const LIFE_DOMAINS: LifeDomainConfig[] = [
  { id: 'atividades_e_praticas', label: 'Atividades e Práticas' },
  { id: 'lazer_e_entretenimento', label: 'Lazer e Entretenimento' },
  { id: 'leitura_e_conteudo', label: 'Leitura e Conteúdo' },
  { id: 'musica_e_cultura', label: 'Música e Cultura' },
  { id: 'gastronomia_e_consumo', label: 'Gastronomia e Consumo' },
  { id: 'habitos_e_rotinas', label: 'Hábitos e Rotinas' },
  { id: 'experiencias_viagens_e_eventos', label: 'Experiências, Viagens e Eventos' },
];

// ============================================================
// CAMADA 2 — CONCEPT IDs (interno, invisível ao usuário)
// ============================================================
// Cada item selecionável mapeia para um Concept ID canônico.
// NÃO usar texto livre como chave lógica.
// O usuário NUNCA vê o concept_id.

type ConceptId = string; // Ex: 'activity.swimming', 'leisure.videogames', 'music.rock'

interface ConceptDefinition {
  conceptId: ConceptId;
  label: string; // Nome exibido ao usuário
  domain: LifeDomain;
}

// Conceitos pré-definidos por domínio (exemplos)
const PREDEFINED_CONCEPTS: ConceptDefinition[] = [
  // Atividades e Práticas
  { conceptId: 'activity.swimming', label: 'Natação', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.running', label: 'Corrida', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.yoga', label: 'Yoga', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.cycling', label: 'Ciclismo', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.gym', label: 'Academia', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.dancing', label: 'Dança', domain: 'atividades_e_praticas' },
  { conceptId: 'activity.martial_arts', label: 'Artes Marciais', domain: 'atividades_e_praticas' },
  
  // Lazer e Entretenimento
  { conceptId: 'leisure.videogames', label: 'Videogames', domain: 'lazer_e_entretenimento' },
  { conceptId: 'leisure.board_games', label: 'Jogos de Tabuleiro', domain: 'lazer_e_entretenimento' },
  { conceptId: 'leisure.cinema', label: 'Cinema', domain: 'lazer_e_entretenimento' },
  { conceptId: 'leisure.theater', label: 'Teatro', domain: 'lazer_e_entretenimento' },
  { conceptId: 'leisure.karting', label: 'Karting', domain: 'lazer_e_entretenimento' },
  { conceptId: 'leisure.bowling', label: 'Boliche', domain: 'lazer_e_entretenimento' },
  
  // Leitura e Conteúdo
  { conceptId: 'content.reading', label: 'Leitura', domain: 'leitura_e_conteudo' },
  { conceptId: 'content.podcasts', label: 'Podcasts', domain: 'leitura_e_conteudo' },
  { conceptId: 'content.documentaries', label: 'Documentários', domain: 'leitura_e_conteudo' },
  { conceptId: 'content.writing', label: 'Escrita', domain: 'leitura_e_conteudo' },
  { conceptId: 'content.photography', label: 'Fotografia', domain: 'leitura_e_conteudo' },
  
  // Música e Cultura
  { conceptId: 'music.rock', label: 'Rock', domain: 'musica_e_cultura' },
  { conceptId: 'music.pop', label: 'Pop', domain: 'musica_e_cultura' },
  { conceptId: 'music.samba', label: 'Samba', domain: 'musica_e_cultura' },
  { conceptId: 'music.jazz', label: 'Jazz', domain: 'musica_e_cultura' },
  { conceptId: 'music.classical', label: 'Música Clássica', domain: 'musica_e_cultura' },
  { conceptId: 'music.electronic', label: 'Eletrônica', domain: 'musica_e_cultura' },
  { conceptId: 'culture.museums', label: 'Museus', domain: 'musica_e_cultura' },
  { conceptId: 'culture.art_galleries', label: 'Galerias de Arte', domain: 'musica_e_cultura' },
  
  // Gastronomia e Consumo
  { conceptId: 'food.cooking', label: 'Culinária', domain: 'gastronomia_e_consumo' },
  { conceptId: 'food.restaurants', label: 'Restaurantes', domain: 'gastronomia_e_consumo' },
  { conceptId: 'food.wine', label: 'Vinhos', domain: 'gastronomia_e_consumo' },
  { conceptId: 'food.craft_beer', label: 'Cerveja Artesanal', domain: 'gastronomia_e_consumo' },
  { conceptId: 'food.coffee', label: 'Café', domain: 'gastronomia_e_consumo' },
  
  // Hábitos e Rotinas
  { conceptId: 'habit.meditation', label: 'Meditação', domain: 'habitos_e_rotinas' },
  { conceptId: 'habit.morning_routine', label: 'Rotina Matinal', domain: 'habitos_e_rotinas' },
  { conceptId: 'habit.night_owl', label: 'Coruja Noturna', domain: 'habitos_e_rotinas' },
  { conceptId: 'habit.early_bird', label: 'Madrugador', domain: 'habitos_e_rotinas' },
  
  // Experiências, Viagens e Eventos
  { conceptId: 'experience.travel', label: 'Viagens', domain: 'experiencias_viagens_e_eventos' },
  { conceptId: 'experience.adventure', label: 'Aventura', domain: 'experiencias_viagens_e_eventos' },
  { conceptId: 'experience.festivals', label: 'Festivais', domain: 'experiencias_viagens_e_eventos' },
  { conceptId: 'experience.concerts', label: 'Shows', domain: 'experiencias_viagens_e_eventos' },
  { conceptId: 'experience.sports_events', label: 'Eventos Esportivos', domain: 'experiencias_viagens_e_eventos' },
];

// ============================================================
// CAMADA 3 — DECLARAÇÃO DO USUÁRIO
// ============================================================
// O usuário pode selecionar interesses e marcar estados simples.

type InterestState = 'gosto' | 'pratico_as_vezes' | 'pratico_regularmente';

interface UserInterest {
  conceptId: ConceptId;
  label: string; // Nome exibido (pode ser do conceito pré-definido ou texto livre mapeado)
  state: InterestState;
  domain: LifeDomain; // Apenas para organização visual
  isCustom: boolean; // true se foi digitado pelo usuário (não pré-definido)
}

interface PhysicalProfileData {
  interests: UserInterest[];
  habits: {
    smoking: 'não_fumo' | 'ocasionalmente' | 'regularmente' | null;
    drinking: 'não_bebo' | 'socialmente' | 'regularmente' | null;
  };
  weeklyRoutine: 'leve' | 'moderada' | 'intensa' | null;
  goals: ('estética' | 'bem_estar' | 'condicionamento')[];
}

export default function ProfilePhysical() {
  const {
    activeDomain,
    setActiveDomain,
    profileData,
    setProfileData,
    lifestyle,
    setLifestyle,
    customInterestInput,
    setCustomInterestInput,
    isLoading,
    setIsLoading,
    isSaving,
    setIsSaving,
    error,
    setError,
  } = useProfilePhysicalState();
  const { generateCustomConceptId, getInterestsByDomain, getConceptsByDomain, isConceptSelected, PREDEFINED_CONCEPTS } = useProfilePhysicalLogic();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const profile = await getPhysicalProfile().catch(() => ({
        globalUserId: '',
        interests: [],
        lifestyle: {
          drinks: null,
          smokes: null,
          relationshipStatus: null,
          sexualOrientation: null,
        },
        preferences: {},
        metadata: {},
      }));

      setLifestyle(profile.lifestyle);

      // 🔒 Carregar dados do perfil físico de metadata (se existir)
      const physicalData = (profile.metadata && typeof profile.metadata === 'object' && 'physicalProfile' in profile.metadata)
        ? (profile.metadata.physicalProfile as Partial<PhysicalProfileData>)
        : undefined;
      
      if (physicalData) {
        setProfileData({
          interests: physicalData.interests || [],
          habits: physicalData.habits || {
            smoking: null,
            drinking: null,
          },
          weeklyRoutine: physicalData.weeklyRoutine || null,
          goals: physicalData.goals || [],
        });
      } else {
        // Migrar dados antigos se necessário
        setProfileData({
          interests: [],
          habits: {
            smoking: profile.lifestyle.smokes === 'never' ? 'não_fumo' : 
                     profile.lifestyle.smokes === 'occasionally' ? 'ocasionalmente' :
                     profile.lifestyle.smokes === 'regularly' ? 'regularmente' : null,
            drinking: profile.lifestyle.drinks === 'never' ? 'não_bebo' :
                      profile.lifestyle.drinks === 'socially' ? 'socialmente' :
                      profile.lifestyle.drinks === 'regularly' ? 'regularmente' : null,
          },
          weeklyRoutine: null,
          goals: [],
        });
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao carregar dados';
      setError(errorMessage);
      console.error('Erro completo:', err);
    } finally {
      setIsLoading(false);
    }
  };


  // Adicionar interesse pré-definido
  const addPredefinedInterest = (concept: ConceptDefinition, state: InterestState) => {
    const existing = profileData.interests.find(i => i.conceptId === concept.conceptId);
    if (existing) {
      // Atualizar estado se já existe
      updateInterestState(concept.conceptId, state);
      return;
    }

    const newInterest: UserInterest = {
      conceptId: concept.conceptId,
      label: concept.label,
      state,
      domain: concept.domain,
      isCustom: false,
    };

    setProfileData({
      ...profileData,
      interests: [...profileData.interests, newInterest],
    });
  };

  // Adicionar interesse customizado (texto livre)
  const addCustomInterest = (domain: LifeDomain, state: InterestState) => {
    const label = customInterestInput[domain].trim();
    if (!label) return;

    const conceptId = generateCustomConceptId(label, domain);
    
    // Verificar se já existe (mesmo conceptId ou mesmo label no mesmo domínio)
    const existing = profileData.interests.find(
      i => i.conceptId === conceptId || (i.label.toLowerCase() === label.toLowerCase() && i.domain === domain)
    );
    
    if (existing) {
      updateInterestState(existing.conceptId, state);
      setCustomInterestInput({ ...customInterestInput, [domain]: '' });
      return;
    }

    const newInterest: UserInterest = {
      conceptId,
      label,
      state,
      domain,
      isCustom: true,
    };

    setProfileData({
      ...profileData,
      interests: [...profileData.interests, newInterest],
    });

    setCustomInterestInput({ ...customInterestInput, [domain]: '' });
  };

  // Atualizar estado de um interesse
  const updateInterestState = (conceptId: ConceptId, state: InterestState) => {
    setProfileData({
      ...profileData,
      interests: profileData.interests.map(i =>
        i.conceptId === conceptId ? { ...i, state } : i
      ),
    });
  };

  // Remover interesse
  const removeInterest = (conceptId: ConceptId) => {
    setProfileData({
      ...profileData,
      interests: profileData.interests.filter(i => i.conceptId !== conceptId),
    });
  };

  const getInterestsByDomainWrapper = (domain: LifeDomain): UserInterest[] => {
    return getInterestsByDomain(domain, profileData.interests);
  };

  const getConceptsByDomainWrapper = (domain: LifeDomain): ConceptDefinition[] => {
    return getConceptsByDomain(domain);
  };

  const isConceptSelectedWrapper = (conceptId: ConceptId): boolean => {
    return isConceptSelected(conceptId, profileData.interests);
  };

  const updateHabits = (field: 'smoking' | 'drinking', value: PhysicalProfileData['habits']['smoking'] | PhysicalProfileData['habits']['drinking']) => {
    setProfileData({
      ...profileData,
      habits: {
        ...profileData.habits,
        [field]: value,
      },
    });
  };

  const updateWeeklyRoutine = (routine: PhysicalProfileData['weeklyRoutine']) => {
    setProfileData({
      ...profileData,
      weeklyRoutine: routine,
    });
  };

  const toggleGoal = (goal: 'estética' | 'bem_estar' | 'condicionamento') => {
    const currentGoals = profileData.goals;
    const isSelected = currentGoals.includes(goal);
    
    setProfileData({
      ...profileData,
      goals: isSelected
        ? currentGoals.filter(g => g !== goal)
        : [...currentGoals, goal],
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError(null);

    try {
      // 🔒 Salvar dados declarativos em metadata (temporário até API ser atualizada)
      await updatePhysicalProfile({
        interests: [], // Não usar categorias
        lifestyle: {
          ...lifestyle,
          smokes: profileData.habits.smoking === 'não_fumo' ? 'never' :
                 profileData.habits.smoking === 'ocasionalmente' ? 'occasionally' :
                 (profileData.habits.smoking === 'regularmente' ? 'regularly' : null),
          drinks: profileData.habits.drinking === 'não_bebo' ? 'never' :
                 profileData.habits.drinking === 'socialmente' ? 'socially' :
                 (profileData.habits.drinking === 'regularmente' ? 'regularly' : null),
        },
        preferences: {},
        metadata: {
          physicalProfile: profileData, // 🔒 Dados declarativos completos
        },
      });

      alert('Interesses e gostos atualizados com sucesso!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao salvar perfil');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="profile-physical">
        <h2>Interesses e Gostos</h2>
        <div className="loading">Carregando interesses e gostos...</div>
      </div>
    );
  }

  return (
    <ProfilePhysicalForm
      error={error}
      activeDomain={activeDomain}
      setActiveDomain={setActiveDomain}
      profileData={profileData}
      lifestyle={lifestyle}
      customInterestInput={customInterestInput}
      setCustomInterestInput={setCustomInterestInput}
      isSaving={isSaving}
      LIFE_DOMAINS={LIFE_DOMAINS}
      getInterestsByDomain={getInterestsByDomainWrapper}
      getConceptsByDomain={getConceptsByDomainWrapper}
      isConceptSelected={isConceptSelectedWrapper}
      updateInterestState={updateInterestState}
      removeInterest={removeInterest}
      addPredefinedInterest={addPredefinedInterest}
      addCustomInterest={addCustomInterest}
      updateHabits={updateHabits}
      updateWeeklyRoutine={updateWeeklyRoutine}
      toggleGoal={toggleGoal}
      setLifestyle={setLifestyle}
      handleSave={handleSave}
    />
  );
}
