// frontend/src/components/mfibank/MFIBankRecentTransactions.tsx
// Últimas Transações da Conta MFIBank

import { useState, useEffect } from 'react';
import { getUserStatement, type StatementEntry } from '../../api/transparency';
import './MFIBankRecentTransactions.css';

interface MFIBankRecentTransactionsProps {
  onTransactionClick?: (transactionId: string) => void;
}

export default function MFIBankRecentTransactions({ onTransactionClick }: MFIBankRecentTransactionsProps) {
  const [transactions, setTransactions] = useState<StatementEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadRecentTransactions();
  }, []);

  const loadRecentTransactions = async () => {
    setLoading(true);
    setError(null);

    try {
      const result = await getUserStatement({ limit: 5 });
      setTransactions(result.entries);
    } catch (err: any) {
      console.error('Erro ao carregar transações recentes:', err);
      const errorMessage = err.message || 'Erro ao carregar transações';
      
      // Mensagens mais amigáveis
      if (errorMessage.includes('404') || errorMessage.includes('not found')) {
        setError('Conta não encontrada. Tente fazer login novamente.');
      } else if (errorMessage.includes('401') || errorMessage.includes('authentication')) {
        setError('Sessão expirada. Por favor, faça login novamente.');
      } else if (errorMessage.includes('timeout') || errorMessage.includes('Timeout')) {
        setError('Tempo de resposta excedido. Verifique sua conexão e tente novamente.');
      } else if (errorMessage.includes('fetch') || errorMessage.includes('conectar')) {
        setError('Não foi possível conectar ao servidor. Verifique se o backend está rodando.');
      } else {
        setError(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  const getTypeLabel = (type: StatementEntry['type']): string => {
    const labels: Record<StatementEntry['type'], string> = {
      p2p: 'P2P',
      donation: 'Doação',
      split: 'Split',
      compensation: 'Compensação',
      governance: 'Governança',
      other: 'Outro',
    };
    return labels[type] || 'Desconhecido';
  };

  if (loading) {
    return (
      <div className="mfibank-recent-transactions">
        <div className="mfibank-recent-loading">Carregando transações...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mfibank-recent-transactions">
        <div className="mfibank-recent-error">
          <p>Erro ao carregar transações</p>
          <button onClick={loadRecentTransactions}>Tentar novamente</button>
        </div>
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="mfibank-recent-transactions">
        <h3>Últimas Transações</h3>
        <div className="mfibank-recent-empty">
          <p>Nenhuma transação encontrada</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mfibank-recent-transactions">
      <h3>Últimas Transações</h3>
      <div className="mfibank-recent-list">
        {transactions.map((entry) => (
          <div
            key={entry.transactionId}
            className={`mfibank-recent-item ${entry.direction}`}
            onClick={() => onTransactionClick?.(entry.transactionId)}
          >
            <div className="mfibank-recent-item-left">
              <div className="mfibank-recent-type">
                {getTypeLabel(entry.type)}
                {entry.metadata.splitGroupId && (
                  <span className="mfibank-recent-split-badge">Split</span>
                )}
              </div>
              <div className="mfibank-recent-date">{formatDate(entry.createdAt)}</div>
            </div>
            <div className="mfibank-recent-item-right">
              <div className={`mfibank-recent-amount ${entry.direction}`}>
                {entry.direction === 'in' ? '+' : '-'}
                {formatCurrency(Math.abs(entry.amount))}
              </div>
              {onTransactionClick && (
                <button className="mfibank-recent-details-button">
                  Detalhes
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}





























