// src/components/ContextualSuggestion.tsx
// Camada de sugestões contextuais - silenciosa, opcional, respeitosa

import { useState, useEffect } from 'react';
import { getInferences, recordSuggestionAction, type InferenceSuggestion } from '../api/inference';
import { normalizeCategoryLabel } from '../utils/categoryLabelNormalizer';
import './ContextualSuggestion.css';

interface ContextualSuggestionProps {
  onSuggestionAccepted?: () => void;
  onSuggestionDismissed?: () => void;
  onNavigate?: (tab: 'professional' | 'physical' | 'learning') => void;
}

export default function ContextualSuggestion({ 
  onSuggestionAccepted,
  onSuggestionDismissed,
  onNavigate,
}: ContextualSuggestionProps) {
  const [suggestion, setSuggestion] = useState<InferenceSuggestion | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    loadSuggestion();
  }, []);

  const loadSuggestion = async () => {
    setIsLoading(true);
    try {
      const result = await getInferences();
      
      // Filtrar sugestões já dispensadas (do localStorage)
      const dismissed = getDismissedSuggestions();
      const available = result.suggestions.filter(s => !dismissed.has(s.id));
      
      // Selecionar apenas a primeira (prioritária)
      if (available.length > 0) {
        setSuggestion(available[0]);
      } else {
        setSuggestion(null);
      }
    } catch (error) {
      console.error('Erro ao carregar sugestão:', error);
      setSuggestion(null);
    } finally {
      setIsLoading(false);
    }
  };

  const getDismissedSuggestions = (): Set<string> => {
    try {
      const stored = localStorage.getItem('dismissed_suggestions');
      if (stored) {
        const ids = JSON.parse(stored) as string[];
        return new Set(ids);
      }
    } catch (error) {
      console.error('Erro ao ler sugestões dispensadas:', error);
    }
    return new Set();
  };

  const markAsDismissed = (suggestionId: string) => {
    try {
      const dismissed = getDismissedSuggestions();
      dismissed.add(suggestionId);
      localStorage.setItem('dismissed_suggestions', JSON.stringify(Array.from(dismissed)));
    } catch (error) {
      console.error('Erro ao salvar sugestão dispensada:', error);
    }
  };

  const handleAccept = async () => {
    if (!suggestion || isProcessing) return;

    setIsProcessing(true);
    try {
      // Registrar aceitação no backend
      await recordSuggestionAction({
        suggestionId: suggestion.id,
        action: 'accept',
      });

      // Executar ação sugerida
      if (onNavigate) {
        if (suggestion.type === 'physical_to_learning') {
          onNavigate('learning');
        } else if (suggestion.type === 'learning_to_professional') {
          onNavigate('professional');
        } else if (suggestion.type === 'professional_needs_physical') {
          onNavigate('physical');
        }
      }

      // Remover sugestão da UI
      setSuggestion(null);
      
      // Callback opcional
      onSuggestionAccepted?.();
    } catch (error) {
      console.error('Erro ao aceitar sugestão:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDismiss = async () => {
    if (!suggestion || isProcessing) return;

    setIsProcessing(true);
    try {
      // Registrar dismiss no backend
      await recordSuggestionAction({
        suggestionId: suggestion.id,
        action: 'dismiss',
      });

      // Marcar como dispensada localmente
      markAsDismissed(suggestion.id);

      // Remover sugestão da UI
      setSuggestion(null);
      
      // Callback opcional
      onSuggestionDismissed?.();
    } catch (error) {
      console.error('Erro ao dispensar sugestão:', error);
      // Mesmo com erro, remover da UI para não travar
      markAsDismissed(suggestion.id);
      setSuggestion(null);
    } finally {
      setIsProcessing(false);
    }
  };

  // Não renderizar se não houver sugestão ou estiver carregando
  if (isLoading || !suggestion) {
    return null;
  }

  // Renderizar copy humana baseada no tipo
  const getHumanCopy = (suggestion: InferenceSuggestion) => {
    switch (suggestion.type) {
      case 'physical_to_learning':
        return {
          message: `Percebi que você gosta de ${normalizeCategoryLabel(suggestion.categoryName) || 'isso'}. Quer aprender um pouco mais?`,
          actionLabel: 'Ver temas de aprendizado',
        };
      case 'learning_to_professional':
        return {
          message: `Você já está se aprofundando nisso. Já pensou em levar mais adiante?`,
          actionLabel: 'Ver profissões relacionadas',
        };
      case 'professional_needs_physical':
        return {
          message: `E fora do trabalho, o que te faz bem?`,
          actionLabel: 'Adicionar atividades de prazer',
        };
      case 'learning_stagnant':
        return {
          message: `Que tal retomar seus aprendizados?`,
          actionLabel: 'Ver meus aprendizados',
        };
      default:
        return {
          message: suggestion.message,
          actionLabel: suggestion.actionLabel || 'Ver mais',
        };
    }
  };

  const copy = getHumanCopy(suggestion);

  return (
    <div className="contextual-suggestion">
      <div className="suggestion-content">
        <p className="suggestion-message">{copy.message}</p>
        <div className="suggestion-actions">
          <button
            className="suggestion-button accept"
            onClick={handleAccept}
            disabled={isProcessing}
          >
            {isProcessing ? '...' : copy.actionLabel}
          </button>
          <button
            className="suggestion-button dismiss"
            onClick={handleDismiss}
            disabled={isProcessing}
            aria-label="Dispensar sugestão"
          >
            ✕
          </button>
        </div>
      </div>
    </div>
  );
}







