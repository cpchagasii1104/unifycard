// src/components/AvailabilitySchedule.tsx
// Componente para configurar agenda unificada

import { useState } from 'react';
import type { AvailabilitySchedule } from '../api/categories';
import './AvailabilitySchedule.css';

interface AvailabilityScheduleProps {
  availability: AvailabilitySchedule | null;
  onChange: (availability: AvailabilitySchedule) => void;
}

const DAYS_OF_WEEK = [
  { key: 'monday', label: 'Segunda-feira', short: 'Seg' },
  { key: 'tuesday', label: 'Terça-feira', short: 'Ter' },
  { key: 'wednesday', label: 'Quarta-feira', short: 'Qua' },
  { key: 'thursday', label: 'Quinta-feira', short: 'Qui' },
  { key: 'friday', label: 'Sexta-feira', short: 'Sex' },
  { key: 'saturday', label: 'Sábado', short: 'Sáb' },
  { key: 'sunday', label: 'Domingo', short: 'Dom' },
];

// const TIME_SLOTS = [
//   '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
//   '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
//   '18:00', '19:00', '20:00', '21:00', '22:00', '23:00',
// ];

export default function AvailabilityScheduleComponent({
  availability,
  onChange,
}: AvailabilityScheduleProps) {
  const [schedule, setSchedule] = useState<AvailabilitySchedule>(
    availability || {}
  );

  const updateSchedule = (newSchedule: AvailabilitySchedule) => {
    setSchedule(newSchedule);
    onChange(newSchedule);
  };

  const toggleDay = (dayKey: string) => {
    const newSchedule = { ...schedule };
    if (newSchedule[dayKey]) {
      delete newSchedule[dayKey];
    } else {
      // Padrão: 09:00-18:00
      newSchedule[dayKey] = ['09:00-18:00'];
    }
    updateSchedule(newSchedule);
  };

  const addTimeSlot = (dayKey: string) => {
    const newSchedule = { ...schedule };
    if (!newSchedule[dayKey]) {
      newSchedule[dayKey] = [];
    }
    // Adiciona novo slot padrão
    newSchedule[dayKey].push('09:00-18:00');
    updateSchedule(newSchedule);
  };

  const removeTimeSlot = (dayKey: string, index: number) => {
    const newSchedule = { ...schedule };
    if (newSchedule[dayKey]) {
      newSchedule[dayKey] = newSchedule[dayKey].filter((_, i) => i !== index);
      if (newSchedule[dayKey].length === 0) {
        delete newSchedule[dayKey];
      }
    }
    updateSchedule(newSchedule);
  };

  const updateTimeSlot = (dayKey: string, index: number, timeRange: string) => {
    const newSchedule = { ...schedule };
    if (newSchedule[dayKey]) {
      newSchedule[dayKey][index] = timeRange;
    }
    updateSchedule(newSchedule);
  };

  const parseTimeRange = (range: string): { start: string; end: string } => {
    const [start, end] = range.split('-');
    return { start: start || '09:00', end: end || '18:00' };
  };

  const formatTimeRange = (start: string, end: string): string => {
    return `${start}-${end}`;
  };

  const applyPreset = (preset: 'weekdays' | 'weekend' | 'all' | 'custom') => {
    const newSchedule: AvailabilitySchedule = {};

    if (preset === 'weekdays') {
      DAYS_OF_WEEK.slice(0, 5).forEach((day) => {
        newSchedule[day.key] = ['09:00-18:00'];
      });
    } else if (preset === 'weekend') {
      DAYS_OF_WEEK.slice(5).forEach((day) => {
        newSchedule[day.key] = ['09:00-18:00'];
      });
    } else if (preset === 'all') {
      DAYS_OF_WEEK.forEach((day) => {
        newSchedule[day.key] = ['09:00-18:00'];
      });
    }

    updateSchedule(newSchedule);
  };

  return (
    <div className="availability-schedule">
      <div className="schedule-header">
        <h3>Agenda Unificada</h3>
        <p className="schedule-description">
          Configure seus horários disponíveis.
          Esta é a agenda base do seu perfil como Pessoa Física e será usada para trabalho, convites, eventos, lazer, estudos e cuidados pessoais.
        </p>
      </div>

      <div className="preset-buttons">
        <button
          type="button"
          onClick={() => applyPreset('weekdays')}
          className="preset-button"
        >
          Segunda a Sexta
        </button>
        <button
          type="button"
          onClick={() => applyPreset('weekend')}
          className="preset-button"
        >
          Sábado e Domingo
        </button>
        <button
          type="button"
          onClick={() => applyPreset('all')}
          className="preset-button"
        >
          Todos os Dias
        </button>
        <button
          type="button"
          onClick={() => applyPreset('custom')}
          className="preset-button"
        >
          Limpar
        </button>
      </div>

      <div className="schedule-days">
        {DAYS_OF_WEEK.map((day) => {
          const isActive = !!schedule[day.key];
          const timeSlots = schedule[day.key] || [];

          return (
            <div key={day.key} className={`schedule-day ${isActive ? 'active' : ''}`}>
              <div className="day-header">
                <label className="day-toggle">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={() => toggleDay(day.key)}
                  />
                  <span className="day-label">{day.label}</span>
                </label>
                {isActive && (
                  <button
                    type="button"
                    onClick={() => addTimeSlot(day.key)}
                    className="add-slot-button"
                    title="Adicionar horário"
                  >
                    + Horário
                  </button>
                )}
              </div>

              {isActive && (
                <div className="time-slots">
                  {timeSlots.map((slot, index) => {
                    const { start, end } = parseTimeRange(slot);
                    return (
                      <div key={index} className="time-slot">
                        <input
                          type="time"
                          value={start}
                          onChange={(e) => {
                            const newRange = formatTimeRange(e.target.value, end);
                            updateTimeSlot(day.key, index, newRange);
                          }}
                          className="time-input"
                        />
                        <span className="time-separator">até</span>
                        <input
                          type="time"
                          value={end}
                          onChange={(e) => {
                            const newRange = formatTimeRange(start, e.target.value);
                            updateTimeSlot(day.key, index, newRange);
                          }}
                          className="time-input"
                        />
                        {timeSlots.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeTimeSlot(day.key, index)}
                            className="remove-slot-button"
                            title="Remover horário"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

