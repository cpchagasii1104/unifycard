// src/hooks/useActorContext.ts
// Hook para gerenciar contexto de ator (Actor) globalmente
// Persiste a escolha do ator durante a sessão

import { useState, useEffect, useCallback } from 'react';
import { getAvailableActors, type AvailableActor } from '../api/social';
import { useSession } from '../contexts/SessionProvider';

const ACTOR_CONTEXT_KEY = 'unificard_active_actor';

interface ActorContext {
  actorId: string | null;
  actorType: 'user' | 'page' | 'group' | 'channel' | null;
  actorData: AvailableActor | null;
}

/**
 * Hook para gerenciar o contexto de ator ativo
 * Persiste a escolha no localStorage e carrega automaticamente ao inicializar
 */
export function useActorContext() {
  const { sessionReady } = useSession();
  const [context, setContext] = useState<ActorContext>({
    actorId: null,
    actorType: null,
    actorData: null,
  });
  const [availableActors, setAvailableActors] = useState<AvailableActor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Carregar actors disponíveis e restaurar contexto salvo
  useEffect(() => {
    // GUARD: Não fazer chamadas de API antes de sessionReady
    if (!sessionReady) {
      setIsLoading(false);
      return;
    }
    loadActorsAndRestoreContext();
  }, [sessionReady]);

  const loadActorsAndRestoreContext = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Buscar actors disponíveis
      const actors = await getAvailableActors();
      setAvailableActors(actors);

      // Tentar restaurar contexto salvo
      const savedContext = getSavedActorContext();
      if (savedContext && savedContext.actorId) {
        const savedActor = actors.find(a => a.actor_id === savedContext.actorId);
        if (savedActor && savedActor.can_post) {
          // Restaurar contexto salvo se ainda for válido
          setContext({
            actorId: savedActor.actor_id,
            actorType: savedActor.actor_type,
            actorData: savedActor,
          });
          return;
        }
      }

      // Se não houver contexto salvo ou se o salvo não for mais válido,
      // selecionar o primeiro actor disponível (pessoal)
      if (actors.length > 0) {
        const defaultActor = actors.find(a => a.can_post) || actors[0];
        if (defaultActor) {
          setContext({
            actorId: defaultActor.actor_id,
            actorType: defaultActor.actor_type,
            actorData: defaultActor,
          });
          saveActorContext(defaultActor.actor_id, defaultActor.actor_type);
        }
      }
    } catch (err) {
      console.error('Erro ao carregar actors:', err);
      setError('Erro ao carregar opções. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  // Selecionar um ator
  const selectActor = useCallback((actorId: string | null, actorType?: 'user' | 'page' | 'group' | 'channel') => {
    if (!actorId) {
      // Limpar contexto
      setContext({ actorId: null, actorType: null, actorData: null });
      clearSavedActorContext();
      return;
    }

    const actor = availableActors.find(a => a.actor_id === actorId);
    if (!actor || !actor.can_post) {
      console.warn('Actor não encontrado ou sem permissão:', actorId);
      return;
    }

    const finalActorType = actorType || actor.actor_type;
    setContext({
      actorId: actor.actor_id,
      actorType: finalActorType,
      actorData: actor,
    });
    saveActorContext(actor.actor_id, finalActorType);
  }, [availableActors]);

  // Recarregar actors (útil quando empresas são adicionadas/removidas)
  const refreshActors = useCallback(() => {
    loadActorsAndRestoreContext();
  }, []);

  return {
    context,
    availableActors,
    isLoading,
    error,
    selectActor,
    refreshActors,
  };
}

/**
 * Salva o contexto de ator no localStorage
 */
function saveActorContext(actorId: string, actorType: 'user' | 'page' | 'group' | 'channel'): void {
  try {
    localStorage.setItem(ACTOR_CONTEXT_KEY, JSON.stringify({ actorId, actorType }));
  } catch (err) {
    console.error('Erro ao salvar contexto de ator:', err);
  }
}

/**
 * Restaura o contexto de ator do localStorage
 */
function getSavedActorContext(): { actorId: string; actorType: 'user' | 'page' | 'group' | 'channel' } | null {
  try {
    const saved = localStorage.getItem(ACTOR_CONTEXT_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (err) {
    console.error('Erro ao ler contexto de ator:', err);
  }
  return null;
}

/**
 * Limpa o contexto de ator salvo
 */
function clearSavedActorContext(): void {
  try {
    localStorage.removeItem(ACTOR_CONTEXT_KEY);
  } catch (err) {
    console.error('Erro ao limpar contexto de ator:', err);
  }
}


























