// src/hooks/useHomeData.ts
// Hook centralizado para carregar todos os dados da Home

import { useState, useEffect } from 'react';
import { useSession } from '../contexts/SessionProvider';
import { isAuthenticated, getTenantId } from '../config/auth';
import { getIdentityProfile } from '../api/identity';
import { getMatchingSuggestions, type MatchSuggestion } from '../api/matching';
import { getUserStatement } from '../api/transparency';
import { listPublicCulturalEvents } from '../api/cultural';

export interface HomeContextData {
  actorName: string;
  actorType: string;
  city: string | null;
  isLoadingCity: boolean;
}

export interface ContinueItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  status: string;
  path: string;
  type: 'transaction' | 'event';
}

export interface HomeData {
  context: HomeContextData;
  suggestions: MatchSuggestion[];
  continueItems: ContinueItem[];
  isLoading: boolean;
}

export function useHomeData(): HomeData {
  const { sessionReady, activeActor } = useSession();
  const [context, setContext] = useState<HomeContextData>({
    actorName: activeActor?.display_name || 'Usuário',
    actorType: activeActor?.actor_type === 'user' ? 'Pessoa Física' : 
               activeActor?.actor_type === 'page' ? 'Empresa' : 
               activeActor?.actor_type === 'group' ? 'Grupo' : 
               activeActor?.actor_type === 'channel' ? 'Canal' : 'Usuário',
    city: null,
    isLoadingCity: true,
  });
  const [suggestions, setSuggestions] = useState<MatchSuggestion[]>([]);
  const [continueItems, setContinueItems] = useState<ContinueItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar cidade do perfil de identidade
  useEffect(() => {
    const loadCity = async () => {
      if (!activeActor) {
        setContext(prev => ({ ...prev, city: null, isLoadingCity: false }));
        return;
      }

      try {
        const identity = await getIdentityProfile();
        const cityName = identity.residence?.city?.name || null;
        setContext(prev => ({ ...prev, city: cityName, isLoadingCity: false }));
      } catch (err) {
        console.warn('Erro ao carregar cidade:', err);
        setContext(prev => ({ ...prev, city: null, isLoadingCity: false }));
      }
    };

    loadCity();
  }, [activeActor]);

  // Atualizar contexto quando activeActor mudar
  useEffect(() => {
    if (activeActor) {
      setContext(prev => ({
        ...prev,
        actorName: activeActor.display_name || 'Usuário',
        actorType: activeActor.actor_type === 'user' ? 'Pessoa Física' : 
                   activeActor.actor_type === 'page' ? 'Empresa' : 
                   activeActor.actor_type === 'group' ? 'Grupo' : 
                   activeActor.actor_type === 'channel' ? 'Canal' : 'Usuário',
      }));
    }
  }, [activeActor]);

  // Carregar todos os dados da Home
  // REGRA CRÍTICA: Só fazer chamadas quando sessão estiver pronta E activeActor definido
  useEffect(() => {
    // GUARD: Não fazer chamadas se:
    // - sessão não estiver pronta
    // - não estiver autenticado
    // - tenantId não existir
    // - activeActor não estiver definido (endpoints protegidos precisam de actor)
    if (!sessionReady || !isAuthenticated() || !getTenantId() || !activeActor) {
      setIsLoading(false);
      return;
    }

    // Flag para cancelar se componente desmontar ou sessão mudar
    let cancelled = false;

    const loadHomeData = async () => {
      if (cancelled) return;
      setIsLoading(true);

      try {
        // Carregar sugestões e itens de continuidade em paralelo
        // 🔴 getUserStatement pode retornar 401 (sem acesso bancário) - tratar silenciosamente
        const [suggestionsResult, continueResult] = await Promise.allSettled([
          getMatchingSuggestions(4),
          Promise.allSettled([
            getUserStatement({ limit: 3 }),
            listPublicCulturalEvents({ limit: 3 }),
          ]),
        ]);

        // Processar sugestões
        if (suggestionsResult.status === 'fulfilled') {
          setSuggestions(suggestionsResult.value.suggestions || []);
        } else {
          console.warn('Erro ao carregar sugestões:', suggestionsResult.reason);
          setSuggestions([]);
        }

        // Processar itens de continuidade
        const items: ContinueItem[] = [];
        
        if (continueResult.status === 'fulfilled') {
          const [statementResult, eventsResult] = continueResult.value;

          // Adicionar transações recentes (se disponível)
          // 🔴 Tratar 401 silenciosamente (sem acesso bancário)
          if (statementResult.status === 'fulfilled' && statementResult.value.entries.length > 0) {
            const recentTransaction = statementResult.value.entries[0];
            const formatCurrency = (value: number): string => {
              return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL',
              }).format(value);
            };

            items.push({
              id: `transaction-${recentTransaction.transactionId}`,
              title: 'Transação recente',
              description: `Última transação: ${formatCurrency(recentTransaction.amount)}`,
              icon: recentTransaction.direction === 'in' ? '💰' : '💸',
              status: 'Recente',
              path: `/transaction/${recentTransaction.transactionId}`,
              type: 'transaction',
            });
          }

          // Adicionar eventos próximos (se disponível)
          if (eventsResult.status === 'fulfilled' && eventsResult.value.events.length > 0) {
            const upcomingEvent = eventsResult.value.events[0];
            const eventDate = new Date(upcomingEvent.datetime_start);
            const isToday = eventDate.toDateString() === new Date().toDateString();
            const isTomorrow = eventDate.toDateString() === new Date(Date.now() + 86400000).toDateString();
            
            items.push({
              id: `event-${upcomingEvent.id}`,
              title: upcomingEvent.title,
              description: isToday 
                ? `Hoje às ${eventDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
                : isTomorrow
                ? `Amanhã às ${eventDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
                : eventDate.toLocaleDateString('pt-BR'),
              icon: '🎭',
              status: upcomingEvent.status === 'PUBLISHED' ? 'Confirmado' : 'Agendado',
              path: `/events/${upcomingEvent.id}`,
              type: 'event',
            });
          }
        } else {
          // Erro ao carregar itens de continuidade - logar apenas se não for 401
          const reason = continueResult.reason;
          if (reason?.code !== 'FEATURE_UNAVAILABLE' && reason?.status !== 401) {
            console.warn('Erro ao carregar itens de continuidade:', reason);
          }
        }

        setContinueItems(items);
      } catch (err) {
        console.error('Erro ao carregar dados da Home:', err);
        setSuggestions([]);
        setContinueItems([]);
      } finally {
        setIsLoading(false);
      }
    };

    if (activeActor) {
      loadHomeData();
    } else {
      setIsLoading(false);
    }

    // Cleanup: cancelar se sessão mudar ou componente desmontar
    return () => {
      cancelled = true;
    };
  }, [activeActor, sessionReady]);

  return {
    context,
    suggestions,
    continueItems,
    isLoading,
  };
}







