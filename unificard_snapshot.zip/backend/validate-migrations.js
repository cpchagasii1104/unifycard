// validate-migrations.js
// Script para validar a ordem e estrutura das migrations sem executá-las

const fs = require('fs');
const path = require('path');

console.log('='.repeat(80));
console.log('🔍 VALIDAÇÃO DE MIGRATIONS');
console.log('='.repeat(80));
console.log('');

const migrationsDir = path.join(__dirname, 'migrations');
const migrationFiles = fs.readdirSync(migrationsDir)
  .filter(f => f.endsWith('.sql'))
  .sort();

console.log(`📋 Total de migrations encontradas: ${migrationFiles.length}`);
console.log('');

// Verificar duplicatas
const numbers = migrationFiles.map(f => {
  const match = f.match(/^(\d+)_/);
  return match ? parseInt(match[1]) : null;
}).filter(n => n !== null);

const duplicates = numbers.filter((n, i) => numbers.indexOf(n) !== i);
if (duplicates.length > 0) {
  console.error('❌ Migrations com números duplicados encontradas:');
  duplicates.forEach(dup => {
    const files = migrationFiles.filter(f => f.startsWith(`${dup.toString().padStart(3, '0')}_`));
    console.error(`   Número ${dup}: ${files.join(', ')}`);
  });
  console.error('');
  process.exit(1);
}

// Listar ordem de execução
console.log('📋 Ordem de execução (validação):');
console.log('');
migrationFiles.forEach((file, index) => {
  const match = file.match(/^(\d+)_(.+)/);
  const number = match ? parseInt(match[1]) : 0;
  const name = match ? match[2] : file;
  
  // Verificar se está na ordem correta
  const expectedNumber = index + 1;
  const isInOrder = number === expectedNumber || (index > 0 && number > parseInt(migrationFiles[index - 1].match(/^(\d+)_/)?.[1] || '0'));
  
  console.log(`  ${(index + 1).toString().padStart(2, '0')}. ${file} ${isInOrder ? '✅' : '⚠️'}`);
});

console.log('');

// Verificar migrations renumeradas
console.log('📊 Migrations renumeradas (036-039):');
const renumbered = migrationFiles.filter(f => {
  const match = f.match(/^(036|037|038|039)_/);
  return match !== null;
});

if (renumbered.length > 0) {
  renumbered.forEach(file => {
    console.log(`  ✅ ${file}`);
  });
} else {
  console.log('  ⚠️  Nenhuma migration renumerada encontrada (esperado: 036-039)');
}
console.log('');

// Verificar dependências básicas
console.log('🔗 Verificando dependências básicas:');
const hasInitialSchema = migrationFiles.some(f => f.startsWith('001_'));
const hasRBAC = migrationFiles.some(f => f.startsWith('002_'));
const hasGroups = migrationFiles.some(f => f.includes('groups_system'));
const hasSocial = migrationFiles.some(f => f.includes('social_core'));

console.log(`  ${hasInitialSchema ? '✅' : '❌'} Initial Schema (001)`);
console.log(`  ${hasRBAC ? '✅' : '❌'} RBAC (002)`);
console.log(`  ${hasGroups ? '✅' : '❌'} Groups System`);
console.log(`  ${hasSocial ? '✅' : '❌'} Social Core`);
console.log('');

// Verificar se work-instant precisa de migrations
console.log('📝 Nota: Work-Instant não requer migrations (usa Map em memória)');
console.log('');

console.log('='.repeat(80));
console.log('✅ VALIDAÇÃO CONCLUÍDA');
console.log('='.repeat(80));
console.log('');
console.log('💡 Para testar em banco limpo:');
console.log('   1. Crie um novo banco de dados');
console.log('   2. Configure DATABASE_URL no .env');
console.log('   3. Execute: npm run migrate');
console.log('');
















