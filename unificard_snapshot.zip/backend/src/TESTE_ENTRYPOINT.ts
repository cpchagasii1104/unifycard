// TESTE DEFINITIVO - Este arquivo testa se o Node consegue executar o entrypoint
console.log('🔵 SERVER ENTRYPOINT STARTED');
console.log('🔵 PID:', process.pid);
console.log('🔵 CWD:', process.cwd());
console.log('🔵 NODE_VERSION:', process.version);

setTimeout(() => {
  console.log('🔵 SERVER STILL ALIVE (3 segundos depois)');
}, 3000);

// Forçar saída para provar que o arquivo foi executado
setTimeout(() => {
  console.log('🔵 FORCING EXIT - Se você viu isso, o arquivo FOI executado');
  process.exit(1);
}, 5000);


























