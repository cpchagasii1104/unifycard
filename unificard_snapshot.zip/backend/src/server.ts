// ARQUIVO MORTO - BOOT.ts é o único entrypoint
export {}
