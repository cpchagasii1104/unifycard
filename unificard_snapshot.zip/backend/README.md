⚠️ GATE 2 ATIVO — SSOT

Este repositório está sob o Gate 2 (Bloqueio Estrutural).
É PROIBIDO:
- criar novos writers financeiros fora do Bank
- usar legado para decisão
- introduzir “temporários”

Qualquer violação = FAIL de Gate.

Ver: docs/ssot/PROHIBITED_STRUCTURES.md e docs/ssot/SSOT_REGISTRY.md
